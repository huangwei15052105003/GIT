# -*- coding: utf-8 -*-
"""
Created on Tue Nov 13 07:55:53 2018

@author: HUANGWEI45
"""

import os
import pandas as pd
from sklearn.linear_model import LinearRegression
import shutil
import datetime
import matplotlib.pyplot as plt



def read_single_awe(name):
 
            f = [i.strip() for i in open(name) if i.strip('\n') != ""]
            if eval(f[-1].split('\t')[3]) >= 1: # lot with wfr qty >=20
                #basic information================================================
                
                riqi = f [[i for i,k in enumerate(f) if k[0:17] == 'Date(YYYY/MM/DD)='][0]].split("=")[1]
                shijian =  f [[i for i,k in enumerate(f) if k[0:15] == 'Time(HR:MM:SS)='][0]].split("=")[1]
                part =  f [[i for i,k in enumerate(f) if k[0:6] == 'JobID='][0]].split("/")[1]
                layer =  f [[i for i,k in enumerate(f) if k[0:8] == 'LayerID='][0]].split("=")[1]
                tool =  f [[i for i,k in enumerate(f) if k[0:14] == 'MachineNumber='][0]].split("=")[1]
                lot =  f [[i for i,k in enumerate(f) if k[0:8] == 'BatchID='][0]].split("=")[1]
                
                # measurement data
                n = [i for i,k in enumerate(f) if k[0:17] == 'AlignmentStrategy'][0] #flag for inline data
                df = pd.DataFrame([i.split('\t') for i in f])
                tmp = df.loc[n+1:,]
                tmp.columns = df.loc[n:n].T[n]
                df = tmp.copy()
                mark =  tmp['MarkVariant'].iloc[0]
                align = tmp['AlignmentStrategy'].iloc[0]
                basic=[riqi,shijian,part,layer,tool,lot,mark,align,name]
                tmp,riqi,shijian,part,layer,tool,lot,mark,align,name=None,None,None,None,None,None,None,None,None,None
                
                
                #========================================================================================= 
                validNo = df[['WaferNr','MarkNr','NomPosX','NomPosY','BasicMarkType']].drop_duplicates()
                validX = validNo[validNo['BasicMarkType'].str.contains('-X')]#[['MarkNr','NomPosX','NomPosY']].drop_duplicates()
                validY = validNo[validNo['BasicMarkType'].str.contains('-Y')]#[['MarkNr','NomPosX','NomPosY']].drop_duplicates()
                validNo = [validX.shape[0]]
                validNo.append(validY.shape[0])
                #validX = validX[['MarkNr','NomPosX','NomPosY']].drop_duplicates()
                #validY = validY[['MarkNr','NomPosX','NomPosY']].drop_duplicates()
                
                
                  
                valid = ['1XRedValid','3XRedValid','5XRedValid','7XRedValid','88XRedValid',
                         '1XGreenValid','3XGreenValid','5XGreenValid','7XGreenValid','88XGreenValid',
                         '1YRedValid','3YRedValid','5YRedValid','7YRedValid','88YRedValid',
                         '1YGreenValid','3YGreenValid','5YGreenValid','7YGreenValid','88YGreenValid']
                
                #dela shift
                for n,order in enumerate(valid[0:20]):                  
                    if '88' in order:
                        tmp  = order[0:3]
                    else:
                        tmp = order[0:2]


                    if tmp[0:2]=='88':
                        #print(order,tmp)
                        tmp1 = df[df[valid[n-4]] =='T']
                        tmp1 = tmp1[tmp1[valid[n]] =='T'][['WaferNr','MarkNr','NomPosX','NomPosY',tmp + order[3:-5] + 'Pos',tmp + order[3:-5] + 'MCC',tmp + order[3:-5] + 'WQ']]                       
                        validNo.append(tmp1.shape[0]) 
                    else:
                        #print(order,tmp)
                        tmp1 = df[df[valid[n]] =='T'][['WaferNr','MarkNr','NomPosX','NomPosY',tmp + order[2:-5] + 'Pos',tmp + order[2:-5] + 'MCC',tmp + order[2:-5] + 'WQ']]                    
                        validNo.append(tmp1.shape[0])
                    if "X" in order:
                        validX = pd.merge(validX,tmp1,how='left', on= ['WaferNr','MarkNr','NomPosX','NomPosY'])
                    else:
                        validY = pd.merge(validY,tmp1,how='left', on= ['WaferNr','MarkNr','NomPosX','NomPosY'])
                validX[[ 'NomPosX', 'NomPosY', '1XRedPos',
                       '1XRedMCC', '1XRedWQ', '3XRedPos', '3XRedMCC', '3XRedWQ', '5XRedPos',
                       '5XRedMCC', '5XRedWQ', '7XRedPos', '7XRedMCC', '7XRedWQ', '88XRedPos',
                       '88XRedMCC', '88XRedWQ', '1XGreenPos', '1XGreenMCC', '1XGreenWQ',
                       '3XGreenPos', '3XGreenMCC', '3XGreenWQ', '5XGreenPos', '5XGreenMCC',
                       '5XGreenWQ', '7XGreenPos', '7XGreenMCC', '7XGreenWQ', '88XGreenPos',
                       '88XGreenMCC', '88XGreenWQ']] = validX[[ 'NomPosX', 'NomPosY', '1XRedPos',
                       '1XRedMCC', '1XRedWQ', '3XRedPos', '3XRedMCC', '3XRedWQ', '5XRedPos',
                       '5XRedMCC', '5XRedWQ', '7XRedPos', '7XRedMCC', '7XRedWQ', '88XRedPos',
                       '88XRedMCC', '88XRedWQ', '1XGreenPos', '1XGreenMCC', '1XGreenWQ',
                       '3XGreenPos', '3XGreenMCC', '3XGreenWQ', '5XGreenPos', '5XGreenMCC',
                       '5XGreenWQ', '7XGreenPos', '7XGreenMCC', '7XGreenWQ', '88XGreenPos',
                       '88XGreenMCC', '88XGreenWQ']].astype(float)
                validY[['NomPosX', 'NomPosY', '1YRedPos',
                       '1YRedMCC', '1YRedWQ', '3YRedPos', '3YRedMCC', '3YRedWQ', '5YRedPos',
                       '5YRedMCC', '5YRedWQ', '7YRedPos', '7YRedMCC', '7YRedWQ', '88YRedPos',
                       '88YRedMCC', '88YRedWQ', '1YGreenPos', '1YGreenMCC', '1YGreenWQ',
                       '3YGreenPos', '3YGreenMCC', '3YGreenWQ', '5YGreenPos', '5YGreenMCC',
                       '5YGreenWQ', '7YGreenPos', '7YGreenMCC', '7YGreenWQ', '88YGreenPos',
                       '88YGreenMCC', '88YGreenWQ']] = validY[[ 'NomPosX', 'NomPosY',  '1YRedPos',
                       '1YRedMCC', '1YRedWQ', '3YRedPos', '3YRedMCC', '3YRedWQ', '5YRedPos',
                       '5YRedMCC', '5YRedWQ', '7YRedPos', '7YRedMCC', '7YRedWQ', '88YRedPos',
                       '88YRedMCC', '88YRedWQ', '1YGreenPos', '1YGreenMCC', '1YGreenWQ',
                       '3YGreenPos', '3YGreenMCC', '3YGreenWQ', '5YGreenPos', '5YGreenMCC',
                       '5YGreenWQ', '7YGreenPos', '7YGreenMCC', '7YGreenWQ', '88YGreenPos',
                       '88YGreenMCC', '88YGreenWQ']].astype(float)
                        
                validX['XRedDelta'] = validX['1XRedPos']-validX['88XRedPos']
                validX['XGreenDelta'] = validX['1XGreenPos']-validX['88XGreenPos']
                validY['YRedDelta'] = validY['1YRedPos']-validY['88YRedPos']
                validY['YGreenDelta'] = validY['1YGreenPos']-validY['88YGreenPos']
                return basic,validNo,validX,validY





def linearfit(XYin):
    
    
    linreg = LinearRegression()
    residual=pd.DataFrame(columns=[0])
    for i in XYin['WaferNr'].unique():
        input_y = XYin[XYin['WaferNr']==i][XYin.columns[-1]]
        input_x = XYin[XYin['WaferNr']==i][['NomPosX', 'NomPosY']]
        model=linreg.fit(input_x, input_y)
        tmp = pd.DataFrame(linreg.intercept_ + linreg.coef_[0] * input_x['NomPosX'] + linreg.coef_[1] * input_x['NomPosY'] - input_y)
        residual = pd.concat([residual,tmp])
    residual = -1 * residual
    return residual.describe()


            
                    











def summary_awe(tmpID):
    

    
    #tmpID = '8C'
    
    #get HA,HB,LA,LB file list
    df= pd.read_csv("Y:\\ASML_AWE\\filelist.csv")
    df = df[df['Path'].str.endswith('awe')]
    #df=df[df['Path'].str.startswith(r'Y:\ASML_AWE\83')]
    df=df[df['Path'].str.startswith('Y:\\ASML_AWE\\'+tmpID)]
    file = [i for i in df['Path'] if '.1_0_' in i ] # only lot it ends with .1
    
    
    
    
    
    
    
    listx=[ '1XRedPos',
       '1XRedMCC', '1XRedWQ', '3XRedPos', '3XRedMCC', '3XRedWQ', '5XRedPos',
       '5XRedMCC', '5XRedWQ', '7XRedPos', '7XRedMCC', '7XRedWQ', '88XRedPos',
       '88XRedMCC', '88XRedWQ', '1XGreenPos', '1XGreenMCC', '1XGreenWQ',
       '3XGreenPos', '3XGreenMCC', '3XGreenWQ', '5XGreenPos', '5XGreenMCC',
       '5XGreenWQ', '7XGreenPos', '7XGreenMCC', '7XGreenWQ', '88XGreenPos',
       '88XGreenMCC', '88XGreenWQ', 'XRedDelta', 'XGreenDelta']
    listy=['1YRedPos',
       '1YRedMCC', '1YRedWQ', '3YRedPos', '3YRedMCC', '3YRedWQ', '5YRedPos',
       '5YRedMCC', '5YRedWQ', '7YRedPos', '7YRedMCC', '7YRedWQ', '88YRedPos',
       '88YRedMCC', '88YRedWQ', '1YGreenPos', '1YGreenMCC', '1YGreenWQ',
       '3YGreenPos', '3YGreenMCC', '3YGreenWQ', '5YGreenPos', '5YGreenMCC',
       '5YGreenWQ', '7YGreenPos', '7YGreenMCC', '7YGreenWQ', '88YGreenPos',
       '88YGreenMCC', '88YGreenWQ', 'YRedDelta', 'YGreenDelta']
        
    
    summary=[]   
    for count,name in enumerate(file):
        print (count+1, len(file),name)
        basic,validNo,validX,validY = None,None,None,None
        data=[]
        
        try:
            basic,validNo,validX,validY =  read_single_awe(name)
            data.extend(basic)
            data.extend(validNo)
            for i in range(32):
                data.extend(   validX[listx[i]].describe()   )
                data.extend(   validY[listy[i]].describe()   )
            #data-->basic,validNo,1XRedPos,1YRedPos,1XRedMCC,1YRedMCC......., "543" item
            
            for i in range(10):
                #print(listx[3*i])
                XYin = validX[['WaferNr', 'MarkNr', 'NomPosX', 'NomPosY',listx[3*i]]].dropna()
                data.extend(linearfit(XYin)[0])                
                XYin = validY[['WaferNr', 'MarkNr', 'NomPosX', 'NomPosY',listy[3*i]]].dropna()
                data.extend(linearfit(XYin)[0])
            summary.append(data)
                
            
        except:
            print('==file errro or small wfr qty===')
        #summary.append(data)
    return summary
        
 
    



def rar_awe(file):
    


    #df=df[df['Path'].str.startswith(r'Y:\ASML_AWE\83')]
    '''
    rarlist = os.listdir("Y:\\ASML_AWE\\rar")
    rarlist.sort()
   
    file = ["Y:\\ASML_AWE\\rar\\" + i for i in rarlist if '.1_0_' in i ] # only lot it ends with .1
    '''
    
    
    
    
    
    
    listx=[ '1XRedPos',
       '1XRedMCC', '1XRedWQ', '3XRedPos', '3XRedMCC', '3XRedWQ', '5XRedPos',
       '5XRedMCC', '5XRedWQ', '7XRedPos', '7XRedMCC', '7XRedWQ', '88XRedPos',
       '88XRedMCC', '88XRedWQ', '1XGreenPos', '1XGreenMCC', '1XGreenWQ',
       '3XGreenPos', '3XGreenMCC', '3XGreenWQ', '5XGreenPos', '5XGreenMCC',
       '5XGreenWQ', '7XGreenPos', '7XGreenMCC', '7XGreenWQ', '88XGreenPos',
       '88XGreenMCC', '88XGreenWQ', 'XRedDelta', 'XGreenDelta']
    listy=['1YRedPos',
       '1YRedMCC', '1YRedWQ', '3YRedPos', '3YRedMCC', '3YRedWQ', '5YRedPos',
       '5YRedMCC', '5YRedWQ', '7YRedPos', '7YRedMCC', '7YRedWQ', '88YRedPos',
       '88YRedMCC', '88YRedWQ', '1YGreenPos', '1YGreenMCC', '1YGreenWQ',
       '3YGreenPos', '3YGreenMCC', '3YGreenWQ', '5YGreenPos', '5YGreenMCC',
       '5YGreenWQ', '7YGreenPos', '7YGreenMCC', '7YGreenWQ', '88YGreenPos',
       '88YGreenMCC', '88YGreenWQ', 'YRedDelta', 'YGreenDelta']
        
    
    summary=[]   
    for count,name in enumerate(file):
        print (count+1, len(file),name)
        basic,validNo,validX,validY = None,None,None,None
        data=[]
        
        try:
            basic,validNo,validX,validY =  read_single_awe(name)
            data.extend(basic)
            data.extend(validNo)
            for i in range(32):
                data.extend(   validX[listx[i]].describe()   )
                data.extend(   validY[listy[i]].describe()   )
            #data-->basic,validNo,1XRedPos,1YRedPos,1XRedMCC,1YRedMCC......., "543" item
            
            for i in range(10):
                #print(listx[3*i])
                XYin = validX[['WaferNr', 'MarkNr', 'NomPosX', 'NomPosY',listx[3*i]]].dropna()
                data.extend(linearfit(XYin)[0])                
                XYin = validY[['WaferNr', 'MarkNr', 'NomPosX', 'NomPosY',listy[3*i]]].dropna()
                data.extend(linearfit(XYin)[0])
            summary.append(data)
                
            
        except:
            print('==file errro or small wfr qty===')
        #summary.append(data)
    return summary
        





def compile_rarfile():
    
    rarlist = os.listdir("Y:\\ASML_AWE\\rar")
    rarlist.sort()   
    file = ["Y:\\ASML_AWE\\rar\\" + i for i in rarlist if '.1_0_' in i ] # only lot it ends with .1    
    file = file[0:10000] # error if too many files processed    
    summary =  rar_awe(file)
    pd.DataFrame(summary).to_csv('Y:\\ASML_AWE\\Full_AWE_rar40000.csv',index=None,mode='a',encoding='GBK')   




def complile_lateset_awe_by_tool(tmpID ='8C'):

    summary=summary_awe(tmpID)

    pd.DataFrame(summary).to_csv('Y:\\ASML_AWE\\Full_AWE_'+ tmpID + '.csv',index=None,mode='a',encoding='GBK',header=None)                        
    
















#=============================================================================================



def get_filepath(path='Z:\\AsmlAweFile\\RawData\\82\\'):
    n = 0
    filenamelist=[]
    for root, dirs, files in os.walk(path, False):  #root:所有目录名-->字符串 #dirs: root下的子目录名-->列表 #files：root下的文件名-->列表 # name.endswith(ext)-->文件名筛选 
        for names in files:
            #if names.endswith('ChartData.rar'):
            filenamelist.append( root  + '\\' + names)
            n +=1
            print(n,"   ",names)
    filenamelist.sort(reverse = False)
    return (filenamelist)





def read_disk_z_awe(filelist):
    

    

    
    file = [ i for i in filelist if i[-3:]=='awe']

    
    
    
    
    
    
    
    listx=[ '1XRedPos',
       '1XRedMCC', '1XRedWQ', '3XRedPos', '3XRedMCC', '3XRedWQ', '5XRedPos',
       '5XRedMCC', '5XRedWQ', '7XRedPos', '7XRedMCC', '7XRedWQ', '88XRedPos',
       '88XRedMCC', '88XRedWQ', '1XGreenPos', '1XGreenMCC', '1XGreenWQ',
       '3XGreenPos', '3XGreenMCC', '3XGreenWQ', '5XGreenPos', '5XGreenMCC',
       '5XGreenWQ', '7XGreenPos', '7XGreenMCC', '7XGreenWQ', '88XGreenPos',
       '88XGreenMCC', '88XGreenWQ', 'XRedDelta', 'XGreenDelta']
    listy=['1YRedPos',
       '1YRedMCC', '1YRedWQ', '3YRedPos', '3YRedMCC', '3YRedWQ', '5YRedPos',
       '5YRedMCC', '5YRedWQ', '7YRedPos', '7YRedMCC', '7YRedWQ', '88YRedPos',
       '88YRedMCC', '88YRedWQ', '1YGreenPos', '1YGreenMCC', '1YGreenWQ',
       '3YGreenPos', '3YGreenMCC', '3YGreenWQ', '5YGreenPos', '5YGreenMCC',
       '5YGreenWQ', '7YGreenPos', '7YGreenMCC', '7YGreenWQ', '88YGreenPos',
       '88YGreenMCC', '88YGreenWQ', 'YRedDelta', 'YGreenDelta']
        
    
    summary=[]   
    for count,name in enumerate(file):
        print (count+1, len(file),name)
        basic,validNo,validX,validY = None,None,None,None
        data=[]
        
        try:
            basic,validNo,validX,validY =  read_single_awe(name)
            data.extend(basic)
            data.extend(validNo)
            for i in range(32):
                data.extend(   validX[listx[i]].describe()   )
                data.extend(   validY[listy[i]].describe()   )
            #data-->basic,validNo,1XRedPos,1YRedPos,1XRedMCC,1YRedMCC......., "543" item
            
            for i in range(10):
                #print(listx[3*i])
                XYin = validX[['WaferNr', 'MarkNr', 'NomPosX', 'NomPosY',listx[3*i]]].dropna()
                data.extend(linearfit(XYin)[0])                
                XYin = validY[['WaferNr', 'MarkNr', 'NomPosX', 'NomPosY',listy[3*i]]].dropna()
                data.extend(linearfit(XYin)[0])
            summary.append(data)
            
                
            
        except:
            print('==file errro or small wfr qty===')
        move_file(name)
        #summary.append(data)
    return summary
        


def move_file(name):
    
    str1 =  datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    
    new = 'y:\\ASML_AWE\\' + name[23:26] + name[26:].split('\\')[0] + '\\' + name[26:].split('\\')[1] 
    if os.path.exists(new ):
        #print("TRUE",name,new)
        if os.path.exists( new + '\\' + name.split('\\')[6]):
            print("TRUE")
            new = new + '\\' +  str1 + "_" + name.split('\\')[6]
            shutil.move(name,new)
        else:
            shutil.move(name,new)
    else:
        #print("FALSE",name,new)
        os.makedirs(new) 
        shutil.move(name,new)
    
    
    



def plot_MCC(file = 'y:/ASML_AWE/New_AWE.csv'):
    
    tool_dict = {6158:'ALSD89',4666:'ALSD82',5688:'ALSD8A',9726:'ALSD8C',4955:'ALSD8B',
                 6450:'ALSD85',8111:'BLSD7D',8144:'ALSD86',4730:'ALSD83',4142:'ALSD87'}
    
    tmp = ['RiQI', 'ShiJian', 'Part', 'Layer', 'Tool', 'Lot','MarkVariant','AlignStrategy', 
        '5XRedMCC_count','5XRedMCC_mean','5XRedMCC_std','5XRedMCC_min','5XRedMCC_25%','5XRedMCC_50%','5XRedMCC_75%','5XRedMCC_max',
        '5YRedMCC_count','5YRedMCC_mean','5YRedMCC_std','5YRedMCC_min','5YRedMCC_25%','5YRedMCC_50%','5YRedMCC_75%','5YRedMCC_max',
        '5XGreenMCC_count','5XGreenMCC_mean','5XGreenMCC_std','5XGreenMCC_min','5XGreenMCC_25%','5XGreenMCC_50%','5XGreenMCC_75%','5XGreenMCC_max',
        '5YGreenMCC_count','5YGreenMCC_mean','5YGreenMCC_std','5YGreenMCC_min','5YGreenMCC_25%','5YGreenMCC_50%','5YGreenMCC_75%','5YGreenMCC_max']
    tmp = ['RiQI', 'ShiJian',  'Tool',
           '5XRedMCC_min','5XRedMCC_max',
        '5YRedMCC_min','5YRedMCC_max',
        '5XGreenMCC_min','5XGreenMCC_max',
        '5YGreenMCC_min','5YGreenMCC_max']
    df = pd.read_csv(file,usecols = tmp )
    df['Index'] = pd.to_datetime(df['RiQI'] + " " + df['ShiJian'])
    df = df.reset_index().set_index('Index')
    df = df.sort_index()
    for toolid in df['Tool'].unique():
        tmp = df[df['Tool'] == toolid]
        fig = plt.figure(figsize=(18, 10))
        #-----------------------------------
        ax1 = fig.add_subplot(4,2,1) 
    
        #plt.plot(tmp.index,tmp['5XRedMCC_min']) 
        tmp['5XRedMCC_min'][-1188:].plot()             
        ax1.set_title(tool_dict[toolid] +"_5XRedMCC-Min")
        plt.ylim(0.9,1)
        #-----------------------------------
        ax2 = fig.add_subplot(4,2,2) 
    
        tmp['5XRedMCC_max'][-1188:].plot()             
        ax2.set_title(tool_dict[toolid] +"_5XRedMCC-Max")
        plt.ylim(0.99,1)
    
        
        #-----------------------------------
        ax3 = fig.add_subplot(4,2,3) 
    
        tmp['5XGreenMCC_min'][-1188:].plot()             
        ax3.set_title(tool_dict[toolid] +"_5XGreenMCC-Min")
        plt.ylim(0.9,1)
        
      
        
        #-----------------------------------
        ax4 = fig.add_subplot(4,2,4)
        tmp['5XGreenMCC_max'][-1188:].plot()             
        ax4.set_title(tool_dict[toolid] +"_5XGreenMCC-Max")
        plt.ylim(0.99,1)
        
        
              #-----------------------------------
        ax5 = fig.add_subplot(4,2,5) 
    
        #plt.plot(tmp.index,tmp['5XRedMCC_min']) 
        tmp['5YRedMCC_min'][-1188:].plot()             
        ax5.set_title(tool_dict[toolid] +"_5YRedMCC-Min")
        plt.ylim(0.9,1)
        #-----------------------------------
        ax6 = fig.add_subplot(4,2,6) 
    
        tmp['5YRedMCC_max'][-1188:].plot()             
        ax6.set_title(tool_dict[toolid] +"_5YRedMCC-Max")
        plt.ylim(0.99,1)
    
        
        #-----------------------------------
        ax7 = fig.add_subplot(4,2,7) 
    
        tmp['5YGreenMCC_min'][-1188:].plot()             
        ax7.set_title(tool_dict[toolid] +"_5YGreenMCC-Min")
        plt.ylim(0.9,1)
        
      
        
        #-----------------------------------
        ax8 = fig.add_subplot(4,2,8)
        tmp['5YGreenMCC_max'][-1188:].plot()             
        ax8.set_title(tool_dict[toolid] +"_5YGreenMCC-Max")
        plt.ylim(0.99,1)
     
        fig.subplots_adjust(hspace=1)       
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        plt.savefig('z:/_DailyCheck/ASML_AWE/' + tool_dict[toolid] + '.jpg',dpi=100, bbox_inches='tight')







    
if __name__=="__main__":
    filelist = get_filepath(path='Z:\\AsmlAweFile\\RawData\\')
    pd.DataFrame(filelist).to_csv('z:/asmlawefile/list.csv') 
    summary =   read_disk_z_awe(filelist)   
    pd.DataFrame(summary).to_csv('Y:\\ASML_AWE\\New_AWE.csv',index=None,mode='a',encoding='GBK',header=None)     
    plot_MCC(file = 'y:/ASML_AWE/New_AWE.csv')
    

















































#['y:/asml_awe/' + i for i in os.listdir('y:/asml_awe') if i[-3:] == 'csv' and '500_' not in i and 'filelist' not in i and 'Template' not in i ]
      
#tmp = pd.read_csv('y:/asml_awe/Full_AWE_rar80000.csv')

                     
                        
    

                        
                        
                        




#df[['5XRedMCC_mean','5YRedMCC_mean','5XGreenMCC_mean','5YGreenMCC_mean']].to_csv("C:/temp/mcc.csv")                        
#df[['5XRedWQ_mean','5YRedWQ_mean','5XGreenWQ_mean','5YGreenWQ_mean']].to_csv("C:/temp/wq.csv") 
#df[['5XRedResidual_std','5YRedResidual_std','5XGreenResidual_std','5YGreenResidual_std']].to_csv("C:/temp/residual.csv")                        
                     
                              
                        
                        
'''                        
def unrar_file(filename): #DOS command,unzip file
    databasepath = r'Z:\_DailyCheck\Database\data.mdb'
    str1='P:\\HuangWei\\haozip\\haozipc e -y ' + filename + ' -oP:\\HuangWei\\'
    os.system(str1)
    print(filename)                        
                        
filename = 'Y:\\ASML_AWE\\08\\A12358EA\\GT\\AWFT_CJ4C04.1_0_TO_SM5.rar'                        
str1='Z:\\_DailyCheck\\outlook\\haozip\\haozipc e -y ' + filename + ' -oc:\temp'                        
os.system(str1)                        
 




df= pd.read_csv("Y:\\ASML_AWE\\filelist.csv")
rar = df[df['Path'].str.endswith('rar')]
                     
f = open('c:/temp/bat.txt','a')                     
for file in rar['Path']:
    print (file)
    f.write("\n" + 'Z:\\_DailyCheck\\outlook\\haozip\\haozipc e -y ' + file + ' -oY:\\ASML_AWE\\RAR'  )
f.close()                        
                        
'''                        


                        
                        