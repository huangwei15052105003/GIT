# -*- coding: utf-8 -*-
"""
Created on Thu May  3 11:54:31 2018

@author: HUANGWEI45
"""

# NIKON RECIPE CHECK
# Only datetime only
#  P:\_DailyCheck\NikonRecipe

import os
import pandas as pd
import time
import datetime
import numpy as np
import xlwings as xw



def get_path(FileDir =r'P:\Nikondir' ):
#list batchreport filename in specified directory    
    filenamelist=[]
    for root, dirs, files in os.walk(FileDir, False):  #root:所有目录名-->字符串 #dirs: root下的子目录名-->列表 #files：root下的文件名-->列表 # name.endswith(ext)-->文件名筛选 
        for names in files:
            if 'ALII' in names and '.txt' in names:
                tmpname = root  + '\\' + names
                x = time.localtime ( (int(os.stat(tmpname).st_mtime)) )
                tmpdatetime = datetime.datetime.strptime(str(x.tm_year)+'-'+str(x.tm_mon)+'-'+str(x.tm_mday),'%Y-%m-%d')
                filenamelist.append([tmpname,(tmpdatetime.date()) ])
    filenamelist.sort(reverse = False)
    
    
    return (filenamelist)
    

def NikonRecipeDate():

    filelist = get_path(FileDir =r'P:\Nikondir' )
    
    
    
    
    tool=[]
    
    missing = []
    for i,x in enumerate(filelist):
        print(x)
        key = datetime.datetime.now().date()
        if x[1]<key:
            tool.append([x[0],str(x[1])])
            missing.append(x[0].split("\\")[2].split('.')[0])
            print(x[0],str(x[1]))
        
        tmp = pd.read_csv(x[0])
        tmp = tmp.dropna()    
        tmp = tmp.reset_index()
        tmp.columns  = [1,2,3,4]
        tmp  = tmp [tmp[1].str.contains('.PRV;')]
     
        
        tmp['Tool']= x[0][-10:-4]   
        
        
        if i == 0:
            df = tmp.copy()
        else:
            df = pd.concat([df,tmp],axis=0)
        
    
    tmp = df[1].str.split(';')
    name = [ i[0][:-4] for i in  tmp ]  #part name 
    
    date = [ i[1].split('-') for i in tmp ]
    
    date1 = [ i[0][-2:] for i in date ]  #date
    date2 = [ i[1] for i in date ]  # month
    date3 = [ i[2][0:4] for i in date] #year
    tool = list(df['Tool'])
     
       
    df = pd.DataFrame(np.array([tool,name,date1,date2,date3]).T)
    df['date'] = pd.to_datetime( df[2] + '-' + df[3] + '-' + df[4] )
    df = df.drop([2,3,4],axis =1)
    df.columns = ['Tool','Part','Date']
    #df = df [ df['Date'] > datetime.datetime.strptime('2018-5-2','%Y-%m-%d') ]
    
    df = df [ df['Date'] >( datetime.datetime.now().date()-datetime.timedelta(days=2) )] 
    df = df.drop_duplicates()
    result = df.pivot(index = 'Part',columns = 'Tool',values = 'Part')
    
    pd.concat([result,pd.DataFrame(missing)],axis=0).to_csv('Z:/_DailyCheck/NikonRecipe/' + str(datetime.datetime.now().date()) + '.csv')
    
    #sht = wb.sheets[0]
    #sht.range("A1").value = result
    #sht.range("Y1").value = " Tools Below are disconnected"
    #sht.range("Y2").value = missing
    #wb.save( 'P:/_DailyCheck/NikonRecipe/' + str(datetime.datetime.now().date()) + '.xlsx')
    #wb.close()
    
    #shetresult.to_csv( 'P:/RoutineWork/NikonRecipeDateCheck/' + str(datetime.datetime.now().date()-datetime.timedelta(days=1)) + '.CSV')
if __name__ == "__main__":
     NikonRecipeDate()
     tmp = open(r'C:\anaconda3\log.txt','a')
     tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___003-NikonRecipeDate  Done\n")
     tmp.close()