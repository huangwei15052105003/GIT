# -*- coding: utf-8 -*-
"""
Created on Fri Apr 27 12:38:02 2018

@author: HUANGWEI45


"""

## script to be coded to un-extract chartdata.xls automatically to p:/huangwei
## now is manually unextracted




import win32com.client
import datetime
import time
import pandas as pd
import os


#databasepath = r'Z:\_DailyCheck\Database\data.mdb'
def get_db_latest_date():
    databasepath = r'Z:\_DailyCheck\Database\data.mdb'
    conn = win32com.client.Dispatch(r"ADODB.Connection")
    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)
    
    rs = win32com.client.Dispatch(r'ADODB.Recordset')
    rs_name = ['CD_data','OL_ASML','OL_Nikon']
    #startdate = "'2018-04-27 06:00:00', 'YYYY-MM-DD HH:MM:SS'"
    #sql = " SELECT Dcoll_Time FROM " + rs_name[0] + "  where Dcoll_Time > format (" + startdate + " ) Order By Dcoll_Time desc "   
    
    
    print('CD date is being extracted...........')
    sql = " SELECT Dcoll_Time FROM " + rs_name [0] + "  Order By Dcoll_Time asc "  
    rs.Open(sql, conn, 1, 3)
    rs.MoveLast()
    CDdate = datetime.datetime.strptime(  str( rs.Fields[0].Value )[:-6], '%Y-%m-%d %H:%M:%S')
    rs = None
    rs = win32com.client.Dispatch(r'ADODB.Recordset')
    
    print('ASML date is being extracted...........')    
    sql = " SELECT Dcoll_Time FROM " + rs_name [1] + "  Order By Dcoll_Time asc " 
    rs.Open(sql, conn, 1, 3)
    rs.MoveLast()
    ASMLdate = datetime.datetime.strptime(  str( rs.Fields[0].Value )[:-6], '%Y-%m-%d %H:%M:%S')
    rs = None
    rs = win32com.client.Dispatch(r'ADODB.Recordset')
    
    print('Nikon date is being extracted...........')    
    sql = " SELECT Dcoll_Time FROM " + rs_name [2] + "  Order By Dcoll_Time asc " 
    rs.Open(sql, conn, 1, 3)
    rs.MoveLast()
    #NIKONdate = datetime.datetime.strptime(  str( rs.Fields[0].Value ).rstrip("+00:00"), '%Y-%m-%d %H:%M:%S')
    NIKONdate = datetime.datetime.strptime(  str( rs.Fields[0].Value )[:-6], '%Y-%m-%d %H:%M:%S')

    rs = None
    
    
    #rs.Open('[' + rs_name[0] + ']', conn, 1, 3)
    
    
    #rs.MoveFirst()  #光标移到首条记录
    #rs.MoveNext()
    #rs.MoveLast()
    
    conn.close
    
    print ('Latest Date in database: \n\n    CD:    ' + str(CDdate) + '\n\n    ASML:  ' + str(ASMLdate) + '\n\n    Nikon: ' + str(NIKONdate) +'\n' )
    
    return CDdate,ASMLdate,NIKONdate
    
    



def get_latest_chart_data(CDdate, ASMLdate, NIKONdate): #from compiled CSV file
    databasepath = r'Z:\_DailyCheck\Database\data.mdb'
    filefullpath = 'Z:\\_DailyCheck\\outlook\\ChartData.xls'
    
    print('CD data from CSV  is being extracted...........')    
    cd_new = pd.read_excel(filefullpath,sheet_name='CD')
    cd_new['Dcoll Time'] = pd.to_datetime(cd_new['Dcoll Time'])    
    cd_new = cd_new.sort_values(by="Dcoll Time",ascending = True)
    cd_new = cd_new[ cd_new['Dcoll Time'] > CDdate ]
        
    print('ASML data from CSV  is being extracted...........')    
    asml_new = pd.read_excel(filefullpath,sheet_name='OL_ASML',skiprows=[1])
    asml_new['Dcoll Time'] = pd.to_datetime(asml_new['Dcoll Time'])    
    asml_new = asml_new.sort_values(by="Dcoll Time",ascending = True)
    asml_new = asml_new[ asml_new['Dcoll Time'] > ASMLdate ]
    
    print('NIKON data from CSV  is being extracted...........')    
    nikon_new = pd.read_excel(filefullpath,sheet_name='OL_NIKON',skiprows=[1])
    nikon_new['Dcoll Time'] = pd.to_datetime(nikon_new['Dcoll Time'])    
    nikon_new = nikon_new.sort_values(by="Dcoll Time",ascending = True)
    nikon_new = nikon_new[ nikon_new['Dcoll Time'] > NIKONdate ]
    
    return cd_new,asml_new,nikon_new






def get_rar_filename(dirxls):
    databasepath = r'Z:\_DailyCheck\Database\data.mdb'
    
    filenamelist=[]
    for root, dirs, files in os.walk(dirxls, False):  #root:所有目录名-->字符串 #dirs: root下的子目录名-->列表 #files：root下的文件名-->列表 # name.endswith(ext)-->文件名筛选 
        for names in files:
            if names.endswith('.RAR') or names.endswith('.rar'):
                filenamelist.append( root  + '\\' + names) 
    filenamelist.sort(reverse = False)
    return (filenamelist)
    
    
    
def unrar_file(filename): #DOS command,unzip file
    databasepath = r'Z:\_DailyCheck\Database\data.mdb'
    str1='P:\\HuangWei\\haozip\\haozipc e -y ' + filename + ' -oP:\\HuangWei\\'
    os.system(str1)
    print(filename)
 
def unrar_latest_ChartDataXLS():
    databasepath = r'Z:\_DailyCheck\Database\data.mdb'
    dirxls = r'Z:\_DailyCheck\outlook\Charting'
    filenamelist=get_rar_filename(dirxls)
    tmp = []
    for filename in filenamelist:
        print (time.ctime(os.stat(filename).st_mtime))
        print (time.localtime ( (int(os.stat(filename).st_mtime)) ))
        tmp.append([filename, time.localtime ( (int(os.stat(filename).st_mtime)) )])
    tmp = pd.DataFrame(tmp)
    tmp = tmp.sort_values(by=1, ascending=True)
    tmp = tmp.iloc[-1,0]
    tmp ='Z:\\_DailyCheck\\outlook\\haozip\\haozipc e -y ' + tmp + ' -oZ:\\_DailyCheck\\outlook\\'
    os.system(tmp)




























def update_db(cd_new,asml_new,nikon_new):
    databasepath = r'Z:\_DailyCheck\Database\data.mdb'
    #################################################
    #https://zhidao.baidu.com/question/1832218251617721020.html
    import pytz
    tz = pytz.timezone("GMT")  # settime zone
    #datetime.datetime(2009, 2, 21, 15, 12, 33, tzinfo=tz)    
    # datetime format of access:  pywintypes.datetime, with time zone information
    # datetime format of pandas:  pandas.tslib.Timestamp -->swith to datetime with time zone
    
    
    
    cd_new = cd_new.fillna(0)
    asml_new = asml_new.fillna(0)
    nikon_new = nikon_new.fillna(0)
        
    
                 
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)


    rs_name= ['CD_data','OL_ASML','OL_Nikon']     
    
    
    print ('CD database is being updated................')    
    rs = win32com.client.Dispatch(r'ADODB.Recordset')
    rs.Open(  rs_name[0] , conn, 1, 3)
    #rs.MoveLast()
    for i in range(cd_new.shape[0]):

        rs.AddNew()  #添加一条新记录 
        for j in range(cd_new.shape[1]):
            #print (i,j, cd_new.iloc[i,j])
           
            if j == 7:
        
                tmp = cd_new.iloc[i,j]
                tmp = datetime.datetime(tmp.year, tmp.month, tmp.day, tmp.hour, tmp.minute, tmp.second, tzinfo=tz)
                rs.Fields.Item(j).Value = tmp
                #rs.Fields.Item(j).Value = cd_new.iloc[i,j].tz_localize("Asia/Shanghai")  #GMT
            else:
                rs.Fields.Item(j).Value = cd_new.iloc[i,j]
        rs.Update()  #更新
    print ('CD database update is completed.    ' + str(cd_new.shape[0]) + ' rows have been inserted')
    rs = None





    print ('ASML database is being updated................')    
    rs = win32com.client.Dispatch(r'ADODB.Recordset')
    rs.Open(  rs_name[1] , conn, 1, 3)
    #rs.MoveLast()
    for i in range(asml_new.shape[0]):
        
        rs.AddNew()  #添加一条新记录 
        for j in range(asml_new.shape[1]):
            #print (i,j, asml_new.iloc[i,j])
           
            if j == 7:
        
                tmp = asml_new.iloc[i,j]
                tmp = datetime.datetime(tmp.year, tmp.month, tmp.day, tmp.hour, tmp.minute, tmp.second, tzinfo=tz)
                rs.Fields.Item(j).Value = tmp
                #rs.Fields.Item(j).Value = cd_new.iloc[i,j].tz_localize("Asia/Shanghai")  #GMT
            else:
                rs.Fields.Item(j).Value = asml_new.iloc[i,j]
        rs.Update()  #更新
    print ('asml database update is completed.    ' + str(asml_new.shape[0]) + ' rows have been inserted')
    rs = None








    print ('NIKON database is being updated................')    
    rs = win32com.client.Dispatch(r'ADODB.Recordset')
    rs.Open(  rs_name[2] , conn, 1, 3)
    #rs.MoveLast()
    for i in range(nikon_new.shape[0]):
        
        rs.AddNew()  #添加一条新记录 
        for j in range(nikon_new.shape[1]):
            #print (i,j, nikon_new.iloc[i,j])           
            if j == 7:

                tmp = nikon_new.iloc[i,j]
                tmp = datetime.datetime(tmp.year, tmp.month, tmp.day, tmp.hour, tmp.minute, tmp.second, tzinfo=tz)
                rs.Fields.Item(j).Value = tmp
                #rs.Fields.Item(j).Value = cd_new.iloc[i,j].tz_localize("Asia/Shanghai")  #GMT
            else:
                rs.Fields.Item(j).Value = nikon_new.iloc[i,j]
        rs.Update()  #更新
    print ('Nikon database update is completed.    ' + str(nikon_new.shape[0]) + ' rows have been inserted')
    rs = None


    conn.close
        
       
if __name__ == "__main__":  
    try:
        CDdate, ASMLdate, NIKONdate = get_db_latest_date()
        
        unrar_latest_ChartDataXLS()
        
        cd_new, asml_new, nikon_new =  get_latest_chart_data(CDdate, ASMLdate, NIKONdate) #from compiled CSV file
        
        update_db(cd_new,asml_new,nikon_new)
        tmp = open(r'C:\anaconda3\log.txt','a')
        tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___010A-PpcsAdo Done\n")
        tmp.close()
    except:
        tmp = open(r'C:\anaconda3\log.txt','a')
        tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___010A-PpcsAdo Failed\n")
        tmp.close()
