# -*- coding: utf-8 -*-
"""
Created on Wed Aug  8 10:16:05 2018

@author: HUANGWEI45
"""

import pandas as pd
import datetime
import os












def generate_ftp(nikonpath,wipPart,list1):
    
    
    no_delete = ['CH','CH001','CH002','CH003','DH','DH001','DH002','DH003',
             'GSL','GSL001','GSL002','GSL003','PYH','PYH001','PYH002','PYH003',
             'QWH','QWH001','QWH002','QWH003','ZJZ','ZJZ001','ZJZ002','ZJZ003',
             'ZJ','ZJ001','ZJ002','ZJ003','ZP','ZP001','ZP002','ZP003',
             'YW',"YW001",'YW002','YW003','QQ','QQ001','QQ002','QQ003',
             'HFB','HFB001','HFB002','HFB003','LPG','LPG001','LPG002','LPG003',
             'LYH','LYH001','LYH002','LYH003','SK','SK001','SK002','SK003',
             'WYC','WYC001','WYC002','WYC003','WTX','WTX001','WTX002','WTX003',
             'YXC','YXC001','YXC002','YXC003','ZFS','ZFS001','ZFS002','ZFS003',
             'ZLF','ZLF001','ZLF002','ZLF003','ZQX','ZQX001','ZQX002','ZQX003',
             'FH','FH001','FH002','FH003', 'SCR','SCR001','SCR002','SCR003',   
             '2LXXXBST03','2LXXXBST04',
             '2LXXXLSA01',
             '2LXXXFIA02','2LXXXFIA03','2LXXXFIA04','2LXXXFIA05','2LXXXFIA06','2LXXXFIA07',
             '2LXXXSCD01','2LXXXSCD02','2LXXXSCD03','2LXXXSCD04','2LXXXSCD05',
             'XK2047AZ1ST'
            ]

    # ppid in nikon tool
    tmp =list( pd.read_csv(nikonpath).reset_index()['level_0'])
    tmp = [ i.split(".")[0] for i in tmp if '.PRV;' in i ]
    nikonPpid = tmp.copy()

      
       
    #ppid to be processed
    to_be_copy1 =set( wipPart) - set( nikonPpid)
    to_be_delete1 = set(nikonPpid) - set(wipPart)

    to_be_copy=[]
    
    for tmp in to_be_copy1:
        if tmp in list1:
            to_be_copy.append(tmp)
    to_be_copy.sort()


    to_be_delete=[]
    for tmp in to_be_delete1:
        if tmp not in no_delete:
            to_be_delete.append(tmp)
    to_be_delete.sort()




    filestr1 = 'Z:\\_DailyCheck\\NikonRecipeMaintain\\' + nikonpath[-10:-4] + '_put.ftp'
    filestr2 = 'Z:\\_DailyCheck\\NikonRecipeMaintain\\' + nikonpath[-10:-4] + '_delete.ftp'
    filestr3 = 'Z:\\_DailyCheck\\NikonRecipeMaintain\\' + nikonpath[-10:-4] + '_bak.ftp'
    
    filestr1 = 'P:\\SEQLOG\\FTP\\' + nikonpath[-10:-4] + '_put.ftp'
    filestr2 = 'P:\\SEQLOG\\FTP\\' + nikonpath[-10:-4] + '_delete.ftp'
    filestr3 = 'P:\\SEQLOG\\FTP\\' + nikonpath[-10:-4] + '_bak.ftp'   
    
    
    
    
    
    try:
        os.remove(filestr1)
    except:
        pass
    
    try:
        os.remove(filestr2)
    except:
        pass
    
    try:
        os.remove(filestr3)
    except:
        pass    




    ftp = open(filestr1,'a')
    if  nikonpath[23:25]=='22' or nikonpath[23:25]=='23':
        ftp.write('lcd  dka300:[mcsvuser.user]\n')
        ftp.write('set def dka100:[mcsvuser.user]\nbin\n')
    else:
        ftp.write('lcd  dka300:[mcsvuser.user]\n')
        ftp.write('set def dka300:[mcsvuser.user]\nbin\n')
        
 
    if nikonpath[23:25]=='22' or nikonpath[23:25]=='23':
        for name in to_be_copy:
            ftp.write('put ' + name + '.prv\n')
    else:
        for name in to_be_copy:
             ftp.write('put ' + name + '.prv\n')                
    ftp.write('bye\n')    
    ftp.close()
    
 
    
    
    ftp = open(filestr3,'a')
    if  nikonpath[23:25]=='22' or nikonpath[23:25]=='23':
        ftp.write('lcd  dka300:[mcsvuser.user]\n')
        ftp.write('set def dka100:[bak]\nbin\n')
    else:
        ftp.write('lcd  dka300:[mcsvuser.user]\n')
        ftp.write('set def dka300:[bak]\nbin\n')
        
 
    if nikonpath[23:25]=='22' or nikonpath[23:25]=='23':
        for name in to_be_copy:
            ftp.write('put ' + name + '.prv\n')
    else:
        for name in to_be_copy:
             ftp.write('put ' + name + '.prv\n')                
    ftp.write('bye\n')    
    ftp.close()   
    
    
    
    
    
    
    
    
    
            
    
    ftp = open(filestr2,'a')
    if nikonpath[23:25]=='22' or nikonpath[23:25]=='23':
        ftp.write('set def dka100:[mcsvuser.user]\nbin\n')
    else:
        ftp.write('set def dka300:[mcsvuser.user]\nbin\n')
        

        
    if nikonpath[23:25]=='22' or nikonpath[23:25]=='23':
        for name in to_be_delete:
            ftp.write('delete ' + name + '.prv;*\n')
    else:
        for name in to_be_delete:
            ftp.write('delete ' + name + '.prv;*\n')
    ftp.write('bye\n')
    ftp.close()





















def NikonRecipeMaintain():

    
    tmp =str( datetime.datetime.now())
    wipPath = r'D:\HuangWeiScript\PyTaskCode\R2R_New_Part.xlsm'
    
    
    mfgPath = '\\\\10.4.50.16\\fab2文件库\\F2_PUBLIC\\Daily meeting\\'
    mfgPath = mfgPath + tmp[0:4] + '年生产会议\\'
    mfgPath = mfgPath + tmp[0:4]  + "." + tmp[5:7] + '\\backlog' 
    mfgPath = mfgPath + tmp[5:7] + tmp[8:10] + '.xls'
    
    
    
    
    
    
    # bank,wip,backlog==>part
    tmp1 = pd.read_excel(wipPath,sheet_name="WIP",usecols =[ 26])
    tmp1 = set ( [ i.split('.')[0] for i in list ( tmp1['Part']) ])    
    try:
        tmp2 = pd.read_excel(mfgPath,sheet_name="Backlog",usecols=[2],skiprows=[0])
        tmp2 = set ( list ( tmp2['PART']) )        
    except:
        tmp2 = tmp1.copy()
        

    
    part = tmp1|tmp2  
    wipPart =  [ i for i in part ]
    
    
    ## list all PartID and Nikon PPID
    tmp = pd.read_excel(wipPath,sheet_name="WIP",usecols =[ 29,30 ]).dropna().drop_duplicates()
    list1 = list(tmp['Y'])
    dic = {k:v for k,v in zip(list(tmp['X']),list(tmp['Y']))}
    
    
    # conver wip part name to nikon ppid(process)
    for n ,tmp in enumerate(wipPart):    
        try:
           if tmp != dic[tmp]:
               wipPart[n] =  dic[tmp]
               print(tmp,wipPart[n])
        except:
            pass
    
    
    toollist = ['ALII01','ALII02','ALII03','ALII04','ALII05','ALII06','ALII07','ALII08','ALII09',
                'ALII10','ALII11','ALII12','ALII13','ALII14','ALII15','ALII16','ALII17','ALII18',
                'ALII19','ALII20','ALII21','ALII22','ALII23']
    
    
    
    
    for nikonpath in toollist:
        nikonpath = 'P:\\Nikondir\\' + nikonpath + '.TXT'
        try:
            generate_ftp(nikonpath,wipPart,list1)
        except:
            pass 
    


if __name__ == '__main__':
    try:
        NikonRecipeMaintain()
        tmp = open(r'C:\anaconda3\log.txt','a')
        tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___013-NikonRecipeMaintain Done\n")
        tmp.close()
    except:
        tmp = open(r'C:\anaconda3\log.txt','a')
        tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___013-NikonRecipeMaintain Failed\n")
        tmp.close()


























'''

方法一：
list1 = ['k1','k2','k3']
list2 = ['v1','v2','v3']
dic = dict(map(lambda x,y:[x,y],list1,list2))

>>> print(dic)
{'k3': 'v3', 'k2': 'v2', 'k1': 'v1'}

方法二：
>>> dict(zip(list1,list2))
{'k3': 'v3', 'k2': 'v2', 'k1': 'v1'}
'''

