# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Apr 27 12:38:02 2018

@author: HUANGWEI45


"""

def hold_par():

    employeeId = (11067402,20546313,20934636	,11067305	,
                  20570125	,11065552	,11066347	,20785358	,
                  20082601	,20972339	,20465486	,11067475	,11068246	,
                  20934644	,20590158	,20507725	,20068437	,20740048	,11067846	,
                  11068114	,20084824	,20217740	,11067223	,11068127	,11068434	,
                  20491831	,11067904	,11065627	,20059603	,20974967	,20480780,21035183,
                  20128671,20128633,	21005745,21023923)
    
    employeeId = [ str(i) for i in employeeId]
    
    employeeName = ('陈辉',	'董辉',	'高士龙',	'黄玮','李建国',	'李万全',	'潘宇航',	
                    '钱韦华',	'宋方明',	'肖杰','颜亚朋',	'赵娟',	'周朋',	'闫稳',	
                    '瞿倩',	'陈云',	'洪亮',	'黄发彬',	'李平贵',	'李燕',	'李玉华',	
                    '刘吉胜',	'任钰',	'邵康',	'孙巍巍',	'孙伟',	'王大健',	'王亚超',	
                    '王燕',	'王志刚',	'岳新春','吴庭溪','朱福生','朱龙飞','倪灵','张基智')
    

    
    name ={'11067402':'ChenHui', '20546313':'DongHui', '20934636':'GaoSL', 
       '11067305':'HuangWei', '20570125':'LiJG', '11065552':'LiWQ',
       '21005745':'NiL', '11066347':'PanYH', '20785358':'QianWH',
       '20082601':'SongFM', '20972339':'XiaoJ', '21023923':'ZhangJZ', 
       '11067475':'ZhaoJuan', '11068246':'ZhouPeng', '20934644':'YanWen', 
       '20590158':'QuQian', '20068437':'HongLiang', '20740048':'HuangFB',
       '21057480':'HuangCL', '11067846':'LiPG', '11068114':'LiYan', 
       '20084824':'LiYH', '20217740':'LiuJS', '11067223':'RenYu',
       '11068127':'ShaoKang', '11068434':'SunWW', '20491831':'SunWei',
       '11067904':'WangDJ', '11065627':'WangYC', '20059603':'WangYan',
       '11067071':'WangYP', '20974967':'WangZG', '21035183':'WuTX',
       '21057465':'YeBing', '20480780':'YueXC', '20128671':'ZhuFS', '20128633':'ZhuLF'}



    
    PE= ['ChenH', 'ChenY', 'DongH', 'GaoSL',  'HuangFB', 'LiPG','PanYH', 'QianWH', 'QuQ', 'ShaoK','SunW', 'WangYC', 'YanW',  'ZhaoJ', 'ZhouP']
    
    AE = [ 'HongL',  'LiJG', 'LiWQ', 'LiuJS','SongFM', 'WangDJ', 'WangY',  'XiaoJ', 'YanYP', 'YueXC','PanYH']
    
    return employeeId,employeeName,name,PE,AE


 
name ={
    '20128671':'朱福生',
    '21023923':'张基智',
    '21005745':'倪灵',
    '20128633':'朱龙飞',
    '21035183':'吴庭溪',    
    '11067402':'陈辉',
    '20546313':'董辉',
    '20934636':'高士龙',
    '11067305'	:'黄玮',
    '20570125'	:'李建国',
    '11065552'	:'李万全',
    '11066347'	:'潘宇航',
    '20785358'	:'钱韦华',
    '20082601'	:'宋方明',
    '20972339':'肖杰',
    '20465486':'颜亚朋',
    '11067475':'赵娟',
    '11068246'	:'周朋',
    '20934644':'闫稳',
    '20590158'	:'瞿倩',
    '20507725'	:'陈云',
    '20068437':'洪亮',
    '20740048'	:'黄发彬',
    '11067846':'李平贵',
    '11068114':'李燕',
    '20084824'	:'玉华',
    '20217740':'刘吉胜',
    '11067223':'任钰',
    '11068127':'邵康',
    '11068434':'孙巍巍',
    '20491831':'孙伟',
    '11067904':'王大健',
    '11065627':'王亚超',
    '20059603':'王燕',
    '20974967':'王志刚',
    '20480780':'岳新春'}
    



name ={'11067402':'ChenHui', '20546313':'DongHui', '20934636':'GaoSL', 
       '11067305':'HuangWei', '20570125':'LiJG', '11065552':'LiWQ',
       '21005745':'NiL', '11066347':'PanYH', '20785358':'QianWH',
       '20082601':'SongFM', '20972339':'XiaoJ', '21023923':'ZhangJZ', 
       '11067475':'ZhaoJuan', '11068246':'ZhouPeng', '20934644':'YanWen', 
       '20590158':'QuQian', '20068437':'HongLiang', '20740048':'HuangFB',
       '21057480':'HuangCL', '11067846':'LiPG', '11068114':'LiYan', 
       '20084824':'LiYH', '20217740':'LiuJS', '11067223':'RenYu',
       '11068127':'ShaoKang', '11068434':'SunWW', '20491831':'SunWei',
       '11067904':'WangDJ', '11065627':'WangYC', '20059603':'WangYan',
       '11067071':'WangYP', '20974967':'WangZG', '21035183':'WuTX',
       '21057465':'YeBing', '20480780':'YueXC', '20128671':'ZhuFS', '20128633':'ZhuLF'}






















import win32com.client
import datetime
import pandas as pd
#import xlwings as xw
import gc
import matplotlib.pyplot as plt



'''
>>> sht = xw.Book().sheets[0]
>>> sht.range('A1').value = [[1,2], [3,4]]
>>> rng1 = sht.range('A1').expand('table')  # or just .expand()
>>> rng2 = sht.range('A1').options(expand='table')
>>> rng1.value
[[1.0, 2.0], [3.0, 4.0]]
>>> rng2.value
[[1.0, 2.0], [3.0, 4.0]]
>>> sht.range('A3').value = [5, 6]
>>> rng1.value
[[1.0, 2.0], [3.0, 4.0]]
>>> rng2.value
[[1.0, 2.0], [3.0, 4.0], [5.0, 6.0]]

'''


def extract_data(sql ):
    employeeId,employeeName,name,PE,AE=hold_par()


    databasepath = r'Y:\Hold\HOLD.mdb'               
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)
    
    rs = win32com.client.Dispatch(r'ADODB.Recordset')
    rs.Open(sql, conn, 1, 3)  
    rs.movefirst      

    df = []
    
    while True:
        tmp=[]
        if rs.EOF:
            break
        else:
            for j in range( rs.fields.count ):
                tmp.append ( str(rs.fields.item(j).value))
        df.append(tmp)

            
        rs.MoveNext()
    rs.close
    conn.close
    
    return df




def update_excel_data_xw( path = r'Y:\Hold\hold.xlsm',  databasepath = r'Y:\Hold\HOLD.mdb'  ):
    employeeId,employeeName,name,PE,AE=hold_par()

    # refresh hold data in excel
    filename = r'Y:\Hold\hold.xlsm'
    xlApp = win32com.client.Dispatch('Excel.Application')
    xlApp.visible = 1 # 此行设置打开的Excel表格为可见状态；忽略则Excel表格默认不可见
    xlBook = xlApp.Workbooks.Open(filename)
    strPara = xlBook.Name + '!Holdlothistory()'
    status = xlApp.ExecuteExcel4Macro(strPara)    
    sht = xlBook.sheets('Sheet1')
    
    
    # get latest dta in access database           
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)
    rs_name= 'hold'    
    
       
    rs = win32com.client.Dispatch(r'ADODB.Recordset')    
    sql  = 'select RELEASE_TIME from hold order by RELEASE_TIME DESC'
    rs.Open(sql, conn, 1, 3)
    rs.movefirst
    key = datetime.datetime.strptime (str(rs.fields.item(0).value)[:-6],'%Y-%m-%d %H:%M:%S')
    key1 = str(rs.fields.item(0).value)[:-6]
    key2 = rs.fields.item(0).value
    rs.close    
    
    
    # update database based on RELEASE_TIME
    print ('hold database is being updated................') 
    rs.Open(  rs_name , conn, 1, 3)
    

    for i in range( 2,sht.usedrange.rows.count,1):
        if sht.cells(i,20).value > key2:        
            try:
                tmpname = name[ str(int(sht.cells(i,22).value)) ]
                print(sht.cells(i,20).value, tmpname)                                                
                rs.AddNew()
                for j in range(1,41,1):
                    #print (sht.cells(i,j).value)
                    if j == 16:
                        try:
                            rs.Fields.Item(15).value = sht.cells(i,16).value[0:255].replace('\t','').replace('\n','')
                        except:
                            rs.Fields.Item(15).value = 'No Comment'
                    elif j==22:
                        rs.Fields.Item(21).value = tmpname
                    elif j==17 or j == 20:
                        rs.Fields.Item(j-1).value = str(sht.cells(i,j).value)[:-6]
                            
                    else:
                        rs.Fields.Item(j-1).value = str( sht.cells(i,j).value )
                rs.Update()
    
            except:
                pass
    
  
    conn.close
    xlBook.Save()

    xlBook.Close() # 关闭Excel，并保存更改 
 
 



                    
    




def plot_AE_daily(no=90):
    employeeId,employeeName,name,PE,AE=hold_par()
  


    begin =  str( datetime.datetime.now().date() - datetime.timedelta(days = no) ) + " 07:30:00"  
    end =  str( datetime.datetime.now().date()  ) + " 07:30:00"  
   

    sql = "  SELECT hold.LOT_QTY, hold.RELEASE_TIME,hold.RELEASE_USER, hold.EVENT_TIME \
            FROM hold \
            WHERE (not  (((hold.[HOLD_COMMENTS]) In (  \
            'O.O.C. chart.', \
            'PHPE/PHPE/PHPE/NO NEED ADD MEASURE, WAIT PE MAKE DECISION', \
            'PHPE/PHPE/PHPE/TOOL OR RECIPE OK, NEED PE CHECK WHETHER REMEASURE', \
            'PHPE/PHPE/PHPE/NO NEED REMEASURE, WAIT PE CHECK WHETHER ADD MEASURE', \
            'O.O.S. derived results and O.O.C. chart.', \
            'O.O.S. derived results.' \
            ))))  \
            AND ( (hold.RELEASE_TIME between #" + begin + "# and #" + end + "#) or  \
                (hold.EVENT_TIME between #" + begin + "# and #" + end + "#) ) "
             

      
    df = extract_data(sql )

######## extract data  
    LOT_QTY = []
    RELEASE_TIME = []
    RELEASE_USER =[]
    HOLD_TIME =[]
    
    for i in df:
        LOT_QTY.append( int(eval(i[0])) )
        RELEASE_TIME.append( i[1][0:-6]) #remove time zone i
        RELEASE_USER.append( i[2]) 
        HOLD_TIME.append( i[3][0:-6])    


    df = pd.DataFrame( { 'LOT_QTY':LOT_QTY,
                        'RELEASE_TIME':RELEASE_TIME,
                        'RELEASE_USER': RELEASE_USER,
                        'HOLD_TIME':HOLD_TIME})
###### edit data,
    #moveNew['Week'] = [ (i-delta).strftime("%W") for i in moveNew['TRACKOUTTIME']]
    
    # 7:30 AM ~ next 7:30AM-->one working day
    df['REVISED_TIME'] = [str( datetime.datetime.strptime(i, '%Y-%m-%d %H:%M:%S') - datetime.timedelta(days =7.5/24) )for i in df['RELEASE_TIME'] ]    
    df['Month'] = df['REVISED_TIME'].str[5:7]
    df['Hour'] = df['REVISED_TIME'].str[11:13]
    df['Day'] = df['REVISED_TIME'].str[:10] 
   
    df['REVISED_TIME1'] = [str( datetime.datetime.strptime(i, '%Y-%m-%d %H:%M:%S') - datetime.timedelta(days =7.5/24) )for i in df['HOLD_TIME'] ]        
    df['Month1'] = df['REVISED_TIME1'].str[5:7]
    df['Hour1'] = df['REVISED_TIME1'].str[11:13]
    df['Day1'] = df['REVISED_TIME1'].str[:10] 

    df = df.sort_values(by = 'REVISED_TIME')  




### AE Working load      
    tmp =df [['Day','RELEASE_USER','LOT_QTY']]    
    ref = pd.DataFrame(  df['Day'].unique()  ).reset_index().set_index(0)
    #wb = xw.Book('Y:/hold/workingload.xlsx')
    #sht=wb.sheets('sheet1')
    
    tmp1=[]    
    for i in AE:
        data = tmp[tmp['RELEASE_USER'].str.contains(i)]
        wfr =pd.DataFrame( data['LOT_QTY'].groupby(data['Day']).sum() )
        wfr = pd.concat([wfr, ref], axis=1, join_axes=[ref.index]).fillna(0)
        lot =pd.DataFrame ( data['LOT_QTY'].groupby(data['Day']).count() )
        lot = pd.concat([lot, ref], axis=1, join_axes=[ref.index]).fillna(0)
        
        fig = plt.figure(figsize =(12,4))
        ax1 = fig.add_subplot(1,2,1) 
        ax1 = wfr['LOT_QTY'].plot(kind='bar',color = 'blue')
        ax1.set_title (i + '__Hold_Release Count By Wfr Qty')
        ax1.yaxis.grid(True)
        ax1.set_ylim(0,5000)
        
        ax2 = fig.add_subplot(1,2,2) 
        ax2 = lot['LOT_QTY'].plot(kind='bar',color = 'blue')
        ax2.set_title (i + '__Hold_Release Count By Lot Qty')
        ax2.yaxis.grid(True)
        ax2.set_ylim(0,300)        
    
        #sht.pictures.add(fig, name= i +' Daily Workloading', update=True,
        #                     left=sht.range('A1').left, top=sht.range('A1').top)
        #tmp1.append([i,int( wfr[wfr['LOT_QTY']>0].describe().iloc[0,0]), int(wfr[wfr['LOT_QTY']>0].describe().iloc[1,0]),int(lot[lot['LOT_QTY']>0].describe().iloc[1,0]) ]) 
        
        
        
        
        
        
        # night shift relese lot after 7:30AM, day shift after 19:30 PM-->trigger incorrect data--> better to set lot['LOT_QTY']>5???
        
        plt.clf() # 清图。
        plt.cla() # 清坐标轴。
        plt.close() # 关窗口
        gc.collect()         
       
        
    
        #plt4 = tmp.plot(kind='bar',stacked=True,alpha=0.5,figsize =(10,5),
        #                color = ['black','bisque','lightgreen','rosybrown','gold','seagreen', 'red','olivedrab','blue','purple'] )


    summaryDay = pd.DataFrame({'Name':[i[0] for i in tmp1],
                               'Days':[i[1] for i in tmp1],
                               'LotPerDay': [i[3] for i in tmp1], 
                               'WfrPerDay': [ i[2] for i in tmp1]}).set_index('Name').sort_values(by = 'Days', ascending = False)
    print(summaryDay)
    #sht.range("R1").value = summaryDay    
    #wb.save()
    #wb.close()    

    


###### hold/release breakdown by hour

    tmp =df [['Day','Hour','LOT_QTY']] 
    wfr_release =pd.DataFrame( tmp['LOT_QTY'].groupby([tmp['Day'],tmp['Hour']]).sum() ).reset_index().pivot(index = 'Day',columns = 'Hour',values = 'LOT_QTY').fillna(0)
    lot_release =pd.DataFrame( tmp['LOT_QTY'].groupby([tmp['Day'],tmp['Hour']]).count()).reset_index().pivot(index = 'Day',columns = 'Hour',values = 'LOT_QTY').fillna(0)

    tmp =df.sort_values(by = 'HOLD_TIME')      [['Day1','Hour1','LOT_QTY']]
    tmp.columns = ['Day','Hour','LOT_QTY']
    wfr_hold =pd.DataFrame( tmp['LOT_QTY'].groupby([tmp['Day'],tmp['Hour']]).sum() ).reset_index().pivot(index = 'Day',columns = 'Hour',values = 'LOT_QTY').fillna(0)
    lot_hold =pd.DataFrame( tmp['LOT_QTY'].groupby([tmp['Day'],tmp['Hour']]).count()).reset_index().pivot(index = 'Day',columns = 'Hour',values = 'LOT_QTY').fillna(0)

    wfr_hold = wfr_hold[wfr_release.index[0]:wfr_release.index[-1]]
    lot_hold = lot_hold[lot_release.index[0]:lot_release.index[-1]]
    
    hour_wfr = wfr_release - wfr_hold 
    hour_lot = lot_release - lot_hold 

    timeperiod = ['08:30','09:30','10:30','11:30','12:30','13:30','14:30','15:30','16:30','17:30','18:30','19:30','20:30','21:30','22:30','23:30','0:30','1:30','2:30','3:30','4:30','5:30','6:30','7:30']
    hour_wfr.columns = timeperiod
    hour_lot.columns = timeperiod  
    lot_release.columns = timeperiod
    wfr_release.columns = timeperiod     
    lot_hold.columns = timeperiod
    wfr_hold.columns = timeperiod
    
    
    return summaryDay,wfr_hold,lot_hold,wfr_release,lot_release,hour_wfr,hour_lot
    
    

 




def update_excel_data_xw_new():

    oldpath = r'Y:\Hold\hold.csv'
    newpath = r'Y:\Hold\hold_auto.xlsm'
    
    print('Reading Latest Data.........')
    
    new = pd.read_excel(newpath,encoding='GBK')
    #new['RELEASE_TIME'] = pd.to_datetime(new['RELEASE_TIME'])
    #new['EVENT_TIME'] = pd.to_datetime(new['EVENT_TIME'])
  
    old = pd.read_csv(oldpath,encoding='GBK')
    #old = pd.read_excel(r'Y:\Hold\hold.xlsm',encoding='GBK')
    #old.to_csv('y:/hold/hold.csv',encoding='GBK',index=None)
    print('Reading History Data.........')    
    
    old['RELEASE_TIME'] = pd.to_datetime(old['RELEASE_TIME'])
    old['EVENT_TIME'] = pd.to_datetime(old['EVENT_TIME'])
    #old['QUEUE_TIME'] = pd.to_datetime(old['QUEUE_TIME'])
    #old['PREV_HIST_TIME'] = pd.to_datetime(old['PREV_HIST_TIME'])    


    tmptime = list(old['RELEASE_TIME'])[-1]
    
    print('The Latest History Date is %s'%(str(tmptime)))

#===================================================================
#in case RELEASE_TIME of several lots is identical 

    old_1 =set( old [old['RELEASE_TIME'] == tmptime]['EVENT_TIME'] )
    new_1 =set( new [new['RELEASE_TIME'] == tmptime]['EVENT_TIME'] )
    new_1 = new_1 - old_1
    
    newtmp =  new [new['RELEASE_TIME'] == tmptime]
    if len(new_1)>0:
        for i in list(new_1):            
            newtmp[newtmp['EVENT_TIME']==i].to_csv('y:/hold/hold.csv',index=None,encoding='GBK',header=None,mode='a')
    #==================================================
    
    newtmp =  new [new['RELEASE_TIME'] > tmptime]
    if newtmp.shape[0]>0:
        newtmp.to_csv('y:/hold/hold.csv',index=None,encoding='GBK',header=None,mode='a')
    print(' %s ROWS ARE APPENDED'%(str(newtmp.shape[0])))
    










    

   
    

    
    
    


'''  
       def excell_to_csv(excell_file_path, date_time_index=[], skiprows=0, format="%Y/%m/%d %H:%M:%S"):
        """

        :param excell_file_path: excell文件路径，处理完成之后会在excell文件的路径下，生成以asv结尾的csv文件
        :param date_time_index: 需要处理的时间日期所在的列
        :param skiprows: 从第几行开始处理，默认不带字段名，如果有字段名，这skiprows=1，自动跳过第一行
        :param format: excell文件里面日期的格式
        :return:
        """
        # headre=None，读取excell文件，认为excell文件里面第一行不是字段名
        excell_dataframe = pd.read_excel(excell_file_path, header=None, skiprows=skiprows)
        print(excell_dataframe)
        for index in date_time_index:
            # 遇到日期中有不是标准格式的日期，两种解决办法：1.errors="coerce"，2.infer_datetime_format=True 两种方法都会把非标准日期，转换为空
            excell_dataframe[index] = pd.to_datetime(excell_dataframe[index], format=format, errors="coerce")
            # excell_dataframe[index] = pd.to_datetime(excell_dataframe[index], infer_datetime_format=True)
        # 利用正则，把每个字段里面的换行调换掉
        excell_dataframe = excell_dataframe.replace(to_replace=r"\n", value="", regex=True).replace(to_replace=r"\r", value="", regex=True).replace(to_replace=r"\r\n", value="", regex=True)
        # 把读取的dataframe数据生成csv，index=False，不要行索引，header=None不要列名，sep="\001"以ascall1作为csv文件分隔符（此时在linux下，vi打开asv文件可以看到分隔符），分隔符可以自定义
        excell_dataframe.to_csv("{}".format(excell_file_path.replace(".xlsx",".asv").replace(".xls", ".asv")), index=False, header=None, encoding='utf-8', sep='\001')
    if __name__ == '__main__':
        excell_to_csv('cc_complaint.xls', date_time_index=[1, 2], skiprows=1)

---------------------
作者：weixin_41734687 
来源：CSDN 
原文：https://blog.csdn.net/weixin_41734687/article/details/82432769?utm_source=copy 
版权声明：本文为博主原创文章，转载请附上博文链接！
    
'''




          



 
 









     
if __name__ == "__main__":

#run_xls_macro()
    try:
        #update_excel_data_xw_new( path =r'Y:\Hold\hold.xlsm',  databasepath = r'Y:\Hold\HOLD.mdb'  )
        update_excel_data_xw_new()
        tmp = open(r'C:\anaconda3\log.txt','a')
        tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___014-Hold Done\n")
        tmp.close()
    except:
       
        tmp = open(r'C:\anaconda3\log.txt','a')
        tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___014-Hold Failed\n")
        tmp.close()        

#data = plot_AE_daily(no=90) 











