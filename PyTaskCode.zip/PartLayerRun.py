# -*- coding: utf-8 -*-
"""
# encoding = 'GB2312' ,encoding='GBK' 
Created on Tue Apr 10 13:06:05 2018

@author: HUANGWEI45
"""

#import matplotlib.pyplot as plt
#from bs4 import BeautifulSoup
import pandas as pd
#import os
#import numpy as np
#import xlwings as xw


import win32com.client
#import pytz
#import datetime
#import gc
import datetime

def part_layer_list_001(): #part/layer not processed
    
    
    databasepath = r'Y:\New_Flow\NewFlow.mdb'    
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)  
    rs = win32com.client.Dispatch(r'ADODB.Recordset')

   
    sql =  "SELECT Key, PartVer,Stage,PPID FROM FlowStage  WHERE Flag1=0"
    rs.Open(sql, conn, 1, 3)    
    rs.MoveFirst()  #光标移到首条记录
    
    
    list1 = []
    rs.MoveFirst()

    while True:
        if rs.EOF:
            break
        else:
            
            list1.append( [ rs.Fields[i].Value for i in range(rs.Fields.count) ])

        rs.MoveNext()
            
    rs.close
    conn.close
    
    list1 = pd.DataFrame(list1,columns = ['Key','PartID','Stage','PPID'])
    list1['PartID'] = list1['PartID'].str[:-3]
    

    return list1




def part_layer_list_002(): #move
    
    
    databasepath = r'Y:\ERRC_RWK_MOVE\RwkMoveOcap.mdb'    
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)  
    rs = win32com.client.Dispatch(r'ADODB.Recordset')

   
    sql =  "SELECT PARTNAME, STAGE,PPID FROM MOVE WHERE Day > #2018-01-01# "
    rs.Open(sql, conn, 1, 3)    
    rs.MoveFirst()  #光标移到首条记录
    
    
    list2 = []
    rs.MoveFirst()

    while True:
        if rs.EOF:
            break
        else:
            
            list2.append( [ rs.Fields[i].Value for i in range(rs.Fields.count) ])

        rs.MoveNext()
            
    rs.close
    conn.close
    
    list2 = pd.DataFrame(list2,columns = ['PartID','Stage','PPID'])
  
    

    return list2


def part_layer_list_003(): # part/layer processed
    list1 = part_layer_list_001()
    list2 = part_layer_list_002()
    df = pd.merge(list1,list2,on = ['PartID','Stage','PPID']).drop_duplicates()
    return df





def update_flag1():
    df = part_layer_list_003()
    databasepath = r'Y:\New_Flow\NewFlow.mdb'    
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)  
    rs = win32com.client.Dispatch(r'ADODB.Recordset')
    
   
    #sql =  "SELECT Key, PartVer,Stage,PPID FROM FlowStage  WHERE Flag1=0"
    rs.Open('FlowStage', conn, 1, 3)    
    
    if df.shape[0] > 0:
        for i in list(df['Key']):
            sql = "UPDATE FlowStage SET Flag1=1 where Key=" + str(i)
            conn.Execute (sql)
    rs.close
    conn.close

if __name__ == "__main__":
    try:
        update_flag1()
        
        tmp = open(r'D:\HuangWeiScript\PyTaskCode\pythonlog.txt','a')
        tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___015-PartLayerRun Done\n")
        tmp.close()
    except:
        tmp = open(r'D:\HuangWeiScript\PyTaskCode\pythonlog.txt','a')
        tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___015-PartLayerRun Failed\n")
        tmp.close()





