# -*- coding: utf-8 -*-
"""
# encoding = 'GB2312' ,encoding='GBK' 
Created on Tue Apr 10 13:06:05 2018

@author: HUANGWEI45

Extract data from p:/database/data.mdb
plot OVL Trend
"""


import matplotlib.pyplot as plt
import pandas as pd
import win32com.client
import datetime
import gc



def extract_data():
    n = 25 #define time period for data extraction
    databasepath = r'Z:\_DailyCheck\Database\data.mdb'  
    
    
    enddate = datetime.datetime.now().date()
    startdate = enddate - datetime.timedelta(days=n)
    
        
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)  
    rs = win32com.client.Dispatch(r'ADODB.Recordset')
    
    
    sql = "SELECT * FROM OL_ASML WHERE (Dcoll_Time>#" + str(startdate) + "#) ORDER BY Dcoll_Time"
    sql = "SELECT  \
          Proc_EqID, Dcoll_Time, \
          TranX_Optimum, TranY_Optimum,  ScalX_Optimum, ScalY_Optimum, \
          ORT_Optimum,  Wrot_Optimum, Mag_Optimum, Rot_Optimum,  ARMag_Optimum, ARRot_Optimum, \
          Tech,Layer \
          FROM OL_ASML WHERE (Dcoll_Time>#" + str(startdate) + "#) ORDER BY Dcoll_Time"
    
    
    rs.Open(sql, conn, 1, 3)
    
    
    
    asml = []
    rs.MoveFirst()
    
    while True:
        if rs.EOF:
            break
        else:       
            asml.append ([rs.Fields.Item(i).Value for i in range( rs.Fields.Count)] )
            rs.MoveNext()
    
    rs.close
    asml = pd.DataFrame(asml)
    
    sql = "SELECT * FROM OL_NIKON WHERE (Dcoll_Time>#" + str(startdate) + "#) ORDER BY Dcoll_Time"        
    sql = "SELECT  \
          Proc_EqID, Dcoll_Time, \
          OffsetX_Optimum, OffsetY_Optimum, ScalX_Optimum , ScalY_Optimum, \
          ORT_Optimum, Wrot_Optimum , Mag_Optimum , Rot_Optimum, Mag_Optimum , Rot_Optimum, \
          Tech, Layer \
          FROM OL_NIKON WHERE (Dcoll_Time>#" + str(startdate) + "#) ORDER BY Dcoll_Time"        
    rs.Open(sql, conn, 1, 3) 
    
    nikon = []
    rs.MoveFirst()
    while True:
        if rs.EOF:
            break
        else:        
            nikon.append ([rs.Fields.Item(i).Value for i in range( rs.Fields.Count)] )
            rs.MoveNext()
    rs.close
    nikon = pd.DataFrame(nikon)
    
    conn.close
    
    return asml, nikon














def optvalue(asml,nikon):
    df = pd.concat([asml,nikon],axis=0).fillna(0)
    df[1] = [ datetime.datetime.strptime (str(i)[0:-6],'%Y-%m-%d %H:%M:%S') for i in df[1]]    
    
    df = df.reset_index().set_index(1)

    toollist = ('ALDI02', 'ALDI03', 'ALDI05', 'ALDI06', 'ALDI07', 'ALDI09', 'ALDI10', 'ALDI11', 'ALDI12', 'BLDI08', 'BLDI13',
           'ALII01','ALII02', 'ALII03', 'ALII04', 'ALII05', 'ALII10', 'ALII11','ALII12', 'ALII13', 'ALII14', 'ALII15', 'ALII16', 'ALII17',
                'ALII18', 'ALSIB6', 'ALSIB7', 'ALSIB8', 'ALSIB9', 'ALSIBJ', 'BLSIBK', 'BLSIBL', 'BLSIE1','BLSIE2')
            
                 
                 
 

       
           
    #wb = xw.Book(r'p:\RoutineWork\ScriptSaving.xlsx')    
    #sht = wb.sheets["OvlOpt"]          


    for i, tool in enumerate(toollist): 
        #print(i,"  ",toollist)

        #df = df.sort(['Dcoll Time'] , ascending=True)
        
        print ( tool + ' is being updated......')
        
        tmp = df[df[0] == tool]
        if tmp.shape[0] > 0:
            
            if i < 11:
        
                fig = plt.figure(figsize = (20,16))
                
        
                ax1 = plt.subplot(521) 
                #tmp[2].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                tmp[2].plot(marker='o',linestyle=':',color='r',legend=False)#linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)        
                plt.ylim(-0.1,0.1)
                plt.title( tool + '  ' + "Optimum Tran-X")
                ax1.yaxis.grid(True)
                ax1.xaxis.grid(True)
                plt.ylim(-0.04,0.04)
             
                
                
                
                ax2 = plt.subplot(522) 
                #tmp[3].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                tmp[3].plot(marker='o',linestyle=':',color='r',legend=False)
                ax2.yaxis.grid(True)
                ax2.xaxis.grid(True)        
                plt.title( tool + '  ' + "Optimum Tran-Y")
                plt.ylim(-0.04,0.04)       
                
                ax3 = plt.subplot(523) 
                #tmp[4].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                tmp[4].plot(marker='o',linestyle=':',color='r',legend=False)
                plt.title( tool + '  ' + 'W.Expan.X_Optimum')
                ax3.yaxis.grid(True)
                ax3.xaxis.grid(True)
                plt.ylim(-0.5,0.5)
                
                ax4 = plt.subplot(524) 
                #tmp[5].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                tmp[5].plot(marker='o',linestyle=':',color='r',legend=False)
        
                plt.title( tool + '  ' + 'W.Expan.Y_Optimum')
                ax4.yaxis.grid(True)
                ax4.xaxis.grid(True)
                plt.ylim(-0.5,0.5)
                
                ax5 = plt.subplot(525) 
                #tmp[6].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                tmp[6].plot(marker='o',linestyle=':',color='r',legend=False)
                plt.title( tool + '  ' + 'NonOrtho_Optimum')
                ax5.yaxis.grid(True)
                ax5.xaxis.grid(True)
                plt.ylim(-0.5,0.5)       
                
                ax6 = plt.subplot(526) 
                #tmp[7].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                tmp[7].plot(marker='o',linestyle=':',color='r',legend=False)
                ax6.yaxis.grid(True)
                ax6.xaxis.grid(True)
                plt.title( tool + '  ' + 'W.Rotation_Optimum')
                plt.ylim(-0.5,0.5)        
                
                ax7 = plt.subplot(527) 
                #tmp[8].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                tmp[8].plot(marker='o',linestyle=':',color='r',legend=False)
                ax7.yaxis.grid(True)
                ax7.xaxis.grid(True)  
                plt.title( tool + '  ' + 'Shot Magnification_Optimum')
                plt.ylim(-3,3)        
                
                ax8 = plt.subplot(528)
                 
                #tmp[9].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                tmp[9].plot(marker='o',linestyle=':',color='r',legend=False)
                ax8.yaxis.grid(True)
                ax8.xaxis.grid(True)             
                plt.title( tool + '  ' + 'Shot Rotation_Optimum')
                plt.ylim(-3,3)         
                
                ax9 = plt.subplot(529) 
                #tmp[10].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                tmp[10].plot(marker='o',linestyle=':',color='r',legend=False)
                ax9.yaxis.grid(True)
                ax9.xaxis.grid(True)              
                plt.title( tool + '  ' + 'Shot AsymMag_Optimum')
                plt.ylim(-3,3)        
                
                ax10 = plt.subplot(5,2,10)
     
                #tmp[11].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                tmp[11].plot(marker='o',linestyle=':',color='r',legend=False)
                ax10.yaxis.grid(True)
                ax10.xaxis.grid(True)                     
                plt.title( tool + '  ' + 'Shot AsymRot_Optimum')
                plt.ylim(-3,3) 
                
                fig.subplots_adjust(hspace=0.5)
                
                plt.savefig('z:\\_DailyCheck\\OptOvl_Others\\OvlPicture\\' + tool ,dpi=100, bbox_inches='tight')
                
                #sht.pictures.add(fig, name=(tool + '_Optimum Value'), update=True,
                #                 left=sht.range('A2').left, top=sht.range('A2').top)
                        
        
                plt.clf() # 清图。
                plt.cla() # 清坐标轴。
                plt.close() # 关窗口
                gc.collect() 
                
            else:
                bak = tmp.copy() 
                 
                t1 = tmp [ tmp[12].str.contains("1") | tmp[12].str.contains("25") | tmp[12].str.contains("52") ]
                t1 = t1 [t1[13].str.contains("PT") | t1[13].str.contains("TB") | t1[13].str.contains("HV") | \
                         t1[13].str.contains("NX") | t1[13].str.contains("PX") | t1[13].str.contains("DN") | \
                         t1[13].str.contains("DP")]
                
                t2 = tmp [ tmp[13].str.contains("A1") | tmp[13].str.contains("A2") | tmp[13].str.contains("AT") | tmp[13].str.contains("TT") | \
                           tmp[13].str.contains("W1") |  tmp[13].str.contains("W2") |  tmp[13].str.contains("WT") |tmp[13].str.contains("CT")  ]
         
                tmp = pd.concat([t1,t2],axis = 0).sort_index() 

                if tmp.shape[0] > 0:
                    fig = plt.figure(figsize = (20,16))
                    
            
                    ax1 = plt.subplot(421) 
                    #tmp[2].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                    tmp[2].plot(marker='o',linestyle=':',color='r',legend=False)#linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)        
                    plt.ylim(-0.1,0.1)
                    plt.title( tool + '  ' + "Optimum Tran-X")
                    ax1.yaxis.grid(True)
                    ax1.xaxis.grid(True)
                    if i<11:
                        plt.ylim(-0.04,0.04)
                    else:
                        plt.ylim(-0.08,0.08)
                    
                    
                    
                    ax2 = plt.subplot(422) 
                    #tmp[3].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                    tmp[3].plot(marker='o',linestyle=':',color='r',legend=False)
                    ax2.yaxis.grid(True)
                    ax2.xaxis.grid(True)        
                    plt.title( tool + '  ' + "Optimum Tran-Y")
                    if i<11:
                        plt.ylim(-0.04,0.04)
                    else:
                        plt.ylim(-0.08,0.08)        
                    
                    ax3 = plt.subplot(423) 
                    #tmp[4].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                    tmp[4].plot(marker='o',linestyle=':',color='r',legend=False)
                    plt.title( tool + '  ' + 'W.Expan.X_Optimum')
                    ax3.yaxis.grid(True)
                    ax3.xaxis.grid(True)
                    if i<11:
                        plt.ylim(-0.6,0.6)
                    else:
                        plt.ylim(-1,1)
                    
                    ax4 = plt.subplot(424) 
                    #tmp[5].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                    tmp[5].plot(marker='o',linestyle=':',color='r',legend=False)
            
                    plt.title( tool + '  ' + 'W.Expan.Y_Optimum')
                    ax4.yaxis.grid(True)
                    ax4.xaxis.grid(True)
                    if i<11:
                        plt.ylim(-0.6,0.6)
                    else:
                        plt.ylim(-1,1)
                    
                    ax5 = plt.subplot(425) 
                    #tmp[6].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                    tmp[6].plot(marker='o',linestyle=':',color='r',legend=False)
                    plt.title( tool + '  ' + 'NonOrtho_Optimum')
                    ax5.yaxis.grid(True)
                    ax5.xaxis.grid(True)
                    if i<11:
                        plt.ylim(-0.6,0.6)
                    else:
                        plt.ylim(-1,1)        
                    
                    ax6 = plt.subplot(426) 
                    #tmp[7].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                    tmp[7].plot(marker='o',linestyle=':',color='r',legend=False)
                    ax6.yaxis.grid(True)
                    ax6.xaxis.grid(True)
                    plt.title( tool + '  ' + 'W.Rotation_Optimum')
                    if i<11:
                        plt.ylim(-0.6,0.6)
                    else:
                        plt.ylim(-1,1)         
                    
                    ax7 = plt.subplot(427) 
                    #tmp[8].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                    tmp[8].plot(marker='o',linestyle=':',color='r',legend=False)
                    ax7.yaxis.grid(True)
                    ax7.xaxis.grid(True)  
                    plt.title( tool + '  ' + 'Shot Magnification_Optimum')
                    if i<11:
                        plt.ylim(-3,3)
                    else:
                        plt.ylim(-6,6)         
                    
                    ax8 = plt.subplot(428)
                     
                    #tmp[9].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                    tmp[9].plot(marker='o',linestyle=':',color='r',legend=False)
                    ax8.yaxis.grid(True)
                    ax8.xaxis.grid(True)             
                    plt.title( tool + '  ' + 'Shot Rotation_Optimum')
                    if i<11:
                        plt.ylim(-3,3)
                    else:
                        plt.ylim(-6,6)         
                    fig.subplots_adjust(hspace=0.5)
                    
                    plt.savefig('z:\\_DailyCheck\\OptOvl_Others\\OvlPicture\\FIA_' + tool ,dpi=100, bbox_inches='tight')
                    
                    #sht.pictures.add(fig, name=(tool + '_Optimum Value'), update=True,
                    #                 left=sht.range('A2').left, top=sht.range('A2').top)
                            
            
                    plt.clf() # 清图。
                    plt.cla() # 清坐标轴。
                    plt.close() # 关窗口
                    gc.collect()
                    
                print (i,',   ',tool,',   ',len( set(bak.index) -set(tmp.index) ))
                
                if len( set(bak.index) -set(tmp.index) ) > 0:
                    tmp = bak.loc [list( set(bak.index) -set(tmp.index) )]
                    tmp = tmp.sort_index() 
                #if tmp.shape[0] > 0:
                    fig = plt.figure(figsize = (20,16))
                    
            
                    ax1 = plt.subplot(421) 
                    #tmp[2].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                    tmp[2].plot(marker='o',linestyle=':',color='r',legend=False)#linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)        
                    plt.ylim(-0.1,0.1)
                    plt.title( tool + '  ' + "Optimum Tran-X")
                    ax1.yaxis.grid(True)
                    ax1.xaxis.grid(True)
                    if i<11:
                        plt.ylim(-0.04,0.04)
                    else:
                        plt.ylim(-0.08,0.08)
                    
                    
                    
                    ax2 = plt.subplot(422) 
                    #tmp[3].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                    tmp[3].plot(marker='o',linestyle=':',color='r',legend=False)
                    ax2.yaxis.grid(True)
                    ax2.xaxis.grid(True)        
                    plt.title( tool + '  ' + "Optimum Tran-Y")
                    if i<11:
                        plt.ylim(-0.04,0.04)
                    else:
                        plt.ylim(-0.08,0.08)        
                    
                    ax3 = plt.subplot(423) 
                    #tmp[4].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                    tmp[4].plot(marker='o',linestyle=':',color='r',legend=False)
                    plt.title( tool + '  ' + 'W.Expan.X_Optimum')
                    ax3.yaxis.grid(True)
                    ax3.xaxis.grid(True)
                    if i<11:
                        plt.ylim(-0.6,0.6)
                    else:
                        plt.ylim(-1,1)
                    
                    ax4 = plt.subplot(424) 
                    #tmp[5].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                    tmp[5].plot(marker='o',linestyle=':',color='r',legend=False)
            
                    plt.title( tool + '  ' + 'W.Expan.Y_Optimum')
                    ax4.yaxis.grid(True)
                    ax4.xaxis.grid(True)
                    if i<11:
                        plt.ylim(-0.6,0.6)
                    else:
                        plt.ylim(-1,1)
                    
                    ax5 = plt.subplot(425) 
                    #tmp[6].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                    tmp[6].plot(marker='o',linestyle=':',color='r',legend=False)
                    plt.title( tool + '  ' + 'NonOrtho_Optimum')
                    ax5.yaxis.grid(True)
                    ax5.xaxis.grid(True)
                    if i<11:
                        plt.ylim(-0.6,0.6)
                    else:
                        plt.ylim(-1,1)        
                    
                    ax6 = plt.subplot(426) 
                    #tmp[7].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                    tmp[7].plot(marker='o',linestyle=':',color='r',legend=False)
                    ax6.yaxis.grid(True)
                    ax6.xaxis.grid(True)
                    plt.title( tool + '  ' + 'W.Rotation_Optimum')
                    if i<11:
                        plt.ylim(-0.6,0.6)
                    else:
                        plt.ylim(-1,1)         
                    
                    ax7 = plt.subplot(427) 
                    #tmp[8].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                    tmp[8].plot(marker='o',linestyle=':',color='r',legend=False)
                    ax7.yaxis.grid(True)
                    ax7.xaxis.grid(True)  
                    plt.title( tool + '  ' + 'Shot Magnification_Optimum')
                    if i<11:
                        plt.ylim(-3,3)
                    else:
                        plt.ylim(-6,6)         
                    
                    ax8 = plt.subplot(428)
                     
                    #tmp[9].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
                    tmp[9].plot(marker='o',linestyle=':',color='r',legend=False)
                    ax8.yaxis.grid(True)
                    ax8.xaxis.grid(True)             
                    plt.title( tool + '  ' + 'Shot Rotation_Optimum')
                    if i<11:
                        plt.ylim(-3,3)
                    else:
                        plt.ylim(-6,6)         
                    fig.subplots_adjust(hspace=0.5)
                    
                    plt.savefig('z:\\_DailyCheck\\OptOvl_Others\\OvlPicture\\LSA_' + tool ,dpi=100, bbox_inches='tight')
                    
                    #sht.pictures.add(fig, name=(tool + '_Optimum Value'), update=True,
                    #                 left=sht.range('A2').left, top=sht.range('A2').top)
                            
            
                    plt.clf() # 清图。
                    plt.cla() # 清坐标轴。
                    plt.close() # 关窗口
                    gc.collect()
                                        
                
                
                    


##########################################################################################################



    #wb.save()
    #wb.close()
        


if __name__ == "__main__":
    try:
        asml,nikon = extract_data()
        optvalue(asml,nikon)
        tmp = open(r'C:\anaconda3\log.txt','a')
        tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___009-OvlOpt_FIA_LSA Done\n")
        tmp.close()
    except:
        tmp = open(r'C:\anaconda3\log.txt','a')
        tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___009-OvlOpt_FIA_LSA Failed\n")
        tmp.close()        
    
    



























































