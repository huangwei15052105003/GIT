# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""




import pandas as pd
#import numpy  as np
#from sklearn.linear_model import LinearRegression
import win32com.client
import datetime
#import xlwings as xw
import matplotlib.pyplot as plt
import gc
import numpy as np
import matplotlib.ticker as ticker
import matplotlib.gridspec as gridspec


def align_xaxis(ax2, ax1, x1, x2):
    "maps xlim of ax2 to x1（lower lim） and x2（upper lim） in ax1"
    (x1, _), (x2, _) = ax2.transData.inverted().transform(ax1.transData.transform([[x1, 0], [x2, 0]]))
    xs, xe = ax2.get_xlim()
    k, b = np.polyfit([x1, x2], [xs, xe], 1)
    ax2.set_xlim(xs*k+b, xe*k+b)


def setup(ax):
    ax.spines['right'].set_color('none')
    ax.spines['left'].set_color('none')
    ax.yaxis.set_major_locator(ticker.NullLocator())
    ax.spines['top'].set_color('none')
    ax.xaxis.set_ticks_position('bottom')
    #ax.tick_params(which='major', width=1.00)
    #ax.tick_params(which='major', length=5)
    #ax.tick_params(which='minor', width=0.75)
    #ax.tick_params(which='minor', length=2.5)
    #ax.set_xlim(0, 5)
    #ax.set_ylim(0, 1)
    ax.patch.set_alpha(0.0)
    
    

def db_data(databasepath = 'Z:/_DailyCheck/Database/data.mdb', n=30):
    
    tmp = str ( datetime.datetime.now().date() - datetime.timedelta(days = n ))
    
    
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)        
    ##Move Table###################################################### 

    rs = win32com.client.Dispatch(r'ADODB.Recordset') 
    sql  = ' SELECT * FROM CD_data  WHERE Dcoll_Time > #' + tmp + '#  order by Dcoll_Time'
     

    rs.Open(sql, conn, 1, 3)
    rs.movefirst
        
    tmp = []
    df = []
    while True:
        if rs.EOF:
            break
        else:
            tmp =[]
            #tmp = [ rs.fields.item(i).value for i in range( rs.fields.count)]
            for i in range (rs.fields.count):
                if i in (5,7):
                    tmp.append( str(rs.fields.item(i).value)[0:-6])                    
                else:
                    tmp.append( (rs.fields.item(i).value))
        df.append(tmp)
        rs.MoveNext()
    tmp  = [ rs.fields.item(i).name for i in range( rs.fields.count)]
    rs.close
    conn.close
    
    df = pd.DataFrame(df,columns = tmp)
    
    return df
    

    
    



def plot_spc(df):
    chart = pd.read_csv('Z:/_dailycheck/outlook/config.csv').fillna(0)
    
    for i in range(chart.shape[0]):
        tmp = list (chart.loc[i:i].T[i])
        chart_name = tmp[0]
        layer = tmp [1]
        target = tmp [3]
        upper_limit = tmp[4]
        lower_limit = tmp[2]
        
        print(i,chart_name)
        
        spc = pd.DataFrame(columns = df.columns )
        df_layer = df [ df['Layer'] == layer]
        for j in range(5,chart.shape[1],1):
            if not ( tmp[j] == 0 ) :
                
                tmp1 = ( df_layer [df_layer['PartID'].str.contains(tmp[j])] )
                if tmp1.shape[0]>0:
                    spc = pd.concat([spc,tmp1],axis = 0)
                    
        tmp = spc.sort_values ( by = ['PartID','Proc_EqID','Dcoll_Time'])                
                    
        #spc = spc.sort_values ( by = 'Dcoll_Time' )
        #tmp = spc.reset_index().set_index('PartID')[['1','2','3','4','5','6','7','8','9','Met_Avg']]
    
        
        
        
        if tmp.shape[0] > 0:
         
            
            fig = plt.figure(figsize=(18, 10),tight_layout=True)
            gs = gridspec.GridSpec(10, 1)
            ax = fig.add_subplot(gs[0:8, 0]) 
    
            #ax = fig.add_subplot(3,1,1) 
            #fig,ax = plt.subplots(figsize=(18, 8))
            
            ax.plot(list( tmp['1'] ),linewidth =0.01,linestyle=':', color='white',
               marker = 'o',markerfacecolor='blue', markersize=6,label = '1')
            ax.plot(list( tmp['2'] ),linewidth =0.01,linestyle=':', color='white',
               marker = 'o',markerfacecolor='green', markersize=6,label = '2')
            ax.plot(list( tmp['3'] ),linewidth =0.01,linestyle=':', color='white',
               marker = 'o',markerfacecolor='purple', markersize=6,label = '3')
            ax.plot(list( tmp['4'] ),linewidth =0.01,linestyle=':', color='white',
               marker = 'o',markerfacecolor='coral', markersize=6,label = '4')
            ax.plot(list( tmp['5'] ),linewidth =0.01,linestyle=':', color='white',
               marker = 'o',markerfacecolor='cyan', markersize=6,label = '5')
            ax.plot(list( tmp['6'] ),linewidth =0.01,linestyle=':', color='white',
               marker = 'o',markerfacecolor='slategray', markersize=6,label = '6')
            ax.plot(list( tmp['7'] ),linewidth =0.01,linestyle=':', color='white',
               marker = 'o',markerfacecolor='hotpink', markersize=6,label = '7')
            ax.plot(list( tmp['8'] ),linewidth =0.01,linestyle=':', color='white',
               marker = 'o',markerfacecolor='orange', markersize=6,label = '8')
            ax.plot(list( tmp['9'] ),linewidth =0.01,linestyle=':', color='white',
               marker = 'o',markerfacecolor='orchid', markersize=6,label = '9')
            ax.plot(list( tmp['Met_Avg'] ),linewidth =0.5,linestyle=':', color='red',
               marker = 'v',markerfacecolor='red', markersize=8,label = 'Avg')
            ax.set_xticks( [ i for i in range(tmp.shape[0])])
            ax.set_xticklabels((tmp['PartID']), rotation=30, horizontalalignment='right')
            ax.axhline(target, ls = '--',color = 'r')
            ax.axhline(upper_limit, ls = '--',color = 'r')
            ax.axhline(lower_limit, ls = '--',color = 'r')
            ax.set(ylim=[lower_limit - 0.1 * (target - lower_limit),upper_limit + 0.1 * (upper_limit-target)],title=chart_name)#, xlabel='PartID', ylabel='CD(um)',
                   
            ax.yaxis.grid (True, linestyle=':', linewidth=0.5) 
            ax.xaxis.grid (True, linestyle=':', linewidth=0.5) 
            ax.legend(loc='upper center', ncol = 10 )#shadow=True, fontsize='x-large')
            #ax.lenend(loc='lower center',ncol=10,bbox_to_anchor=(0., 1.02, 1., .102),mode="expand", borderaxespad=0.)
            
            #ax1 = fig.add_subplot(3,1,2)
            ax1 = fig.add_subplot(gs[8:9, 0])
            ax1.plot([0 for i in range(tmp.shape[0])],color='white')
            setup(ax1)
            ax1.xaxis.set_ticks( [ i for i in range(tmp.shape[0])])
            ax1.xaxis.set_ticklabels((tmp['Proc_EqID']), rotation=30, horizontalalignment='right')
            
            
            #ax2 = fig.add_subplot(3,1,3)
            ax2 = fig.add_subplot(gs[9:, 0])
            ax2.plot([0 for i in range(tmp.shape[0])],color='white')
            setup(ax2)
            ax2.xaxis.set_ticks( [ i for i in range(tmp.shape[0])])
            ax2.xaxis.set_ticklabels((tmp['Dcoll_Time']), rotation=30, horizontalalignment='right')
      
            if layer in ('A1','A2','A3','A4','A5','A6','A7','AT','TT'):
                plt.savefig('z:\\_DailyCheck\\DailyChart\\Metal\\' + chart_name + '.jpg',dpi=100, bbox_inches='tight')
                spc.to_csv("z:\\_DailyCheck\\DailyChart\\Metal\\" + chart_name + '.csv')  
            elif layer in ("GT","PC","GC","P0"):
                plt.savefig('z:\\_DailyCheck\\DailyChart\\Poly\\' + chart_name + '.jpg',dpi=100, bbox_inches='tight')
                spc.to_csv("z:\\_DailyCheck\\DailyChart\\Poly\\" + chart_name + '.csv')
            elif layer in ("TO"):
                plt.savefig('z:\\_DailyCheck\\DailyChart\\Active\\' + chart_name + '.jpg',dpi=100, bbox_inches='tight')
                spc.to_csv("z:\\_DailyCheck\\DailyChart\\Active\\" + chart_name + '.csv')  
            elif layer in ("W1","W2",'W3','W4','W5','W6','W7','WT'):
                plt.savefig('z:\\_DailyCheck\\DailyChart\\Hole\\' + chart_name + '.jpg',dpi=100, bbox_inches='tight')
                spc.to_csv("z:\\_DailyCheck\\DailyChart\\Hole\\" + chart_name + '.csv') 
            elif layer in ("PK","HV","TR","BN"):
                plt.savefig('z:\\_DailyCheck\\DailyChart\\NclPrePoly\\' + chart_name + '.jpg',dpi=100, bbox_inches='tight')
                spc.to_csv("z:\\_DailyCheck\\DailyChart\\NclPrePoly\\" + chart_name + '.csv') 
            elif layer in ("SI","HR","CT"):
                plt.savefig('z:\\_DailyCheck\\DailyChart\\NclPostPoly\\' + chart_name + '.jpg',dpi=100, bbox_inches='tight')
                spc.to_csv("z:\\_DailyCheck\\DailyChart\\NclPostPoly\\" + chart_name + '.csv') 
            else:
                plt.savefig('z:\\_DailyCheck\\DailyChart\\Others\\' + chart_name + '.jpg',dpi=100, bbox_inches='tight')
                spc.to_csv("z:\\_DailyCheck\\DailyChart\\Others\\" + chart_name + '.csv') 
                                         
                      
            #plt.show()
            plt.clf() # 清图。
            plt.cla() # 清坐标轴。
            plt.close() # 关窗口
            gc.collect()
    





if __name__=="__main__":
    try:        
        df = db_data(databasepath = 'Z:/_DailyCheck/Database/data.mdb', n=30)
        
        plot_spc(df)

        tmp = open(r'C:\anaconda3\log.txt','a')
        tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___010-Kchart Done\n")
        tmp.close()
    except:
        tmp = open(r'C:\anaconda3\log.txt','a')
        tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___010-Kchart Failed\n")
        tmp.close()


