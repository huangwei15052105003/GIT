# -*- coding: utf-8 -*-
"""
Created on Mon Aug 20 07:45:43 2018

@author: HUANGWEI45
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Aug 16 15:49:44 2018

@author: HUANGWEI45
"""

import sys
sys.path.append('D:/HuangWeiScript/PyTaskCode/')
import datetime

#import NikonRecipeMaintain
#import CDU_QC_IMAGE_CD
#import CDU_QC_IMAGE_PLOT
#import ERRC_OCAP_RWK_MOVE_NEW
#import Flow
#import FileCopy
#import hold
#import kchart
#import MakeVmsFtp
import Nikon_Vector
import NikonPara
import NikonRecipeDate
#import OvlOpt_FIA_LSA
#import PartLayerRun
#import PpcsAdo
#import QcCduOvl
import AsmlBatchReport  
#===========================================
#NikonRecipeMaintain.NikonRecipeMaintain()


#=================================
# CDU_QC_IMAGE_CD.
#folderlist =CDU_QC_IMAGE_CD.YE_folderlist(begin = 0, end =3)        #指定天数内YE目录
#finish_merge = CDU_QC_IMAGE_CD.complete_collection() #已完成图片贴图的YE目录-->后续改为集合，简化nikon_image_cd调用时的判断
#imgdone = CDU_QC_IMAGE_CD.cd_measure_done()          #已完成CD测量的YE目录    
#CDU_QC_IMAGE_CD.nikon_image_cd(folderlist,finish_merge,imgdone)
#CDU_QC_IMAGE_CD.asml_image_cd(folderlist,finish_merge,imgdone)



#=====================
#CDU_QC_IMAGE_PLOT
#CDU_QC_IMAGE_PLOT.Excel_Macro() #读入  天move数据
#CDU_QC_IMAGE_PLOT.rename_imgname()
#CDU_QC_IMAGE_PLOT.cd()
#CDU_QC_IMAGE_PLOT.plot_cd_image(days=30)
#CDU_QC_IMAGE_PLOT.move_file_to_Z_drive()


#=================================
#ERRC_OCAP_RWK_MOVE_NEW

#MOVEdate, RWKdate, ERRCdate, OCAPdate = ERRC_OCAP_RWK_MOVE_NEW.get_db_latest_date1()
#ocap_new, rwk_new, move_new, errc_new = ERRC_OCAP_RWK_MOVE_NEW.get_latest_chart_data1(MOVEdate, RWKdate, ERRCdate, OCAPdate)
#ERRC_OCAP_RWK_MOVE_NEW.update_db(ocap_new, rwk_new, move_new, errc_new)       
#ocap_new, rwk_new, move_new, errc_new = None,None,None,None

#============================
#Flow
#Flow.html_update_all(FileDir = r'Z:\_DailyCheck\outlook\FeedbackFailure')    
#Flow.plot_data() 
#Flow.newflow()
#Flow.flowlayer() 

#=============================
#FileCopy
#FileCopy.FileCopy()

 
#=====================
#hold
#hold.update_excel_data_xw( path =r'Y:\Hold\hold.xlsm',  databasepath = r'Y:\Hold\HOLD.mdb'  )

 

#============================
#kchart
#df = kchart.db_data(databasepath = 'Z:/_DailyCheck/Database/data.mdb', n=30)
#kchart.plot_spc(df)


#=================================
#MakeVmsFtp
#MakeVmsFtp.MakeVmsFtp()







#=====================
#NikonPara
try:
    NikonPara.MacAdjust()
    tmp = open(r'D:\HuangWeiScript\PyTaskCode\pythonlog.txt','a')
    tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___005-NikonPara.MacAdjust  Done\n")
    tmp.close()
    
    NikonPara.MacConst()
    tmp = open(r'D:\HuangWeiScript\PyTaskCode\pythonlog.txt','a')
    tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___006-NikonPara.MacConst  Done\n")
    tmp.close()    
       
    NikonPara.SYSparam()
    tmp = open(r'D:\HuangWeiScript\PyTaskCode\pythonlog.txt','a')
    tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___007-NikonPara.SYSparam  Done\n")
    tmp.close()     
    
except:
    tmp = open(r'D:\HuangWeiScript\PyTaskCode\pythonlog.txt','a')
    tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___007-NikonPara Failed Done\n")
    tmp.close()    


#======================
#Nikon_Vector
try:
    Nikon_Vector.single_ega_file()
    tmp = open(r'D:\HuangWeiScript\PyTaskCode\pythonlog.txt','a')
    tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___008-NikonVector.SYSparam  Done\n")
    tmp.close()
except:
    tmp = open(r'D:\HuangWeiScript\PyTaskCode\pythonlog.txt','a')
    tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___008-Nikon_Vector Failed Done\n")
    tmp.close()      






#=================================
#NikonRecipeDate
try:
    NikonRecipeDate.NikonRecipeDate()
    tmp = open(r'D:\HuangWeiScript\PyTaskCode\pythonlog.txt','a')
    tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___009-NikonRecipeDate  Done\n")
    tmp.close()
except:
    tmp = open(r'D:\HuangWeiScript\PyTaskCode\pythonlog.txt','a')
    tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___009-NikonRecipeDate Failed Done\n")
    tmp.close()     
    


#===================================
#AsmlBatchReport()  
try:
    AsmlBatchReport.AsmlBatchReport()
    tmp = open(r'D:\HuangWeiScript\PyTaskCode\pythonlog.txt','a')
    tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___010-AsmlBatchReport  Done\n")
    tmp.close()
except:
    tmp = open(r'D:\HuangWeiScript\PyTaskCode\pythonlog.txt','a')
    tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___010-AsmlBatchReport Failed Done\n")
    tmp.close()    
    
    
#======================
#OvlOpt_FIA_LSA
#asml,nikon = OvlOpt_FIA_LSA.extract_data()
#OvlOpt_FIA_LSA.optvalue(asml,nikon)

#========================
#PartLayerRun
#PartLayerRun.update_flag1()


#==========================
#PpcsAdo
#CDdate, ASMLdate, NIKONdate = PpcsAdo.get_db_latest_date()
#PpcsAdo.unrar_latest_ChartDataXLS()
#cd_new, asml_new, nikon_new =   PpcsAdo.get_latest_chart_data(CDdate, ASMLdate, NIKONdate) #from compiled CSV file
#PpcsAdo.update_db(cd_new,asml_new,nikon_new)


#==================================
#QcCduOvl              
#QcCduOvl.cdu_ovl_qc()
