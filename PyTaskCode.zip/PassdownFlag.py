# -*- coding: utf-8 -*-
"""
Created on Fri Jul 13 07:28:55 2018

@author: HUANGWEI45
"""




import win32com.client
import datetime
import pandas as pd
import xlwings as xw
import gc
import matplotlib.pyplot as plt

from ctypes import cdll
import os





def is_open(filename = r'Z:\交接\PE交接.xls'):
    _sopen = cdll.msvcrt._sopen
    _close = cdll.msvcrt._close
    _SH_DENYRW = 0x10
    #if not os.access(filename, os.F_OK):
    #    return False # file doesn't exist
    h = _sopen(filename, 0, _SH_DENYRW, 0)
    if h == 3:
        _close(h)
        return False # file is not opened by anyone else
    return True # file is already open

print (is_open(filename = r'Z:\交接\PE交接.xls'))























def update_passdown( path = r'Z:\交接\PE交接.xls' ):

    # refresh hold data in excel
    
    xlApp = win32com.client.Dispatch('Excel.Application')
    xlApp.visible = 0 # 此行设置打开的Excel表格为可见状态；忽略则Excel表格默认不可见
    xlBook = xlApp.Workbooks.Open(path)
    strPara = xlBook.Name + '!Main()'
    status = xlApp.ExecuteExcel4Macro(strPara) 
    xlBook.Save()

    xlBook.Close() # 关闭Excel，并保存更改 
 
  
update_passdown( path = r'Z:\交接\PE交接.xls' )





