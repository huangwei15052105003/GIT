# -*- coding: utf-8 -*-
"""
Created on Wed Oct 17 07:52:17 2018

@author: HUANGWEI45
"""

import pandas as pd
import os

def read_illumination_setting():
    #read illumination conditions from asml txt file
    
    asmlfilepath = 'P:/Recipe/ASMLBACKUP/'  #only latest files
    asmlfilepathnew = 'P:/Recipe/recipe/'
    filelist = []
    for file in os.listdir(asmlfilepath):
        filelist.append(os.path.join(asmlfilepath, file))
    for file in os.listdir(asmlfilepathnew):
        filelist.append(os.path.join(asmlfilepathnew, file))  


    illumination = pd.DataFrame(columns = ['Layer', 'Image', 'Type', 'NA', 'Outer', 'Inner', 'Part'])
    
    
    for n,file in enumerate(filelist):
        print(n,'---',file)
        try:
            tmp = [i.strip('\n') for i in (open(file).readlines()) if i.strip('\n') !='']
            
            if len(tmp)>200:
                for n, i in enumerate(tmp):
                    if i.strip()[0:8]=='Job Name':
                        if '/' in i:
                            part = i.split(':')[1].split('/')[1].strip()
                        else:
                            part = i.split(':')[1].strip()
                try: 
                    a = tmp.index('Illumination Mode')
                    b = tmp.index('Illumination Settings')
                    c = tmp.index('Reticle Image')
                    
                    if a>100 and b>100 and c>100:
                        x =[i.strip().split('|') for i in  tmp[a+4:b-1] ]  #illumination type
                        x = pd.DataFrame(x)[[1,2,3]]
                        x.columns=['Layer','Image','Type']
                        y =[i.strip().split('|') for i in  tmp[b+6:c-1] ] #illumination 
                        y = pd.DataFrame(y)[[1,2,3,4,5]]
                        y.columns = ['Layer','Image','NA','Outer','Inner']
                        tmp1 = pd.merge(x,y,how='left',on=['Layer','Image'])
                        tmp1['Part'] = part
                        tmp1['Layer'] = [i.strip() for i in tmp1['Layer']]
                        tmp1['Image'] = [i.strip() for i in tmp1['Image']]
                        tmp1['Type'] = [i.strip() for i in tmp1['Type']]
                        
                        
                        illumination = pd.concat([illumination,tmp1])
                        tmp,tmp1,a,b,c,x,y,part = None,None,None,None,None,None,None,None
                except:
                    pass
        except:
            pass
        
    illumination = illumination.drop_duplicates()
    
    
    
   
   
    
    tmp = pd.read_csv('y:/newproductchecklist/PartTech.csv',encoding = 'GBK') 
    tmp = tmp.dropna()
    
    
    tmp.columns = ['Part','Tech']
    tmp['Part'] = [ i[0:-3].strip() for i in tmp['Part']]
    tmp['Tech'] = [ i.strip() for i in tmp['Tech']]
    illumination = pd.merge(illumination,tmp,how = 'left',on = ['Part'])
    
    
    
    illumination.to_csv('y:/newproductchecklist/AsmlIllumination.csv',index = None,encoding = 'GBK')  
   
    
    
    #================================================================================
    
    
    illumination = pd.read_csv('y:/newproductchecklist/AsmlIllumination.csv',encoding = 'GBK')
    illumination = illumination[['Part','Tech','Layer',  'Type', 'NA', 'Outer', 'Inner']]
    illumination = illumination[illumination['Type'] != 'Default']
    illumination = illumination.dropna().drop_duplicates()
    
    
    track = pd.read_csv('y:/newproductchecklist/TrackPpid.csv',encoding = 'GBK')
    illumination = pd.merge(illumination,track,how = 'left',on =['Part','Layer'])
    
    
    df = illumination[['Part', 'Tech', 'Layer', 'Track','Type', 'NA', 'Outer', 'Inner']].dropna()
    
    df.to_csv('y:/newproductchecklist/illumination_track.csv',index=None,encoding='GBK')
    
    df['Key']= [str( df.iloc[i,1]) + '_' + str(df.iloc[i,2]) + '_' +str( df.iloc[i,3] )for i in range(df.shape[0])]   
    
    df = df[['Key', 'Type', 'NA', 'Outer', 'Inner']].drop_duplicates()
    df=df.reset_index().drop(columns='index')
    tmp = pd.DataFrame( [i.split('_') for i in df['Key']],columns=['Tech','Layer','Track']) 
    df = pd.concat([tmp,df],axis=1)
    
    df.to_csv('y:/newproductchecklist/AsmlNaVsTechLayer.csv',index = None,encoding='GBK')

  
    
    
    
    
    
    
    
    
    
 
def read_alignment_strategy():
    #read illumination conditions from asml txt file
    
    asmlfilepath = 'P:/Recipe/ASMLBACKUP/'  #only latest files
    asmlfilepathnew = 'P:/Recipe/recipe/'
    filelist = []
    for file in os.listdir(asmlfilepath):
        filelist.append(os.path.join(asmlfilepath, file))
    for file in os.listdir(asmlfilepathnew):
        filelist.append(os.path.join(asmlfilepathnew, file))  
    Align = pd.DataFrame(columns=[0,1,'Part'])
        

    for n,file in enumerate(filelist):
        print(n,'---',file)
        try:
            tmp = [i.strip('\n') for i in (open(file).readlines()) if i.strip('\n') !='']
            

            a = tmp.index( "+=================+==================+=============+")
            b = tmp.index('Reticle Alignment Method')
            x = [i.split('|')[1].strip() for i in tmp[a+1:b-1]]
            y = [i.split('|')[2].strip() for i in tmp[a+1:b-1]]
            tmp1 = pd.DataFrame([x,y]).T
            tmp1['Part'] = file.split('/')[3]
            Align = pd.concat([Align,tmp1])
            tmp,a,b,x,y = None,None,None,None,None
            #if n >100:
            #    break
            
        except:
            pass
    Align.columns = ['Layer','Strategy','Part']
    Align.to_csv('y:/newproductchecklist/align.csv',index=None)
              
          

def read_pre_align_method():    
    asmlfilepath = 'P:/Recipe/ASMLBACKUP/'  #only latest files
    asmlfilepathnew = 'P:/Recipe/recipe/'
    filelist = []
    for file in os.listdir(asmlfilepath):
        filelist.append(os.path.join(asmlfilepath, file))
    for file in os.listdir(asmlfilepathnew):
        filelist.append(os.path.join(asmlfilepathnew, file))  
    method = []
        

    for n,file in enumerate(filelist):
        print(n,'---',file)
        try:
            tmp = [i.strip('\n') for i in (open(file).readlines()) if i.strip('\n') !='']
            
            for i in tmp:
                if i.strip()[:19] == 'Prealignment Method':
                    method.append([i.strip().split(':')[1].strip(),file.split('/')[3]]) 


            
        except:
            pass
    method = pd.DataFrame(method)
    method.to_csv('y:/newproductchecklist/method.csv',index=None)            



class demo:
    def a(self,name):
        self.name = name
        print(self.name)
    def b(self,sex):
        self.sex = sex
        print(self.sex)

test = demo()
test.a("THIS IS NAME")
test.b("SHE IS FEMALE")
    
   
 