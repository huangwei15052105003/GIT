# -*- coding: utf-8 -*-
"""
Created on Fri May 25 10:34:09 2018

@author: HUANGWEI45
"""

# -*- coding: utf-8 -*-


import win32com.client
import os
import sys
import numpy as np
import pandas as pd
import datetime
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import gc
import re
import matplotlib.ticker as ticker


## This is to compile IT data to local CSV file

#-----------------------------------------------------
def align_xaxis(ax2, ax1, x1, x2):
    "maps xlim of ax2 to x1（lower lim） and x2（upper lim） in ax1"
    (x1, _), (x2, _) = ax2.transData.inverted().transform(ax1.transData.transform([[x1, 0], [x2, 0]]))
    xs, xe = ax2.get_xlim()
    k, b = np.polyfit([x1, x2], [xs, xe], 1)
    ax2.set_xlim(xs*k+b, xe*k+b)




#-----------------------------------------------------
def unrar_file(filename): #DOS command,unzip file
    str1='P:\\HuangWei\\haozip\\haozipc e -y ' + filename + ' -oP:\\HuangWei\\'
    os.system(str1)
    print(filename)
    #if os.system(str1) == 0:
    #    print ("execution ok")
    #else:
    #    print ('error')

#-----------------------------------------------------
def data_ready(filefullpath):
    cd_new = pd.read_excel(filefullpath,sheetname='CD')
    cd_new['Dcoll Time'] = pd.to_datetime(cd_new['Dcoll Time'])    
    cd_new = cd_new.sort(columns="Dcoll Time")
    
    try:
        cd_date = pd.read_csv('P:\\HuangWei\\R2R\\cd.csv',usecols=['Dcoll Time'])
        cd_date = cd_date['Dcoll Time'][len(cd_date)-1]
        if len(cd_date.split()[1])<=5:
            cd_date =cd_date + ':59' 
            
        cd_date =( datetime.datetime.strptime(cd_date  , "%Y-%m-%d %H:%M:%S") )
        cd_new = cd_new[cd_new['Dcoll Time']>cd_date]
        print ('cd_date=',cd_date)
            
    except:
        pass
    cd_new.to_csv('P:\\HuangWei\\R2R\\cd.csv',index=False,header=None,mode='a')
    cd_new = None
    cd_date = None


    asml_new = pd.read_excel(filefullpath,sheetname='OL_ASML',skiprows=[1])
    asml_new['Dcoll Time'] = pd.to_datetime(asml_new['Dcoll Time'])    
    asml_new = asml_new.sort(columns="Dcoll Time")    
    
    try:
        asml_date = pd.read_csv('P:\\HuangWei\\R2R\\asml.csv',usecols=['Dcoll Time'])
        asml_date = asml_date['Dcoll Time'][len(asml_date)-1]
        if len(asml_date.split()[1])<=5:
            asml_date =asml_date + ':59' 
                
        asml_date =( datetime.datetime.strptime(asml_date, "%Y-%m-%d %H:%M:%S") )
        asml_new = asml_new[asml_new['Dcoll Time']>asml_date]
        print ('asml_date=',asml_date)
    except:
        pass
    asml_new.to_csv('P:\\HuangWei\\R2R\\asml.csv',index=False,header=None,mode='a')
    asml_new.to_csv('P:\\HuangWei\\R2R\\ovl.csv',index=False,header=None,mode='a')
    asml_new = None
    asml_date = None

    
    
    
    nikon_new = pd.read_excel(filefullpath,sheetname='OL_NIKON',skiprows=[1])
    nikon_new['Dcoll Time'] = pd.to_datetime(nikon_new['Dcoll Time'])    
    nikon_new = nikon_new.sort(columns="Dcoll Time")     
     
    try:
        nikon_date = pd.read_csv('P:\\HuangWei\\R2R\\nikon.csv',usecols=['Dcoll Time'])
        nikon_date = nikon_date['Dcoll Time'][len(nikon_date)-1]
        if len(nikon_date.split()[1])<=5:
            nikon_date =(nikon_date + ':59') 
        nikon_date =( datetime.datetime.strptime(nikon_date, "%Y-%m-%d %H:%M:%S") )
        
        nikon_new = nikon_new[nikon_new['Dcoll Time']>nikon_date]
        print ('nikon_date=',nikon_date)
    except:
        pass
    nikon_new.to_csv('P:\\HuangWei\\R2R\\nikon.csv',index=False,header=None,mode='a')
    nikon_new.to_csv('P:\\HuangWei\\R2R\\ovl.csv',index=False,header=None,mode='a')
    nikon_new = None
    nikon_date = None
#-----------------------------------------------------
def get_rar_filename(dirxls):
    
    filenamelist=[]
    for root, dirs, files in os.walk(dirxls, False):  #root:所有目录名-->字符串 #dirs: root下的子目录名-->列表 #files：root下的文件名-->列表 # name.endswith(ext)-->文件名筛选 
        for names in files:
            if names.endswith('ChartData.rar'):
                filenamelist.append( root  + '\\' + names) 
    filenamelist.sort(reverse = False)
    return (filenamelist)



#-----------------------------------------------------

def csv():
    dirxls = 'P:\\HuangWei\\Email'
    filenamelist=get_rar_filename(dirxls)

    filefullpath = 'P:\\HuangWei\\ChartData.xls'

    for filename in filenamelist:
        unrar_file(filename)
        data_ready(filefullpath)                        
        os.system(' del /q ' + filename )               

############################################################## 
#合并outlook下载的R2R数据
##############################################################



       
def cdu_plot(tool,x,y):


    fig = plt.figure(figsize =(16,12))
    ax = fig.add_subplot(1,1,1)

    ax.boxplot(y,vert=True)

    ax.set_xticklabels(x,rotation=90)

    ax.yaxis.grid(True)
    ax.set_xlabel(tool + '_CDU')
    #ax.set_ylabel('CD Target=0.50')
    
    if tool in ('ALII01', 'ALII02', 'ALII03',
       'ALII04', 'ALII05', 'ALII10', 'ALII11', 'ALII12', 'ALII13',
       'ALII14', 'ALII15', 'ALII16', 'ALII17', 'ALII18', 'ALSIB6',
       'ALSIB7', 'ALSIB8', 'ALSIB9', 'ALSIBJ', 'BLSIBK', 'BLSIBL', 
       'BLSIE1'):
        plt.ylim(0.47,0.53)
        plt.hlines(0.50,1,len(x),linewidth=2,color='red')
        plt.hlines(0.48,1,len(x),linewidth=2,color='red')
        plt.hlines(0.52,1,len(x),linewidth=2,color='red')
    elif tool in ('ALDI05','ALDI11','ALDI12','BLDI08','BLDI13'):
        plt.ylim(0.235,0.265)
        plt.hlines(0.25,1,len(x),linewidth=2,color='red')
        plt.hlines(0.24,1,len(x),linewidth=2,color='red')
        plt.hlines(0.26,1,len(x),linewidth=2,color='red')
    else:
        plt.ylim(0.145,0.175)
        plt.hlines(0.16,1,len(x),linewidth=2,color='red')
        plt.hlines(0.15,1,len(x),linewidth=2,color='red')
        plt.hlines(0.17,1,len(x),linewidth=2,color='red')
    plt.savefig('z:\\_DailyCheck\\OptOvl_Others\\QcCdu\\' + tool ,dpi=100, bbox_inches='tight')    
    #plt.show()   
    

       
       
       
       
       















def get_ovl_csv():
    ovl = rawovl
    ovl = ovl[    (ovl['PartID'] == '2LXXXFIA02')
            | (ovl['PartID'] == '2LXXXFIA03')
            | (ovl['PartID'] == '2LXXXFIA04')
            | (ovl['PartID'] == '2LXXXFIA05')
            | (ovl['PartID'] == '2LXXXFIA06')
            | (ovl['PartID'] == '2LXXXFIA07')
            | (ovl['PartID'] == '2LXXXLSA01')
            | (ovl['PartID'] == '2LXXXSPM01')    ]

    return (ovl)       
#toollist = ovl['Proc EqID'].unique()
#toollist.sort(axis=0)

       




def ovl_plot(tool,sensor,output):
    
    print(tool,'   ',sensor, '   ',output.shape)
    
    
    x1 =[ str(datetime.datetime.date(abc)) for abc in output['Dcoll_Time']]   
    x=[i+1 for i in range(len(x1))]
 
  
    
    fig = plt.figure(figsize=(18, 10))
    #-----------------------------------
    ax1 = fig.add_subplot(2,2,1) 
    plt.xticks(x, x1,rotation=90)
    plt.violinplot(np.array( output[['TranX_OX_min', 'TranX_OX_max','TranX_Met_Value']].T),showmeans=False, showmedians=True)              
    ax1.set_ylabel('TranX_Max-Min-Met')
    ax1.yaxis.grid(True)
    ax1.set_title(tool + ' '+ sensor +  ' TranX')
    #-----------------------------------
    ax2 = fig.add_subplot(2,2,2)
    plt.xticks(x, x1,rotation=90)
    plt.violinplot(np.array( output[['TranY_OY_min', 'TranY_OY_max', 'TranY_Met_Value']].T),showmeans=False, showmedians=True)       
    ax2.set_ylabel('TranY_Max-Min-Met')
    ax2.yaxis.grid(True)
    #plt.legend(loc='lower center',ncol=4,bbox_to_anchor=(0., 1.02, 1., .102),mode="expand", borderaxespad=0.)
    ax2.set_title(tool + ' '+ sensor +  ' TranY')

    
    #-----------------------------------

    ax3 = fig.add_subplot(2,2,3)
   
    plt.xticks(x, x1,rotation=90)
    plt.plot(x,output['ScalX_Met_Value'],linewidth = '1', label = 'W.Sca.X', color='deepskyblue',marker='v')#, linestyle=':')#, marker='v')
    plt.plot(x,output['ScalY_Met_Value'],linewidth = '1', label = 'W.Sca.Y', color='blue',marker='v')# linestyle=':', marker='^')
    plt.plot(x,output[ 'ORT_Met_Value'],linewidth = '1', label = 'Ort', color='red', marker='v')#linestyle='--', marker='o')
    plt.plot(x,output['Wrot_Met_Value'],linewidth = '1', label = 'W.Rot', color='green', marker='v')#linestyle='--', marker='o')
    align_xaxis(ax3,ax1,1,len(x1))
    
    
    
    plt.legend(loc='lower center',ncol=4,bbox_to_anchor=(0., 1.02, 1., .102),mode="expand", borderaxespad=0.)
    #plt.xticks(x, x1.values, rotation=90)
    ax3.set_ylabel('InterField')
    #ax3.set_xlabel(tool + ' '+ sensor)
    ax3.yaxis.grid(True)
  
    
    
    #-----------------------------------
    ax4 = fig.add_subplot(2,2,4)
    plt.xticks(x, x1,rotation=90)
    plt.plot(x,output['Mag_Met_Value'],linewidth = '1', label = 'Mag.', color='deepskyblue', marker='v')#linestyle=':', marker='v')
    plt.plot(x,output['Rot_Met_Value'],linewidth = '1', label = 'Rot.', color='blue',marker='v')# linestyle=':', marker='^')
    plt.plot(x,output['ARMAG_Met_Value'],linewidth = '1', label = 'AsyM', color='red', marker='v')#linestyle='--', marker='o')
    plt.plot(x,output['ARRot_Met_Value'],linewidth = '1', label = 'AsyR', color='green', marker='v')#linestyle='--', marker='o')
    align_xaxis(ax4,ax2,1,len(x1))  
    
    plt.legend(loc='lower center',ncol=4,bbox_to_anchor=(0., 1.02, 1., .102),mode="expand", borderaxespad=0.)
    #plt.xticks(x, x1.values, rotation=90)
    ax4.set_ylabel('IntraField')
    #ax4.set_xlabel(tool + ' '+ sensor)
    ax4.yaxis.grid(True)
    fig.subplots_adjust(hspace=0.4)    
    plt.savefig('z:\\_DailyCheck\\OptOvl_Others\\QcOvl\\' + tool + '_' + sensor,dpi=100, bbox_inches='tight')

    


  





def cd():
    dummy='##################################'
    alltool=('ALDI02', 'ALDI03', 'ALDI05', 'ALDI06', 'ALDI07', 'ALDI09', 'ALDI10',
             'ALDI11', 'ALDI12', 'ALII01', 'ALII02', 'ALII03', 'ALII04', 'ALII05',
             'ALII10', 'ALII11', 'ALII12', 'ALII13', 'ALII14', 'ALII15', 'ALII16',
             'ALII17', 'ALII18', 'ALSIB6', 'ALSIB7', 'ALSIB8', 'ALSIB9', 'ALSIBJ',
             'BLDI08', 'BLDI13', 'BLSIBK', 'BLSIBL', 'BLSIE1')   
    

    try:
        df = rawcd        
    except:
        print('\n\n' + dummy +'\n\n请先用readdata（n）函数导入特定时间区间内的ovl数据\n\n' +dummy)
        sys.exit(0)
    
    
    
    print('\n\n' + dummy + '\n请依次输入tool，partid，layer\ntool:all代表所有设备，asml代表DUV，nikon代表Iline，或单独输入设备ID中的几位\n')
    print('partid,layer可只输入各自的几位，不用全部输入,如"3838"代表整个系列产品，"A"代表铝层次\n' + dummy)
    
    tool =  input ('--请输入tool：')
    part = input ('--请输入partid：')
    layer = input ('--请输入layer：')
    
   

    
    if tool.upper() == 'ALL':
        pass
    elif tool.upper() == 'NIKON':
        df = df [   (df['Proc EqID'].str.contains('II'))
                   |(df['Proc EqID'].str.contains('SI'))   ]
    elif tool.upper() == 'ASML':
        df = df [df['Proc EqID'].str.contains('DI')]
    else:
        toollist = [toolid for toolid in alltool if  (tool.upper() in toolid)]
        df = df[df['Proc EqID'].isin(toollist)]
    
    df = df[ df['PartID'].str.contains(part.upper())]
    df = df[ df['Layer'].str.contains(layer.upper())]
    
    if df.shape[0] == 0:
 
        print(  dummy +'\n未找到匹配数据，退出，请重新输入\n' +dummy)
        sys.exit(0)
    





    ##########################################################
    y1 = np.array( df[['1', '2', '3', '4', '5', '6', '7', '8', '9']]  ).T
    y2 = list(df['CD Target'])
    x = [i+1 for i in range(len(y2))]
    ##########################################################
        

    
    
    ##########################################################
    fig = plt.figure(figsize =(20,12))
    gs = GridSpec(7, 1)  
    ##########################################################
    
    
    ax1 = plt.subplot(gs[0:3, 0])    
    ax1.boxplot(y1  ,vert=True,showmeans=True)
    plt.hlines(y2[0],1,len(y2),linewidth=2,color='red')    
    ax1.set_xticklabels(list(df['LotID']),rotation=90)    
    #ax1.grid(color="red", axis="x")     
    ax1.grid(color="red")
    ax1.set_xlabel(tool.upper() + '_' + part.upper() + '_' + layer.upper() + '_' + 'Opt Dose by LotID' ) 
    if  ((y1.max() > y2[1]*1.1) | (y1.min() < y2[1]*0.9)):
        plt.ylim(y2[1]*0.9,y2[1]*1.1)  # in case of abnormal value     
    
    #plt.xticks(x, list(df['LotID']),rotation=90)  
    #ax1.yaxis.grid(True)
    
    
   
    ########################################################## 
    #draw CD Target
    #ax2 = ax1.twiny()
    #plt.plot(ax1.get_xticks(),y2,linewidth = '2',  color='red', linestyle='-')
    
    #ax2.set_xticklabels(list(df['Dcoll Time']),rotation=90)
    #plt.xticks(x, list(df['Dcoll Time']),rotation=90)
    #plt.plot(y2,linewidth = '2',  color='red', linestyle='-')
    #align_xaxis(ax2, ax1, 1, len(y2))
    #ax2.grid(color="green", axis="x") 
    #此处更改，改为 ax.hlines 函数
    #wehave built in functions to make them easy to plot (see axhline(), axvline(), axhspan(), axvspan())
    #hlines(y, xmin, xmax, colors='k', linestyles='solid', label='', **kwargs) method of matplotlib.axes._subplots.AxesSubplot instance         
        
    #坐标轴无法对齐    
    #ax1.hlines(y2[0],0,len(y2),colors='r',linestyles='solid',linewidth=2)
    ##########################################################     
    
    #draw Optimum dose
    ax3 = ax1.twinx()
    plt.plot(ax1.get_xticks(), list(df['Optimum']),linewidth = '1', color='green', linestyle=':', marker='^',label='Opt-Dose')    
    ax3.legend(loc='upper center', fancybox=True, framealpha=0.1,ncol=1)     
    
    #ax1.get_xticks() 让折线图和box图对齐，否则会错开  
    ########################################################## 
    
    
    #repeat ax1 and change x-axis to 'Dcoll Time'  
    ax6 = plt.subplot(gs[3:4, 0])
    ax6.spines['right'].set_color('none')
    ax6.spines['left'].set_color('none')
    ax6.yaxis.set_major_locator(ticker.NullLocator())
    ax6.spines['top'].set_color('none')
    ax6.xaxis.set_ticks_position('bottom')
    ax6.grid(color="red", axis="x")     
    #ax6.set_xticklabels(list(df['Dcoll Time']),rotation=90)
    plt.xticks(x, list(df['Dcoll Time']),rotation=45)
    
    align_xaxis(ax6, ax1, 0, len(y2))
        
        
        
        
        
        
    ########################################################## 
    #sort data by tool
    df_tool = df.sort(columns='Proc EqID')
        
    ax4 = plt.subplot(gs[4:, 0])
    ax4.boxplot(np.array( df_tool[['1', '2', '3', '4', '5', '6', '7', '8', '9']]  ).T,vert=True,showmeans=True)
    ax4.grid(color="red")
    plt.hlines(y2[0],1,len(y2),linewidth=2,color='red') 
    ax4.set_xticklabels(list(df_tool['Proc EqID']),rotation=90) 
    ax4.yaxis.grid(True)
    ax4.set_xlabel(tool.upper() + '_' + part.upper() + '_' + layer.upper() + '_' + 'Opt Dose by Tool' ) 
    if  ((y1.max() > y2[1]*1.1) | (y1.min() < y2[1]*0.9)):
        plt.ylim(y2[1]*0.9,y2[1]*1.1)  # in case of abnormal value 
    
    
    
    ax5 = ax4.twinx()
    plt.plot(ax4.get_xticks(), list(df_tool['Optimum']),linewidth = '1', color='green', linestyle=':', marker='^',label='Opt-Dose')
    ax5.legend(loc='upper center', fancybox=True, framealpha=0.1,ncol=1) 
    ########################################################## 
    
    #add sapce between sub-plots

    fig.subplots_adjust(hspace=5)
    
    
    plt.savefig('P:\\temp\\cd-spc.jpg',dpi=100, bbox_inches='tight') 
    df.to_csv('P:\\temp\\cd-spc.csv')
    df = None
    df_tool = None
    print( dummy + '\n图片和原始数据保存在P:\\temp目录，文件名cd-spc')



############################################################## 
#查看单个产品CD
##############################################################



def ovl_chart(tool,part,layer,i,df):

    print(tool,'   ',part,'    ',layer,'    ',df.shape[0])
   
    x1 = list(df['LotID']) 

    x  = [i+1 for i in range(len(x1))]
     
    
    
    ##########################################################
    fig = plt.figure(figsize =(18,18))
    gs = GridSpec(4, 1)
    #plt.legend(loc='lower center',ncol=4,bbox_to_anchor=(0., 1.02, 1., .102),mode="expand", borderaxespad=0.)
    ##########################################################
    ax1 = plt.subplot(gs[0:1, 0])
    plt.xticks(x, x1,rotation=90)
    plt.violinplot(np.array( df[['TranX_Ovl-X-Max','TranX_Ovl-X-Min','TranX_Met Value']].T), showmeans=False,  showmedians=True)      
    ax1.grid(color="red")
    ax1.set_title( tool + '   ' + part + '   ' + layer + '   Y1:TranX_Max-Min-Met   Y2:TranX-Opt')
    ax11  = ax1.twinx()
    plt.plot(ax1.get_xticks(), list(df['TranX_Optimum']),linewidth = '1', label = 'TranX-Opt', color='blue', linestyle=':', marker='*')
    ax11.legend(loc='upper right', fancybox=True, framealpha=0.1,ncol=1) 
   
    
    
   
    ##########################################################
    ax2 = plt.subplot(gs[1:2, 0])
    plt.xticks(x, list( df['Proc EqID']),rotation=90)
    plt.violinplot(np.array( df[['TranY_Ovl-Y-Max','TranY_Ovl-Y-Min','TranY_Met Value']].T),showmeans=False, showmedians=True)       
    ax2.grid(color="red")
    ax2.set_title( tool + '   ' + part + '   ' + layer + '   Y1:TranY_Max-Min-Met   Y2:TranY-Opt')
    ax21  = ax2.twinx()
    plt.plot(ax2.get_xticks(), list(df['TranY_Optimum']),linewidth = '1', label = 'TranY-Opt', color='blue', linestyle=':', marker='*')
    ax21.legend(loc='upper right', fancybox=True, framealpha=0.1,ncol=1) 
    
     ##########################################################
    ax3 = plt.subplot(gs[2:3, 0]) 
    plt.xticks(x, x1,rotation=90)
    #align_xaxis(ax3, ax1, 1, len(x1))
    plt.plot(x,list(df['W.Expan.X_Optimum']),linewidth = '1', label = 'Exp-X-Opt', color='red', linestyle='-', marker='v')
    plt.plot(x,list(df['W.Expan.Y_Optimum']),linewidth = '1', label = 'Exp-Y-Opt', color='gold', linestyle='-', marker='v')
    ax3.set_title(  'InterField: Exp-X-Opt-->Red   Exp-Y-Opt-->Gold       Ort-Opt-->Violet   Rot-Opt-->Green  ')    
    ax3.legend(loc='upper left', fancybox=True, framealpha=0.1,ncol=2)
    ax3.grid(color="red") 
    
    
     
    ax31 = ax3.twinx()
    plt.plot(ax3.get_xticks(), list(df['NonOrtho_Optimum']),linewidth = '1', label = 'Ort-Opt', color='blueviolet', linestyle=':', marker='o')
    plt.plot(ax3.get_xticks(), list(df['W.Rotation_Optimum']),linewidth = '1', label = 'Rot-Opt', color='green', linestyle=':', marker='o')
    ax31.legend(loc='upper right', fancybox=True, framealpha=0.1,ncol=2) 
   
    
     ##########################################################
    ax4 = plt.subplot(gs[3, 0]) 
    plt.xticks(x, list( df['Dcoll Time']),rotation=90)
   
    
    plt.plot(x,list(df['Magnification_Optimum']),linewidth = '1', label = 'Mag-Opt', color='red', linestyle='-', marker='v')
    plt.plot(x,list(df['Rotation_Optimum']),linewidth = '1', label = 'Rot-Opt', color='gold', linestyle='-', marker='v')
    ax4.set_title(  'IntraField: Mag-Opt-->Red   Rot-Opt-->Gold       AMag-Opt-->Violet   ARot-->Green  ')
    ax4.legend(loc='upper left',  fancybox=True, framealpha=0.1,ncol=2)     
    ax4.grid(color="red")     
     
    ax41 = ax4.twinx()
    plt.plot(ax4.get_xticks(), list(df['AsymMag_Optimum']),linewidth = '1', label = 'AMag-Opt', color='blueviolet', linestyle=':', marker='o')
    plt.plot(ax4.get_xticks(), list(df['AsymRot_Optimum']),linewidth = '1', label = 'ARot-Opt', color='green', linestyle=':', marker='o')
    ax41.legend(loc='upper right', fancybox=True, framealpha=0.1,ncol=2)     
    
    
    fig.subplots_adjust(hspace=0.4) 
    plt.savefig('P:\\TEMP\\ToolProductTrend\\' + tool + '-' +str( i+1) +'-' + part + '-'+ layer,dpi=100, bbox_inches='tight')  
    
    #del df
    #del fig
    #plt.cla()    
    #gc.collect()
    





def ovl():
    dummy='##################################'
    try:
        df = rawovl        
    except:
        print('\n\n' + dummy +'\n\n请先用readdata（n）函数导入特定时间区间内的ovl数据\n\n' +dummy)
        sys.exit(0)
    
    
    alltool=('ALDI02', 'ALDI03', 'ALDI05', 'ALDI06', 'ALDI07', 'ALDI09', 'ALDI10',
             'ALDI11', 'ALDI12', 'ALII01', 'ALII02', 'ALII03', 'ALII04', 'ALII05',
             'ALII10', 'ALII11', 'ALII12', 'ALII13', 'ALII14', 'ALII15', 'ALII16',
             'ALII17', 'ALII18', 'ALSIB6', 'ALSIB7', 'ALSIB8', 'ALSIB9', 'ALSIBJ',
             'BLDI08', 'BLDI13', 'BLSIBK', 'BLSIBL', 'BLSIE1')   
    
   
    

    
    
    
    print('\n\n' + dummy + '\n请依次输入tool，partid，layer\ntool:all代表所有设备，asml代表DUV，nikon代表Iline，或单独输入设备ID中的几位\n')
    print('partid,layer可只输入各自的几位，不用全部输入,如"3838"代表整个系列产品，"A"代表铝层次\n' + dummy)
    
    tool =  input ('--请输入tool：')
    part = input ('--请输入partid：')
    layer = input ('--请输入layer：')
    
   

    
    if tool.upper() == 'ALL':
        pass
    elif tool.upper() == 'NIKON':
        df = df [   (df['Proc EqID'].str.contains('II'))
                   |(df['Proc EqID'].str.contains('SI'))   ]
    elif tool.upper() == 'ASML':
        df = df [df['Proc EqID'].str.contains('DI')]
    else:
        toollist = [toolid for toolid in alltool if  (tool.upper() in toolid)]
        df = df[df['Proc EqID'].isin(toollist)]
    
    df = df[ df['PartID'].str.contains(part.upper())]
    df = df[ df['Layer'].str.contains(layer.upper())]
    
    if df.shape[0] == 0:
 
        print(  dummy +'\n未找到匹配数据，退出，请重新输入\n' +dummy)
        sys.exit(0)
    i=1
    df.to_csv('P:\\temp\\ovl-spc.csv')    
    print( dummy + '\n\n原始数据保存在P:\\temp目录，文件名ovl-spc')    
    
    ovl_chart(tool,part,layer,i=1,df=df)    



############################################################## 
#查看单个产品ovl
##############################################################



def toolovl():
    
    df = rawovl
    tool = input('Please input tool ID: ')
    tool = tool.upper()
    n=eval(input('Please input part qty: '))
    df=df[df['Proc EqID'].str.contains(tool)]
    
    
 
    
    
   
            
    if df.shape[0] < n:
        print('无数据请确认设备名称未输错,设备名为:  ' + tool)
        
        sys.exit(1)
            
    partlayer = df.groupby(['PartID','Layer'])['JI Time'].count()
    
    if len(partlayer) < n:
        print (tool + '当前只有' + str(len(partlayer))+'个产品，若需要查看更多产品，请增加查询时间区域')
        n = len(partlayer)

    
    
    partlayer.sort()
    partlayer = partlayer.tail(n)
    
    print(df.shape)
    
    for i in range(-n,0,1):
        
        part = partlayer.index[i][0]
        layer = partlayer.index[i][1]
        product = df[(df['PartID'].str.contains(part))  &  (df['Layer'].str.contains(layer))]
        
        
   
        
        ovl_chart(tool,part,layer,i,df=product)
        plt.savefig('P:\\temp\\' + tool + '-' +str( i)  +'-' + part + '-'+ layer,dpi=100, bbox_inches='tight')
        try:
            product.to_csv('P:\\temp\\' + tool + '-' +str( i)  +'-' + part + '-'+ layer + '.csv')
        except:
            pass
     
############################################################## 
#查看单个设备，多个产品OVL
##############################################################    





def alltoolovl():
    
    #try:
    #    os.system(' del /q P:\\TEMP\\ToolProductTrend\\*.png')
    #except:
    #    pass
    
    df = rawovl
    alltool=('ALDI02', 'ALDI03', 'ALDI05', 'ALDI06', 'ALDI07', 'ALDI09', 'ALDI10',
             'ALDI11', 'ALDI12', 'ALII01', 'ALII02', 'ALII03', 'ALII04', 'ALII05',
             'ALII10', 'ALII11', 'ALII12', 'ALII13', 'ALII14', 'ALII15', 'ALII16',
             'ALII17', 'ALII18', 'ALSIB6', 'ALSIB7', 'ALSIB8', 'ALSIB9', 'ALSIBJ',
             'BLDI08', 'BLDI13', 'BLSIBK', 'BLSIBL', 'BLSIE1')
             
           
             
             
   

   
    for tool in alltool:
        os.system(' del /q P:\\TEMP\\ToolProductTrend\\' + tool + '*.png')
        n=5
       
      
       
        df1=df[df['Proc EqID'].str.contains(tool)]              
        partlayer = df1.groupby(['PartID','Layer'])['JI Time'].count()
        
        if len(partlayer) < n:
            print (tool + '当前只有' + str(len(partlayer))+'个产品，若需要查看更多产品，请增加查询时间区域')
            n = len(partlayer)
        
        
        partlayer.sort()
        partlayer = partlayer.tail(n)
        
              
        
        for i in range(0,n,1):
            
            part = partlayer.index[i][0]
            layer = partlayer.index[i][1]
            product = df1[(df1['PartID'].str.contains(part))  &  (df1['Layer'].str.contains(layer))]
            
            
            
            
            ovl_chart(tool,part,layer,i,df=product)
 
        #gc.enable()
            
            
            plt.clf() # 清图。
            plt.cla() # 清坐标轴。
            plt.close() # 关窗口
            gc.collect()
        #gc.disable()
     
   
    
    
    


#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

def bias():
    #将lot的两个层次的OVL参数画在一起以比较差异
    dummy='##################################'
    
    try:
        rawovl.shape
       
    except:
        print('\n\n' + dummy +'\n\n请先用readdata（n）函数导入特定时间区间内的ovl数据\n\n' +dummy)
        sys.exit(0)
    
    
    
    
    
    
    
    
    
    
    


    
    
    
    print('\n\n' + dummy + '\n请依次输入partid，当前层次，前层层次\n')
    print('partid,layer可只输入各自的几位，不用全部输入,如"3838"代表整个系列产品\n')
    print('层次名建议输入全名，A1-001等可以只输入前两位\n'+ dummy)
    
    
    part = input ('--请输入产品名：')
    layer1 = input ('--请输入当前层次：')
    layer2 = input ('--请输入前层层次：')



 
    df1 = rawovl[(rawovl['PartID'].str.contains(part.upper()))  &  (rawovl['Layer'].str.contains(layer1.upper()))]
    df2 = rawovl[(rawovl['PartID'].str.contains(part.upper()))  &  (rawovl['Layer'].str.contains(layer2.upper()))]
    #a = pd.merge(df1, df2, how='left', on='WaferID', suffixes=('_pre', '_post'))
    df = pd.merge(df1, df2, how='inner', on='WaferID', suffixes=('_1', '_2'))

   
   #以下作图，原ovl chart 优化值改为：当前层优化值-前层测量值
    x1 = list(df['LotID_1'])
    x  = [i+1 for i in range(len(x1))]
 
    
    
    ##########################################################
    fig = plt.figure(figsize =(18,18))
    gs = GridSpec(4, 1)
   
    ##########################################################
    ax1 = plt.subplot(gs[0:1, 0])
    plt.xticks(x, x1,rotation=90)
    plt.violinplot(np.array( df[['TranX_Ovl-X-Max_1','TranX_Ovl-X-Min_1','TranX_Met Value_1']].T),showmeans=False,showmedians=True)             
    ax1.yaxis.grid(True)
    ax1.set_title( 'Tran-X' +'    '+ part.upper() + '   ' + layer1.upper() + '  Y2 Axis=bias: ('+layer1.upper()+ ' Opt Value - '+layer2.upper()+' Met Value)')
    ax11  = ax1.twinx()
    plt.plot(ax1.get_xticks(), list(df['TranX_Optimum_1']-df['TranX_Met Value_2']),linewidth = '1', label = 'Opt1-Met_Value2', color='blue', linestyle=':', marker='*') 
    ##########################################################
    
    
    ax2 = plt.subplot(gs[1:2, 0])
    plt.xticks(x, list( df['Proc EqID_1']),rotation=90)
    plt.violinplot(np.array( df[['TranY_Ovl-Y-Max_1','TranY_Ovl-Y-Min_1','TranY_Met Value_1']].T),showmeans=False,showmedians=True)             
    ax2.yaxis.grid(True)
    ax2.set_title( 'Tran-Y' +'    '+ part.upper() + '   ' + layer1.upper() + '  Y2 Axis=bias: ('+layer1.upper()+ ' Opt Value - '+layer2.upper()+' Met Value)   '
                  'X-Axis: ' + layer1.upper() + ' Tool')
    ax21  = ax2.twinx()
    plt.plot(ax2.get_xticks(), list(df['TranY_Optimum_1']-df['TranY_Met Value_2']),linewidth = '1', label = 'Opt1-Met_Value2', color='blue', linestyle=':', marker='*') 

     ##########################################################
    ax3 = plt.subplot(gs[2:3, 0]) 
    plt.xticks(x, list( df['Proc EqID_2']),rotation=90)   
    plt.plot(x,list(df['W.Expan.X_Optimum_1']- df['W.Expan.X_Met Value_2']),linewidth = '1', label = 'Exp-X-Opt', color='red', linestyle='-', marker='v')
    plt.plot(x,list(df['W.Expan.Y_Optimum_1']- df['W.Expan.Y_Met Value_2']),linewidth = '1', label = 'Exp-Y-Opt', color='gold', linestyle='-', marker='v')        
    ax3.legend(loc='upper left', fancybox=True, framealpha=0.1,ncol=2)
    
    ax3.set_title('bias =('+layer1.upper()+ ' Opt Value - '+layer2.upper()+' Met Value)                X-Axis: ' + layer2.upper() + ' Tool')
   

        
    ax31 = ax3.twinx()
    plt.plot(ax3.get_xticks(), list(df['NonOrtho_Optimum_1']-df['NonOrtho_Met Value_2']),linewidth = '1', label = 'Ort-Opt', color='blueviolet', linestyle=':', marker='o')
    plt.plot(ax3.get_xticks(), list(df['W.Rotation_Optimum_1']-df['W.Rotation_Met Value_2']),linewidth = '1', label = 'Rot-Opt', color='green', linestyle=':', marker='o')
    ax31.legend(loc='upper right', fancybox=True, framealpha=0.1,ncol=2)
    align_xaxis(ax3, ax1, 1, len(x1) )

     ##########################################################
    ax4 = plt.subplot(gs[3, 0]) 
    plt.xticks(x, list( df['Dcoll Time_1']),rotation=90)
    plt.plot(x,list(df['Magnification_Optimum_1']-df['Magnification_Met Value_2']),linewidth = '1', label = 'Mag-Opt', color='red', linestyle='-', marker='v')
    plt.plot(x,list(df['Rotation_Optimum_1']-df['Rotation_Met Value_2']),linewidth = '1', label = 'Rot-Opt', color='gold', linestyle='-', marker='v')
    ax4.set_title('bias =('+layer1.upper()+ ' Opt Value - '+layer2.upper()+' Met Value)                   X-Axis: Dcoll Time' )
    ax4.legend(loc='upper left', fancybox=True, framealpha=0.1,ncol=2)  
    
    
    ax41 = ax4.twinx()
    plt.plot(ax4.get_xticks(), list(df['AsymMag_Optimum_1']-df['AsymMag_Met Value_2']),linewidth = '1', label = 'AMag-Opt', color='blueviolet', linestyle=':', marker='o')
    plt.plot(ax4.get_xticks(), list(df['AsymRot_Optimum_1']-df['AsymRot_Met Value_2']),linewidth = '1', label = 'ARot-Opt', color='green', linestyle=':', marker='o')
    ax41.legend(loc='upper right', fancybox=True, framealpha=0.1,ncol=2)
    align_xaxis(ax4, ax1, 1, len(x1) )
    fig.subplots_adjust(hspace=0.4)
    
 
    
    plt.savefig('P:\\TEMP\\bias.jpg',dpi=100, bbox_inches='tight') 
    df.to_csv('p:\\temp\\bias.csv')
    
    #del df
    #del fig
    #plt.cla()    
    #gc.collect()
    


def pretool():

    dummy='##################################'

    print(dummy+ '\n依次输入产品，当前层次，查询天数，前层层次名，以关联当前层次的光刻作业设备\n')
    print('\n查询数据是IT R2R Charting Data，若前层层次无OVL/CD测量，无法进行查询\n'+ dummy +'\n')
    part =( input('请输入产品名，可输入任意几位匹配: ') ).upper()
    layer =( input('请输入层次名：') ).upper()
    try:
        n = eval ( input('请输入当前层次的查询天数： ') )
        while (re.match('[0-9]*',str(n)).group()) == '':
            print('未输入整数，请重新输入')
            n = eval ( input('请输入当前层次的查询天数： ') )
    except:
        print ('输入错误，请重新输入整数: ')
        n = eval ( input('请输入当前层次的查询天数： ') )
    
    pre_layer = (input('请输入前层层次，以英文逗号分隔,最多输入六层：')).upper()
    pre_layer = list(pre_layer.split(','))
    pre_layer = list( set(pre_layer) )   
    
    
    print('依次输入的数据为：\n\n产品__ ' + part + '\n\n层次__ ' + layer + '\n\n查询天数__' + str(n))
 
    print('\n\n查询层次为__ ' ,pre_layer)
    
    readdata(n+60)
    cd = rawcd   [ rawcd  ['PartID'].str.contains(part)]  
    ovl = rawovl [ rawovl ['PartID'].str.contains(part)]
    
    
      
    
    df = ovl [ ovl ['Layer'].str.contains(layer) & (ovl['Dcoll Time'] > (datetime.datetime.today() - datetime.timedelta(days=n)))]
    #df = df[['LotID','Proc EqID']]
   
    
    
    for i in range (len(pre_layer)):
  
        tmpdf = ovl [ ovl ['Layer'].str.contains(pre_layer[i]) ][['LotID','Proc EqID']].drop_duplicates()
        if tmpdf.shape[0] == 0:
            tmpdf = cd [ cd ['Layer'].str.contains(pre_layer[i]) ][['LotID','Proc EqID']].drop_duplicates()
        tmpdf.columns = ('LotID', pre_layer[i])
        print(tmpdf.columns)
        
        
        df = pd.merge(df, tmpdf, how='left', on='LotID')
    df.to_csv('P:\\temp\\pretool.csv')
    print('数据已导出到 P:\\Temp\\pretool.csv')
# 以上采用left join方式，保留当前层所有数据
        
        
        



   
    x1 = list(df['LotID']) 
    x  = [i+1 for i in range(len(x1))]

    fig = plt.figure(figsize = (18,18))
    gs = GridSpec(12,1)
    

    
  
    ##########################################################
    ax1 = plt.subplot(gs[0:3, 0])
    plt.xticks(x, x1,rotation=90)
    plt.violinplot(np.array( df[['TranX_Ovl-X-Max','TranX_Ovl-X-Min','TranX_Met Value']].T), showmeans=False,  showmedians=True)      
    ax1.yaxis.grid(True)
    ax1.set_title( part + '   ' + layer + '   Y1:TranX_Max-Min-Met   Y2:TranX-Opt')
    ax11  = ax1.twinx()
    plt.plot(ax1.get_xticks(), list(df['TranX_Optimum']),linewidth = '1', label = 'TranX-Opt', color='blue', linestyle=':', marker='*')
    
   
    ##########################################################
    ax2 = plt.subplot(gs[3:6, 0])
    plt.xticks(x, list( df['Proc EqID']),rotation=90)
    plt.violinplot(np.array( df[['TranY_Ovl-Y-Max','TranY_Ovl-Y-Min','TranY_Met Value']].T),showmeans=False, showmedians=True)       
    ax2.yaxis.grid(True)
    ax2.set_title( part + '   ' + layer + '   Y1:TranY_Max-Min-Met   Y2:TranY-Opt')
    ax21  = ax2.twinx()
    plt.plot(ax2.get_xticks(), list(df['TranY_Optimum']),linewidth = '1', label = 'TranY-Opt', color='blue', linestyle=':', marker='*')
    

     
    
    ax3 = plt.subplot(gs[6:7, 0])
    plt.xticks(x, df[pre_layer[0]],rotation=90)
    align_xaxis(ax3, ax1, 0, len(x1))

    #plt.violinplot(np.array( df[['TranX_Ovl-X-Max','TranX_Ovl-X-Min','TranX_Met Value']].T), showmeans=False,  showmedians=True)
    ax3.spines['right'].set_color('none')
    ax3.spines['left'].set_color('none')
    ax3.yaxis.set_major_locator(ticker.NullLocator())
    ax3.spines['top'].set_color('none')
    
    ax3.set_title( 'Pre_Layer is : ' + pre_layer[0]) 
    fig.subplots_adjust(hspace=3)  
    if len(pre_layer) == 1:
        sys.exit(0)
     
    ax4 = plt.subplot(gs[7:8, 0]) 
    plt.xticks(x, df[pre_layer[1]],rotation=90)
    align_xaxis(ax4, ax1, 0, len(x1))
    
    #plt.violinplot(np.array( df[['TranX_Ovl-X-Max','TranX_Ovl-X-Min','TranX_Met Value']].T), showmeans=False,  showmedians=True)
    ax4.spines['right'].set_color('none')
    ax4.spines['left'].set_color('none')
    ax4.yaxis.set_major_locator(ticker.NullLocator())
    ax4.spines['top'].set_color('none')
     
    ax4.set_title( 'Pre_Layer is : ' + pre_layer[1])
    fig.subplots_adjust(hspace=3)  
    if len(pre_layer) == 2:
        sys.exit(0)    
            
    ax5 = plt.subplot(gs[8:9, 0]) 
    plt.xticks(x, df[pre_layer[2]],rotation=90)
    align_xaxis(ax5, ax1, 0, len(x1))    
    
    #plt.violinplot(np.array( df[['TranX_Ovl-X-Max','TranX_Ovl-X-Min','TranX_Met Value']].T), showmeans=False,  showmedians=True)
    ax5.spines['right'].set_color('none')
    ax5.spines['left'].set_color('none')
    ax5.yaxis.set_major_locator(ticker.NullLocator())
    ax5.spines['top'].set_color('none')    
    
    ax5.set_title( 'Pre_Layer is : ' + pre_layer[2])
    fig.subplots_adjust(hspace=3)  
    if len(pre_layer) == 3:
        sys.exit(0)    
        
    ax6 = plt.subplot(gs[9:10, 0]) 
    plt.xticks(x, df[pre_layer[3]],rotation=90)
    align_xaxis(ax6, ax1, 0, len(x1))
    
    #plt.violinplot(np.array( df[['TranX_Ovl-X-Max','TranX_Ovl-X-Min','TranX_Met Value']].T), showmeans=False,  showmedians=True)
    ax6.spines['right'].set_color('none')
    ax6.spines['left'].set_color('none')
    ax6.yaxis.set_major_locator(ticker.NullLocator())
    ax6.spines['top'].set_color('none')    
    
    ax6.set_title( 'Pre_Layer is : ' + pre_layer[3])
    fig.subplots_adjust(hspace=3)  
    if len(pre_layer) == 4:
        sys.exit(0)    
    

    ax7 = plt.subplot(gs[10:11, 0]) 
    plt.xticks(x, df[pre_layer[4]],rotation=90)
    align_xaxis(ax7, ax1, 0, len(x1))
    
    #plt.violinplot(np.array( df[['TranX_Ovl-X-Max','TranX_Ovl-X-Min','TranX_Met Value']].T), showmeans=False,  showmedians=True)
    ax7.spines['right'].set_color('none')
    ax7.spines['left'].set_color('none')
    ax7.yaxis.set_major_locator(ticker.NullLocator())
    ax7.spines['top'].set_color('none')    
    
    ax7.set_title( 'Pre_Layer is : ' + pre_layer[4])
    fig.subplots_adjust(hspace=3)  
    if len(pre_layer) == 5:
        sys.exit(0)    
    
    
    

    ax8 = plt.subplot(gs[11:12, 0]) 
    plt.xticks(x, df[pre_layer[5]],rotation=90)
    align_xaxis(ax8, ax1, 0, len(x1))
    
    #plt.violinplot(np.array( df[['TranX_Ovl-X-Max','TranX_Ovl-X-Min','TranX_Met Value']].T), showmeans=False,  showmedians=True)
    ax8.spines['right'].set_color('none')
    ax8.spines['left'].set_color('none')
    ax8.yaxis.set_major_locator(ticker.NullLocator())
    ax8.spines['top'].set_color('none')    
    
    ax8.set_title( 'Pre_Layer is : ' + pre_layer[5])
    fig.subplots_adjust(hspace=3)  
    if len(pre_layer) == 6:
        sys.exit(0)    



    
    #del df
    #del fig
    #plt.cla()    
    #gc.collect()




    ##########################################################
def optvalue_bak():
    toollist = ('ALDI02', 'ALDI03', 'ALDI05', 'ALDI06', 'ALDI07', 'ALDI09',
                'ALDI10', 'ALDI11', 'ALDI12', 'BLDI08', 'BLDI13', 'ALII01',
                'ALII02', 'ALII03', 'ALII04', 'ALII05', 'ALII10', 'ALII11',
                'ALII12', 'ALII13', 'ALII14', 'ALII15', 'ALII16', 'ALII17',
                'ALII18', 'ALSIB6', 'ALSIB7', 'ALSIB8', 'ALSIB9', 'ALSIBJ', 
                 'BLSIBK', 'BLSIBL', 'BLSIE1')
    opt = ['TranX_Optimum','TranY_Optimum','W.Expan.X_Optimum',
           'W.Expan.Y_Optimum','NonOrtho_Optimum','W.Rotation_Optimum',
           'Magnification_Optimum','Rotation_Optimum','AsymMag_Optimum',
           'AsymRot_Optimum','Dcoll Time']
           
           
           
        


    for i, tool in enumerate(toollist):
       
        df = rawovl [ rawovl['Proc EqID'].str.contains(tool)][opt]
        fig = plt.figure(figsize = (18,18))
        plt.subplot(521)        
        plt.plot(list(df[opt[0]]))
        plt.title(tool + ' TranX_Optimum')
        if i<11:
            plt.ylim(-0.06,0.06)
        else:
            plt.ylim(-0.12,0.12)
        plt.hlines(0,0,len(list(df[opt[0]])),colors='r',linestyles='solid',linewidth=3)
        
        
        plt.subplot(522)                       
        plt.plot(list(df[opt[1]]))
        plt.title(tool + ' TranY_Optimum')
        plt.hlines(0,0,len(list(df[opt[0]])),colors='r',linestyles='solid',linewidth=3)        
        if i<11:
            plt.ylim(-0.06,0.06)
        else:
            plt.ylim(-0.12,0.12)
            
            
        
        plt.subplot(523)        
        #plt.xticks( np.arange (df.shape[0]),list(df[opt[10]]),rotation=90)                
        plt.plot(list(df[opt[2]]))
        plt.title(tool + ' W.Expan.X_Optimum')
        plt.hlines(0,0,len(list(df[opt[0]])),colors='r',linestyles='solid',linewidth=3)

        if i<11:
            plt.ylim(-0.6,0.6)
        else:
            plt.ylim(-1,1)


        plt.subplot(524)        
        #plt.xticks( np.arange (df.shape[0]),list(df[opt[10]]),rotation=90)                
        plt.plot(list(df[opt[3]]))
        plt.title(tool + ' W.Expan.Y_Optimum')
        plt.hlines(0,0,len(list(df[opt[0]])),colors='r',linestyles='solid',linewidth=3)
        if i<11:
            plt.ylim(-0.6,0.6)
        else:
            plt.ylim(-1,1)        

        plt.subplot(525)        
        #plt.xticks( np.arange (df.shape[0]),list(df[opt[10]]),rotation=90)                
        plt.plot(list(df[opt[4]]))
        plt.title(tool + ' NonOrtho_Optimum')
        plt.hlines(0,0,len(list(df[opt[0]])),colors='r',linestyles='solid',linewidth=3)
        if i<11:
            plt.ylim(-0.6,0.6)
        else:
            plt.ylim(-1,1)

        plt.subplot(526)        
        #plt.xticks( np.arange (df.shape[0]),list(df[opt[10]]),rotation=90)                
        plt.plot(list(df[opt[5]]))
        plt.title(tool + ' W.Rotation_Optimum')
        plt.hlines(0,0,len(list(df[opt[0]])),colors='r',linestyles='solid',linewidth=3)
        if i<11:
            plt.ylim(-0.6,0.6)
        else:
            plt.ylim(-1,1)        
        

        plt.subplot(527)        
        #plt.xticks( np.arange (df.shape[0]),list(df[opt[10]]),rotation=90)                
        plt.plot(list(df[opt[6]]))
        plt.title(tool + ' Shot Magnification_Optimum')
        plt.hlines(0,0,len(list(df[opt[0]])),colors='r',linestyles='solid',linewidth=3)
        if i<11:
            plt.ylim(-3,3)
        else:
            plt.ylim(-6,6)        
        
        
        
        plt.subplot(528)        
        #plt.xticks( np.arange (df.shape[0]),list(df[opt[10]]),rotation=90)                
        plt.plot(list(df[opt[7]]))
        plt.title(tool + ' Shot Rotation_Optimum')
        plt.hlines(0,0,len(list(df[opt[0]])),colors='r',linestyles='solid',linewidth=3)
        if i<11:
            plt.ylim(-3,3)
        else:
            plt.ylim(-6,6)        
        
        if i < 11:
            plt.subplot(529)        
            #plt.xticks( np.arange (df.shape[0]),list(df[opt[10]]),rotation=90)                
            plt.plot(list(df[opt[8]]))
            plt.title(tool + ' Shot AsymMag_Optimum')
            plt.hlines(0,0,len(list(df[opt[0]])),colors='r',linestyles='solid',linewidth=3)
            if i<11:
                plt.ylim(-3,3)
            else:
                plt.ylim(-6,6)        
            
         
            plt.subplot(5,2,10)        
            #plt.xticks( np.arange (df.shape[0]),list(df[opt[10]]),rotation=90)                
            plt.plot(list(df[opt[9]]))
            plt.title(tool + ' Shot AsymRot_Optimum')
            plt.hlines(0,0,len(list(df[opt[0]])),colors='r',linestyles='solid',linewidth=3)
            if i<11:
                plt.ylim(-3,3)
            else:
                plt.ylim(-6,6)        
        
        plt.savefig('P:\\temp\\OptValueTrend\\' + tool,dpi=100, bbox_inches='tight')
        
        #plt.show()
        plt.close()


     

    ##########################################################



    
   






def cdu_ovl_qc():#所有设备CDU——QC数据
    n = 60 #define time period for data extraction
    databasepath = r'Z:\_DailyCheck\Database\data.mdb'  
    
    
    enddate = datetime.datetime.now().date()
    startdate = enddate - datetime.timedelta(days=n)
    
        
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)  
    rs = win32com.client.Dispatch(r'ADODB.Recordset')
    
    
    sql = "SELECT * FROM CD_data WHERE (Dcoll_Time>#" + str(startdate) + "#) ORDER BY Dcoll_Time"
    
    
    
    sql = "SELECT  \
          Proc_EqID, Dcoll_Time, \
          TranX_Optimum, TranY_Optimum,  ScalX_Optimum, ScalY_Optimum, \
          ORT_Optimum,  Wrot_Optimum, Mag_Optimum, Rot_Optimum,  ARMag_Optimum, ARRot_Optimum \
          FROM CD_date WHERE (Dcoll_Time>#" + str(startdate) + "#) ORDER BY Dcoll_Time"
    
    sql = "SELECT PartID,  \
          Proc_EqID, Dcoll_Time, \
          [1],[2],[3],[4],[5],[6],[7],[8],[9] \
          FROM CD_data WHERE (Dcoll_Time>#" + str(startdate) + "#)  \
          AND (PartID in ('2LXXXSCD01', '2LXXXSCD02', '2LXXXSCD03', '2LXXXSCD04','2LXXXSCD05','2LXXXUCD01','2LXXXUCD02','2LXXXVCD01','2LXXXvCD02')) \
          ORDER BY Dcoll_Time"
                              
                              
                              
    rs.Open(sql, conn, 1, 3)
    
    
    
    cd = []
    rs.MoveFirst()
    
    while True:
        if rs.EOF:
            break
        else:                
            cd.append ([rs.Fields.Item(i).Value for i in range( rs.Fields.Count)] )
            rs.MoveNext()
    
    rs.close
    cd = pd.DataFrame(cd)
    cd.columns = ['PartID','Proc EqID','Dcoll Time','1','2','3','4','5','6','7','8','9']



    
    
    
    
    toollist = ('ALII01', 'ALII02', 'ALII03',
       'ALII04', 'ALII05', 'ALII10', 'ALII11', 'ALII12', 'ALII13',
       'ALII14', 'ALII15', 'ALII16', 'ALII17', 'ALII18', 'ALSIB6',
       'ALSIB7', 'ALSIB8', 'ALSIB9', 'ALSIBJ', 'BLSIBK', 'BLSIBL', 
       'BLSIE1','ALDI02', 'ALDI03', 'ALDI05', 'ALDI06', 'ALDI07', 
       'ALDI09','ALDI10', 'ALDI11', 'ALDI12','BLDI08', 'BLDI13')
    
    for tool in toollist:
        
        y = cd[cd['Proc EqID'] == tool][['1', '2', '3', '4', '5', '6', '7', '8', '9']]
        x = cd[cd['Proc EqID'] == tool] ['Dcoll Time']
        if len(y)>0:
            x = [str(i)[0:-6] for i in x]
            y = np.array(y).T
        
            cdu_plot(tool,x,y)
            print(tool + " CDU")
            plt.clf() # 清图。
            plt.cla() # 清坐标轴。
            plt.close() # 关窗口
            gc.collect()




    sql = "SELECT PartID, \
          Proc_EqID, Dcoll_Time, \
          TranX_OX_min,TranX_OX_max,TranX_Met_Value, \
          TranY_OY_min,TranY_OY_max,TranY_Met_Value, \
          ScalX_Met_Value, ScalY_Met_Value,ORT_Met_Value,Wrot_Met_Value, \
          Mag_Met_Value ,Rot_Met_Value,ARMAG_Met_Value,ARRot_Met_Value \
          FROM OL_ASML WHERE ((Dcoll_Time>#" + str(startdate) + "#)  \
          AND (PartID ='2LXXXSPM01')) ORDER BY Dcoll_Time"
    rs.Open(sql, conn, 1, 3)

    ovl = []
    rs.MoveFirst()
    
    while True:
        if rs.EOF:
            break
        else:                
            ovl.append ([rs.Fields.Item(i).Value for i in range( rs.Fields.Count)] )
            rs.MoveNext()
    
    rs.close
    ovl = pd.DataFrame(ovl)
    ovl.columns =[rs.Fields[i].Name for i in range( rs.Fields.Count)]
    tmp = ovl.columns
    


     

    for tool in toollist:
        if 'DI' in tool:
            sensor = 'SPM'
            output =  ovl[  ovl['Proc_EqID'].str.contains (tool) ]
            if output.shape[0]>0:
                ovl_plot(tool,sensor,output)
                plt.clf() # 清图。
                plt.cla() # 清坐标轴。
                plt.close() # 关窗口
                gc.collect()
                
            


    sql = "SELECT  PartID, \
          Proc_EqID, Dcoll_Time, \
          OffsetX_OX_min,OffsetX_OX_max,OffsetX_Met_Value, \
          OffsetY_OY_min,OffsetY_OY_max,OffsetY_Met_Value, \
          ScalX_Met_Value, ScalY_Met_Value,ORT_Met_Value,Wrot_Met_Value, \
          Mag_Met_Value ,Rot_Met_Value \
          FROM OL_Nikon WHERE ((Dcoll_Time>#" + str(startdate) + "#)  \
          and (PartID like '2LXXX%')) ORDER BY Dcoll_Time"
    rs.Open(sql, conn, 1, 3)

    ovl = []
    rs.MoveFirst()
    
    while True:
        if rs.EOF:
            break
        else:                
            ovl.append ([rs.Fields.Item(i).Value for i in range( rs.Fields.Count)] )
            rs.MoveNext()
    
    rs.close
    ovl = pd.DataFrame(ovl)
    
    ovl['s'] = 0
    ovl ['ss'] = 0
    ovl.columns = tmp


    for tool in toollist:
        if not ('DI' in tool ):

            sensor = 'LSA'        
            output =  ovl[  (ovl['Proc_EqID'].str.contains (tool)) & (ovl['PartID'].str.contains('LSA')) ]
            if output.shape[0] > 0:
                ovl_plot(tool,sensor,output)
                plt.clf() # 清图。
                plt.cla() # 清坐标轴。
                plt.close() # 关窗口
                gc.collect()
        
            sensor = 'FIA'
            output =  ovl[  (ovl['Proc_EqID'].str.contains (tool)) & (ovl['PartID'].str.contains('FIA')) ]
            if output.shape[0] > 0:
                ovl_plot(tool,sensor,output)
        
   
                plt.clf() # 清图。
                plt.cla() # 清坐标轴。
                plt.close() # 关窗口
                gc.collect()






























#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

if __name__=="__main__":
    try:
        pass
    
    ##Windows 任务计划    
        #csv()                  #合并outlook下载的R2R数据
    
        cdu_ovl_qc()
    
        #alltoolovl()           #每台设备5个量产品OVL
        
    ##手动运行python执行,按提示输入查询要求
        
        #cd()        #查看单个产品CD
        #ovl()       #单个产品ovl
        #toolovl()   #单个设备，多个产品OVL
        #bias()      #当前层次OVL及 优化值和前层测量值差值
        #pretool()   #lot各层次作业设备，仅限测试OVL/CD层次
        tmp =open(r'C:\anaconda3\log.txt','a')
        tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___011-QcCduOvl Done\n")
        tmp.close()
    except:
        
        tmp = open(r'C:\anaconda3\log.txt','a')
        tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___011-QcCduOvl Failed\n")
        tmp.close()
    
    
    
    
    
    


















    
    
    
