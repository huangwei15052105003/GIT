# -*- coding: utf-8 -*-
"""
# encoding = 'GB2312' ,encoding='GBK' 
Created on Tue Apr 10 13:06:05 2018

@author: HUANGWEI45

Extract data from p:/database/data.mdb
plot OVL Trend
"""


import matplotlib.pyplot as plt
import pandas as pd
#import os
import xlwings as xw


import win32com.client
#import pytz
import datetime



#import sys
#from matplotlib.gridspec import GridSpec
import gc
#import re
#import matplotlib.ticker as ticker


def extract_data():
    n = 15 #define time period for data extraction
    databasepath = r'p:\Database\data.mdb'  
    
    
    enddate = datetime.datetime.now().date()
    startdate = enddate - datetime.timedelta(days=n)
    
        
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)  
    rs = win32com.client.Dispatch(r'ADODB.Recordset')
    
    
    sql = "SELECT * FROM OL_ASML WHERE (Dcoll_Time>#" + str(startdate) + "#) ORDER BY Dcoll_Time"
    sql = "SELECT  \
          Proc_EqID, Dcoll_Time, \
          TranX_Optimum, TranY_Optimum,  ScalX_Optimum, ScalY_Optimum, \
          ORT_Optimum,  Wrot_Optimum, Mag_Optimum, Rot_Optimum,  ARMag_Optimum, ARRot_Optimum \
          FROM OL_ASML WHERE (Dcoll_Time>#" + str(startdate) + "#) ORDER BY Dcoll_Time"
    
    
    rs.Open(sql, conn, 1, 3)
    
    
    
    asml = []
    rs.MoveFirst()
    
    while True:
        if rs.EOF:
            break
        else:       
            asml.append ([rs.Fields.Item(i).Value for i in range( rs.Fields.Count)] )
            rs.MoveNext()
    
    rs.close
    asml = pd.DataFrame(asml)
    
    sql = "SELECT * FROM OL_NIKON WHERE (Dcoll_Time>#" + str(startdate) + "#) ORDER BY Dcoll_Time"        
    sql = "SELECT  \
          Proc_EqID, Dcoll_Time, \
          OffsetX_Optimum, OffsetY_Optimum, ScalX_Optimum , ScalY_Optimum, \
          ORT_Optimum, Wrot_Optimum , Mag_Optimum , Rot_Optimum  \
          FROM OL_NIKON WHERE (Dcoll_Time>#" + str(startdate) + "#) ORDER BY Dcoll_Time"        
    rs.Open(sql, conn, 1, 3) 
    
    nikon = []
    rs.MoveFirst()
    while True:
        if rs.EOF:
            break
        else:        
            nikon.append ([rs.Fields.Item(i).Value for i in range( rs.Fields.Count)] )
            rs.MoveNext()
    rs.close
    nikon = pd.DataFrame(nikon)
    
    conn.close
    
    return asml, nikon














def optvalue(asml,nikon):
    df = pd.concat([asml,nikon],axis=0).fillna(0)
    df[1] = [ datetime.datetime.strptime (str(i)[0:-6],'%Y-%m-%d %H:%M:%S') for i in df[1]]    
    
    df = df.reset_index().set_index(1)

    toollist = ('ALDI02', 'ALDI03', 'ALDI05', 'ALDI06', 'ALDI07', 'ALDI09', 'ALDI10', 'ALDI11', 'ALDI12', 'BLDI08', 'BLDI13',
           'ALII01','ALII02', 'ALII03', 'ALII04', 'ALII05', 'ALII10', 'ALII11','ALII12', 'ALII13', 'ALII14', 'ALII15', 'ALII16', 'ALII17',
                'ALII18', 'ALSIB6', 'ALSIB7', 'ALSIB8', 'ALSIB9', 'ALSIBJ', 'BLSIBK', 'BLSIBL', 'BLSIE1')
            
                 
                 
 

       
           
    #wb = xw.Book(r'p:\RoutineWork\ScriptSaving.xlsx')    
    #sht = wb.sheets["OvlOpt"]          


    for i, tool in enumerate(toollist): 

        #df = df.sort(['Dcoll Time'] , ascending=True)
        
        print ( tool + ' is being updated......')
        
        tmp = df[df[0] == tool]
        if tmp.shape[0] > 0:
        
            fig = plt.figure(figsize = (30,16))
            
    
            ax1 = plt.subplot(421) 
            #tmp[2].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
            tmp[2].plot(marker='o',linestyle=':',color='r',legend=False)#linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)        
            plt.ylim(-0.1,0.1)
            plt.title( tool + '  ' + "Optimum Tran-X")
            ax1.yaxis.grid(True)
            ax1.xaxis.grid(True)
            if i<11:
                plt.ylim(-0.06,0.06)
            else:
                plt.ylim(-0.12,0.12)
            
            
            
            ax2 = plt.subplot(422) 
            #tmp[3].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
            tmp[3].plot(marker='o',linestyle=':',color='r',legend=False)
            ax2.yaxis.grid(True)
            ax2.xaxis.grid(True)        
            plt.title( tool + '  ' + "Optimum Tran-Y")
            if i<11:
                plt.ylim(-0.06,0.06)
            else:
                plt.ylim(-0.12,0.12)        
            
            ax3 = plt.subplot(423) 
            #tmp[4].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
            tmp[4].plot(marker='o',linestyle=':',color='r',legend=False)
            plt.title( tool + '  ' + 'W.Expan.X_Optimum')
            ax3.yaxis.grid(True)
            ax3.xaxis.grid(True)
            if i<11:
                plt.ylim(-0.6,0.6)
            else:
                plt.ylim(-1,1)
            
            ax4 = plt.subplot(424) 
            #tmp[5].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
            tmp[5].plot(marker='o',linestyle=':',color='r',legend=False)
    
            plt.title( tool + '  ' + 'W.Expan.Y_Optimum')
            ax4.yaxis.grid(True)
            ax4.xaxis.grid(True)
            if i<11:
                plt.ylim(-0.6,0.6)
            else:
                plt.ylim(-1,1)
            
            ax5 = plt.subplot(425) 
            #tmp[6].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
            tmp[6].plot(marker='o',linestyle=':',color='r',legend=False)
            plt.title( tool + '  ' + 'NonOrtho_Optimum')
            ax5.yaxis.grid(True)
            ax5.xaxis.grid(True)
            if i<11:
                plt.ylim(-0.6,0.6)
            else:
                plt.ylim(-1,1)        
            
            ax6 = plt.subplot(426) 
            #tmp[7].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
            tmp[7].plot(marker='o',linestyle=':',color='r',legend=False)
            ax6.yaxis.grid(True)
            ax6.xaxis.grid(True)
            plt.title( tool + '  ' + 'W.Rotation_Optimum')
            if i<11:
                plt.ylim(-0.6,0.6)
            else:
                plt.ylim(-1,1)         
            
            ax7 = plt.subplot(427) 
            #tmp[8].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
            tmp[8].plot(marker='o',linestyle=':',color='r',legend=False)
            ax7.yaxis.grid(True)
            ax7.xaxis.grid(True)  
            plt.title( tool + '  ' + 'Shot Magnification_Optimum')
            if i<11:
                plt.ylim(-3,3)
            else:
                plt.ylim(-6,6)         
            
            ax8 = plt.subplot(428)
             
            #tmp[9].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
            tmp[9].plot(marker='o',linestyle=':',color='r',legend=False)
            ax8.yaxis.grid(True)
            ax8.xaxis.grid(True)             
            plt.title( tool + '  ' + 'Shot Rotation_Optimum')
            if i<11:
                plt.ylim(-3,3)
            else:
                plt.ylim(-6,6)         
            '''
            ax9 = plt.subplot(529) 
            #tmp[10].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
            tmp[10].plot(marker='o',linestyle=':',color='r',legend=False)
            ax9.yaxis.grid(True)
            ax9.xaxis.grid(True)              
            plt.title( tool + '  ' + 'Shot AsymMag_Optimum')
            if i<11:
                plt.ylim(-3,3)
            else:
                plt.ylim(-6,6)        
            
            ax10 = plt.subplot(5,2,10)
 
            #tmp[11].plot(linewidth = '0.1',kind='line',marker='o',linestyle=':',color='r',legend=False)
            tmp[11].plot(marker='o',linestyle=':',color='r',legend=False)
            ax10.yaxis.grid(True)
            ax10.xaxis.grid(True)                     
            plt.title( tool + '  ' + 'Shot AsymRot_Optimum')
            if i<11:
                plt.ylim(-3,3)
            else:
                plt.ylim(-6,6) 
            '''
            fig.subplots_adjust(hspace=0.5)
            
            plt.savefig('P:\\_DailyCheck\\OptOvl_Others\\OvlPicture\\' + tool ,dpi=100, bbox_inches='tight')
            
            #sht.pictures.add(fig, name=(tool + '_Optimum Value'), update=True,
            #                 left=sht.range('A2').left, top=sht.range('A2').top)
                    
    
            plt.clf() # 清图。
            plt.cla() # 清坐标轴。
            plt.close() # 关窗口
            gc.collect()        


##########################################################################################################



    #wb.save()
    #wb.close()
        



asml,nikon = extract_data()
optvalue(asml,nikon)






























       



['Tech',
 'PartID',
 'Layer',
 'LotID',
 'Proc_EqID',
 'Ji_Time',
 'Met_EqID',
 'Dcoll_Time',
 'Wafer_ID',
 'OffsetX_jobin',
 'OffsetX_Feedback',
 'OffsetX_Optimum',
 'OffsetX_Met_Avg',
 'OffsetX_Met_Value',
 'OffsetX_OX_min',
 'OffsetX_OX_max',
 'OffsetY_jobin',
 'OffsetY_Feedback',
 'OffsetY_Optimum',
 'OffsetY_Met_avg',
 'OffsetY_Met_value',
 'OffsetY_OY_Min',
 'OffsetY_OY_Max',
 'ScalX_jobin',
 'ScalX_Feedback',
 'ScalX_Optimum',
 'ScalX_Met_avg',
 'ScalX_Met_value',
 'ScalY_jobin',
 'ScalY_Feedback',
 'ScalY_Optimum',
 'ScalY_Met_avg',
 'ScalY_Met_value',
 'ORT_jobin',
 'ORT_Feedback',
 'ORT_Optimum',
 'ORT_Met_avg',
 'ORT_Met_Value',
 'Wrot_jobin',
 'Wrot_Feedback',
 'Wrot_Optimum',
 'Wrot_Met_avg',
 'Wrot_Met_value',
 'Mag_jobin',
 'Mag_Feedback',
 'Mag_Optimum',
 'Mag_Met_avg',
 'Mag_Met_value',
 'Rot_jobin',
 'Rot_Feedback',
 'Rot_Optimum',
 'Rot_Met_avg',
 'Rot_Met_value']






        
['Tech',
 'PartID',
 'Layer',
 'LotID',
 'Proc_EqID',
 'Ji_Time',
 'Met_EqID',
 'Dcoll_Time',
 'Wafer_ID',
 'TranX_jobin',
 'TranX_Feedback',
 'TranX_Optimum',
 'TranX_Met_Avg',
 'TranX_Met_Value',
 'TranX_OX_min',
 'TranX_OX_max',
 'TranY_jobin',
 'TranY_Feedback',
 'TranY_Optimum',
 'TranY_Met_avg',
 'TranY_Met_value',
 'TranY_OY_Min',
 'TranY_OY_Max',
 'ScalX_jobin',
 'ScalX_Feedback',
 'ScalX_Optimum',
 'ScalX_Met_avg',
 'ScalX_Met_value',
 'ScalY_jobin',
 'ScalY_Feedback',
 'ScalY_Optimum',
 'ScalY_Met_avg',
 'ScalY_Met_value',
 'ORT_jobin',
 'ORT_Feedback',
 'ORT_Optimum',
 'ORT_Met_avg',
 'ORT_Met_Value',
 'Wrot_jobin',
 'Wrot_Feedback',
 'Wrot_Optimum',
 'Wrot_Met_avg',
 'Wrot_Met_value',
 'Mag_jobin',
 'Mag_Feedback',
 'Mag_Optimum',
 'Mag_Met_avg',
 'Mag_Met_value',
 'Rot_jobin',
 'Rot_Feedback',
 'Rot_Optimum',
 'Rot_Met_avg',
 'Rot_Met_value',
 'ARMAG_jobin',
 'ARMag_Feedback',
 'ARMag_Optimum',
 'ARMag_Met_avg',
 'ARMag_Met_value',
 'ARRot_jobin',
 'ARRot_Feedback',
 'ARRot_Optimum',
 'ARRot_Met_avg',
 'ARRot_Met_value']

























