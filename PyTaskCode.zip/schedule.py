# -*- coding: utf-8 -*-
"""
Created on Wed Aug 15 07:51:59 2018

@author: HUANGWEI45
"""

import schedule
import datetime
import time

def job():
    print (str(datetime.datetime.now()) + "        This is a job.....")
    
schedule.every(100).seconds.do(job)
schedule.every(100).minutes.do(job)
schedule.every().hour.do(job)
schedule.every().day.at("10:08").do(job)
schedule.every().wednesday.do(job)
schedule.every().wednesday.at("17:00").do(job)
schedule.every(5).to(10).days.do(job)

while True:
    schedule.run_pending()
    time.sleep(1)