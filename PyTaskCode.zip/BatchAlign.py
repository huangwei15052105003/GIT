# -*- coding: utf-8 -*-
"""
Created on Thu Sep 13 17:00:08 2018

@author: huangwei45
"""

import os
import pandas as pd


def get_filename(folder ):
    
    filenamelist=[]
    for root, dirs, files in os.walk(folder, False):  #root:所有目录名-->字符串 #dirs: root下的子目录名-->列表 #files：root下的文件名-->列表 # name.endswith(ext)-->文件名筛选 
        for names in files:
            if names.endswith('.txc'):
                filenamelist.append( root  + '/' + names) 
    filenamelist.sort(reverse = False)
    return (filenamelist)


for toolid in ['7D','08','82','83','85','87','8B']: 
    #filenamelist = get_filename(folder = r'Y:\ASML_BATCHALIGN_REPORT\85')
    folder = 'Z:\\BatchAlignmentReport\\RawData\\' + toolid
    filenamelist = get_filename(folder)
    
    
    df=[]
    n=0
    
    for n,file in enumerate( filenamelist ):
        print(n,"---",file)                
        f = open(file)                
        tmp = [ i.strip() for i in f.readlines() if i.strip() !=""]
        if len(tmp) > 100:
            data = []
            data.append(file) 
            try: #in case some files are modified,error triggered
                x=[i.strip() for i in tmp[0].split(' ') if i.strip() !='']
                
                data.extend(x)
                
                data.append(tmp[2].split(' ')[-1])
                data.append(tmp[3].split(' ')[-1])
                data.append(tmp[5].split(':')[1].strip().split(' ')[0])
    
                
                if tmp[9].strip() == 'SUMMARY': #XPA strategy is missed, 
                   
                    data.append(tmp[10].split(':')[1].strip())    
                    data.append(tmp[11].split(':')[1].strip())
                    
                    
                    for i in [19,20,21,22,24,25,26,27,29,30,31,32]:
                        try: #in case of zero WQ of some orders, data format is not correct
                            y = []
                            y.extend([ii for ii in tmp[i].split('|')[2].strip().split(' ') if ii != ''])
                            y.extend([ii for ii in tmp[i].split('|')[3].strip().split(' ') if ii != ''])
                            y.extend([ii for ii in tmp[i].split('|')[4].strip().split(' ') if ii != ''])
                            y.extend([ii for ii in tmp[i].split('|')[5].strip().split(' ') if ii != ''])
                            data.extend(y)
                        except:
                            pass
                    df.append(data)
                    
                elif tmp[17].strip() == 'SUMMARY':
                    #print('01')
                    data.append(tmp[18].split(':')[1].strip())    
                    data.append(tmp[19].split(':')[1].strip()) 
                    for i in [27,28,29,30,32,33,34,35,37,38,39,40]:
                        try:
                            y = []
                            y.extend([ii for ii in tmp[i].split('|')[2].strip().split(' ') if ii != ''])
                            y.extend([ii for ii in tmp[i].split('|')[3].strip().split(' ') if ii != ''])
                            y.extend([ii for ii in tmp[i].split('|')[4].strip().split(' ') if ii != ''])
                            y.extend([ii for ii in tmp[i].split('|')[5].strip().split(' ') if ii != ''])
                            data.extend(y)
                        except:
                            pass
        
            except:
                pass
            df.append(data)        
                
                
                
                
                
                
            n += 1
            if n>300000000000000:
                break
        
        
    df = pd.DataFrame(df)
    df.to_csv('Y:/ASML_BATCHALIGN_REPORT/' + toolid + '.csv')
    










#365 --- Z:\BatchAlignmentReport\RawData\82\A14401BA\GT\PK5K0Y.1_0.txc
#366 --- Z:\BatchAlignmentReport\RawData\82\A14729BA-L\GT\CK5H0N.1_0.txc