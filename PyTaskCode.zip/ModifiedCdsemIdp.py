# -*- coding: utf-8 -*-
"""
Created on Wed Dec 26 09:41:15 2018

@author: huangwei45


---run at 10.4.3.111
---sumarize modified idp

"""
import os
import pandas as pd

path = 'e:/mike/cd/list/'

filelist = [ path + i for i in os.listdir(path) if "IDP" in i]
today = []
for file in filelist:
    tool = file.split('/')[4].split('.')[0]
    tmp = [[i.strip(),tool] for i in open(file)]
    today.extend(tmp)
df = pd.DataFrame(today)

df.to_csv('y:/ModifiedCdSemIDP/ChangeList.csv',mode='a',index=None,header=None)


#%%
bt = os.listdir('p:/Recipe/Biastable/')

bt = [ 'p:/Recipe/Biastable/' + i for i in bt if 'xl' in i]

idp = pd.read_csv('y:/ModifiedCdSemIDP/changelist.csv')
idp['Part']= [ i.split('/')[6].split('.')[0]  for i in idp['IDP'] ]


    
bt = pd.DataFrame(bt)
bt.columns = ['Path']
bt['Part'] = [ i.split('/')[3].split('.')[0] for i in bt['Path']]

df = pd.merge(idp,bt,how = 'left', on = 'Part')
df.to_csv('y:/modifiedcdsemidp/WithoutBiasTable.csv')