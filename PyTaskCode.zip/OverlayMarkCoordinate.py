# -*- coding: utf-8 -*-
"""
Created on Tue Sep 18 10:22:11 2018

@author: huangwei45
"""


import pandas as pd
#from win32com import client
import os
import datetime

##https://blog.csdn.net/qq_34475777/article/details/62055523
#https://blog.csdn.net/pipisorry/article/details/50368044


#StepSize.csv: step size from asml file
#reference.csv: ovl coordinate from CE tooling
#BiasTable.csv: overlay tree from bias table
#zuobiao.csv:   overlay coordinate from jobfile
#StandardFlow.csv: PROMIS FLOW, RECIPEID




def read_asml_step_size():
    asmlfilepath = 'P:/Recipe/ASMLBACKUP/'  #only latest files
    asmlfilepathnew = 'P:/Recipe/recipe/'
    filelist = []
    for file in os.listdir(asmlfilepath):
        filelist.append(os.path.join(asmlfilepath, file))
    for file in os.listdir(asmlfilepathnew):
        filelist.append(os.path.join(asmlfilepathnew, file))  
        
    old =set( pd.read_csv('y:/overlay/StepSize.csv',header=0,usecols=['Path'])['Path'])        
    filelist = set(filelist) - old    

    stepSize = []
    fail = []
    for n,file in enumerate(filelist):
        print(n,'--',file)
        try:
            tmp= [ i.strip('\n') for i in open(file).readlines() if i.strip()[0:22] ==  'Cell Size [mm]       X'  ][0].strip().split(':')
            stepSize.append([file.split('/')[3],eval(tmp[1].strip().split(' ')[0]),eval(tmp[2].strip()),file])
        except:
            fail.append(file)
    stepSize = pd.DataFrame(stepSize,columns = ['Part','StepX','StepY','Path']).drop_duplicates()

    stepSize.to_csv('y:/overlay/StepSize.csv',index = False,mode='a',header = False)
            
    log = open('y:/overlay/log.txt','a')
    log.write("\n" + str(datetime.datetime.now())[0:19] +'_  '+ str(stepSize.shape[0]) +'  _rows stepsize data added')
    log.close() 

    
    












def read_standard_coordinate():
    old =set( pd.read_csv('y:/overlay/reference.csv',header=0,usecols=['Path'])['Path'])
    
    filelist = []
    path = r'P:\Recipe\Coordinate'
    for file  in os.listdir(path):
        #if file[-3:]=='doc' or file[-4:]=='docx':
        if file[-3:]=='txt':
            filelist.append(os.path.join(path, file))
            
    filelist = set(filelist)-old       
            
    
    fail=[]
    data = pd.DataFrame(columns = ['PPID', 'LDx', 'LDy', 'RDx', 'RDy', 'RUx', 'RUy', 'LUx', 'LUy', 'Path'])
    
    for n,file in enumerate(filelist):
        print(n,'---',file)
        try:
        
            f = [ i.strip('\n') for i in open(file).readlines() if ( i.strip('\n') !=''  and 'BAR '  in i )]
            if len(f)>4:
                f = [i.replace( '\t\t\t', '_') for i in f]
                f = [i.replace( '\t\t', '_') for i in f]
                
                ld = f.index('BAR IN BAR\tLD\tbar_bar')
                rd = f.index('BAR IN BAR\tRD\tbar_bar')       
                lu = f.index('BAR IN BAR\tLU\tbar_bar')        
                ru = f.index('BAR IN BAR\tRU\tbar_bar') 
        
                
                LD = [ i.split(' ')[1] for i in f[ld+1:rd] ]
                LD=pd.DataFrame([i.split('_') for i in LD]).reset_index().set_index(0)
                LD = LD.drop(columns = 'index')
                LD.columns=['LDx','LDy']
                
                RD = [ i.split(' ')[1] for i in f[rd+1:lu]] 
                RD=pd.DataFrame([i.split('_') for i in RD]).reset_index().set_index(0)
                RD = RD.drop(columns = 'index')
                RD.columns=['RDx','RDy']             
                
                LU = [ i.split(' ')[1] for i in f[lu+1:ru]]  
                LU=pd.DataFrame([i.split('_') for i in LU]).reset_index().set_index(0)
                LU = LU.drop(columns = 'index')
                LU.columns=['LUx','LUy']
                  
                RU = [ i.split(' ')[1] for i in f[ru+1:]]
                RU=pd.DataFrame([i.split('_') for i in RU]).reset_index().set_index(0)
                RU = RU.drop(columns = 'index')
                RU.columns=['RUx','RUy']            
                
                tmp = pd.concat([LD,RD,RU,LU],axis=1)
                tmp['Path']=file
                tmp=tmp.reset_index()
                tmp.columns = ['PPID', 'LDx', 'LDy', 'RDx', 'RDy', 'RUx', 'RUy', 'LUx', 'LUy', 'Path']
                                                        
                data = pd.concat([data,tmp])
            else:
                fail.append(file)
           
            
        except:
            fail.append(file)
            

        
        
    if len(fail)>0:
        fail = pd.DataFrame(fail)
        fail.columns = ['Path']
        data = pd.concat([data,fail])
    data = data[['LDx','LDy'	,'LUx','LUy','RDx','RDy','RUx',	'RUy',	'PPID','Path']]
    data.to_csv('Y:/overlay/reference.csv',mode='a',header = None,index = False)    
    
    
    log = open('y:/overlay/log.txt','a')
    log.write("\n" + str(datetime.datetime.now())[0:19] +'_  '+ str(data.shape[0]) +'  _rows standard data added')
    log.close() 

    
   
    
    
    
    
    
    
    
    
    
    
    
    
    
 
def read_bias_table():
    path =  'P:/recipe/biastable/' 
    filelist = []
    for file in os.listdir(path):
        filelist.append(os.path.join(path, file))
    
    old =set( pd.read_csv('y:/overlay/BiasTable.csv',header=0,usecols=['Path'])['Path'])        
    filelist = set(filelist) - old    

    tmp1=pd.DataFrame(columns =['PPID','Part','OVL-PPID','Path'])
    fail=[]
    
    for n,file in enumerate(filelist):
        print(n,'===',file)
        try:            
            BiasTable= pd.read_excel(file)
            BiasTable.columns = [ i for i in range(len(BiasTable.columns))]
            BiasTable = BiasTable[[6,19]].dropna()
            tmp=[]
            for i in list(BiasTable[6]):
                if len(i) > 3:
                    tmp.append(i[-3:-1])
                else:
                    tmp.append(i)
            
            
            #BiasTable['PPID']=BiasTable[6]+ '-' + BiasTable[19]
            BiasTable['PPID']=[tmp[i] + '-' + list(BiasTable[19])[i] for i in range(len(tmp))]
            BiasTable['Part']=file.split('/')[3].split('.')[0]
            BiasTable['OVL-PPID'] = BiasTable['Part'] + '-' + tmp #BiasTable[6]
            BiasTable = BiasTable.drop(columns=[6,19])
            BiasTable['Path'] = file
            tmp1 = pd.concat([tmp1,BiasTable])
        
      
        except:
            fail.append(file) 
            
    BiasTable = pd.DataFrame(tmp1)
    BiasTable.to_csv('y:/overlay/BiasTable.csv',index=False,mode='a',header= None)
    log = open('y:/overlay/log.txt','a')
    log.write("\n" + str(datetime.datetime.now())[0:19] +'_  '+ str(BiasTable.shape[0]) +'  _rows bias table data added')
    log.close() 

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

def get_path(FileDir = r'P:\OVLdata\GOL'):   
    filenamelist=[]
    for root, dirs, files in os.walk(FileDir, False):  #root:所有目录名-->字符串 #dirs: root下的子目录名-->列表 #files：root下的文件名-->列表 # name.endswith(ext)-->文件名筛选 
        for names in files:

            filenamelist.append( root  + '\\' + names) 
    filenamelist.sort(reverse = False)
    return (filenamelist)


    
#file = 'P:\\OVLdata\\Old\\91CH8S1A.1-2-09.26.16 15.50.51.txt'
#file =  r'P:\OVLdata\Old\57CJCQ01.3-12.07.17 21.59.47.txt'   
# f = [i.strip('\n') for i in open(file).readlines()]    




def read_raw_data():
    filelist =set( get_path(FileDir = r'P:\OVLdata\Old'))
    old = set (pd.read_csv('y:/overlay/zuobiao.csv',usecols=['Path'])['Path'])
    filelist = filelist - old
    result=[]
    fail=[]

    for n, file in enumerate(filelist):
        transfer=[]
        print(n,'----',file,'\n')
        try:
            #df = pd.read_csv(file,header = None)
            f = [i.strip('\n') for i in open(file).readlines()] 
            #riqi = df.loc[0][0].split('\t')[0]
            riqi = f[0].split('\t')[0]
            #ppid = df.loc[2][0].split(' ')[1][6:-1]
            ppid = f[2].split(' ')[1][6:-1]
            #tmp = df[df[0].str[0:8]==('Location')]
            tmp = [ i for i in f if i[0:8]==('Location')]
            
            zuobiao = [ (eval(i.split(' ')[1][2:]),eval(i.split(' ')[3][2:]))   for i in tmp]
            
            
     
            if len(zuobiao) > 0:
           
                tmp = pd.DataFrame(zuobiao).drop_duplicates() 
                zb =  tmp.values.reshape(tmp.shape[0]*tmp.shape[1],order="C")
                #multiwafers measured, delete duplicates of coordinate
                #to keep ID sequence,swithched to DataFrame ,otherwise use "SET"

                #zuobiao =list(  zip (tmp[0],tmp[1]) )
                
                tmp = tmp.describe().loc['max']
                transfer.extend([riqi,ppid,tmp[0],tmp[1],file,len(zb)])
                transfer.extend(zb)
                result.append(transfer)
            else:
                fail.append(file)
        except:
            fail.append(file)

    try: 
        
        df = pd.DataFrame(result) 
        tmp =[i for i in df.columns]
        tmp[0] ='RiQi'
        tmp[1] = 'Part'
        tmp[2] = 'Max_x'
        tmp[3] = 'Max-y'
        tmp[4] = 'Path'
        tmp[5] = 'Count'
        df.columns = tmp

    
            
    
        df['OVL-PPID'] = [i.split('\\')[1] for i in df['Part']]
        df['part'] = [i.split('\\')[0] for i in df['Part']]
        
        tmp = pd.DataFrame(columns = ['RiQi','Part'	,'Max_x','Max-y'	,'Path','Count',6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,'OVL-PPID','part'])
        df = pd.concat([tmp,df])
        #df['count'] = [len(i) for i in df['zuobiao']]

        df = df[['RiQi','Part'	,'Max_x','Max-y'	,'Path','Count',6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,'OVL-PPID','part']]
        df.to_csv('y:/overlay/zuobiao.csv',mode='a',header=None,index=None)        
    except:
        pass
    
    for i in fail:
        os.remove(i)
    
    
    log = open('y:/overlay/log.txt','a')
    log.write("\n" + str(datetime.datetime.now())[0:19] +'_  '+ str(df.shape[0]) +'  _rows raw data added')
    log.close() 

























def partname_to_be_checked(referencepath='Y:/overlay/reference.csv'):
    coordinate = pd.read_csv(referencepath)
    coordinate = coordinate.dropna()
    partlist =  [ i[3].split('.')[0] for i in coordinate['Path'].str.split('\\') ] 
    coordinate['Part'] = partlist #parts with OVL coordinate
    partlist =list( set(partlist))
    #==============================================================
        
    #Part,OVL PPID, scanner/stepper type -->standard naming rule from MFG DB
    mfg = pd.read_excel(r'D:\HuangWeiScript\PyTaskCode\R2R_New_Part.xlsm',sheet_name = 'PPID',header = None)        
    LOL =pd.DataFrame( [i.split('_') for i in mfg[6].dropna()],columns=['Part','Stage','OVL-PPID'] )
    #LOL = LOL.drop(columns='LOL')
    
    ToolType = pd.DataFrame( [i.split('_') for i in mfg[9].dropna()],columns=['Tech','Part','Stage','ToolType'] )
    
   
    flow = pd.merge(LOL,ToolType,on=['Part','Stage'],how='left')
    flow['Part']=[i.split('.')[0] for i in flow['Part']]
    flow = flow[['Part', 'Stage', 'OVL-PPID', 'ToolType']]
    flow = flow.fillna('LII')
    mfg,LOL,ToolType = None,None,None
    flow.to_csv('y:/overlay/StandardFlow.csv',index=False) # not necessary to save it
    
    log = open('y:/overlay/log.txt','a')
    log.write("\n" + str(datetime.datetime.now())[0:19] +'_  '+ str(flow.shape[0]) +'  _are standard PPID qty')
    log.close()
    
    return flow
    
    
    
    

    
def compare(flow):
    
    #bak = flow.copy()
    
    #flow = pd.read_csv('y:/overlay/StandardFlow.csv')
    
    ## merge bias table ,get OVL measurment sequence
    tmp = pd.read_csv('Y:/overlay/biastable.csv')[['PPID', 'Part', 'OVL-PPID']]
    df = pd.merge(flow,tmp,on=['Part','OVL-PPID'],how='left')
    df = df.fillna('')
    
    ## merge step size
    tmp = pd.read_csv('Y:/overlay/stepsize.csv')[['Part', 'StepX', 'StepY']]
    df = pd.merge(df,tmp,on=['Part'],how='left')
    df = df.fillna('')

    ## merge standard coordinate
    tmp = pd.read_csv('Y:/overlay/reference.csv')#[['Part', 'StepX', 'StepY']]
    tmp['Part'] = [i.split('\\')[3].split('.')[0] for i in list(tmp['Path']) ]
    tmp = tmp[['LDx', 'LDy', 'RDx', 'RDy','RUx', 'RUy' ,'LUx', 'LUy', 'PPID','Part']]
    df = pd.merge(df,tmp,on=['Part','PPID'],how='left')
    df = df.fillna('')
    
    ##merge jobfile coordinates
    tmp = pd.read_csv('Y:/overlay/zuobiao.csv')[[ 'Path', 'Count', '6', '7', '8', '9',
       '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21',
       'OVL-PPID']].fillna('')
    tmp.columns = [ 'Path', 'Count', 'm11', 'm12', 'm21', 'm22',
       'm31', 'm32', 'm41', 'm42', 'm51', 'm52', 'm61', 'm62', 'm71', 'm72', 'm81', 'm82',
       'OVL-PPID']
    
    tmpQ200 = pd.read_csv('y:/overlay/q200.csv')
    tmpQ200.columns = ['OVL-PPID', 'm11', 'm12', 'm21', 'm22', 'm31', 'm32', 'm41', 'm42', 'Path']
    tmpQ200['m11']=tmpQ200['m11']/1000
    tmpQ200['m12']=tmpQ200['m12']/1000    
    tmpQ200['m21']=tmpQ200['m21']/1000    
    tmpQ200['m22']=tmpQ200['m22']/1000    
    tmpQ200['m31']=tmpQ200['m31']/1000
    tmpQ200['m32']=tmpQ200['m32']/1000
    tmpQ200['m41']=tmpQ200['m41']/1000  
    tmpQ200['m42']=tmpQ200['m42']/1000    
    
    
    tmpQ200['Count']=4    
    
    tmp = pd.concat([tmp,tmpQ200],axis=0)
    tmp.to_csv('c:/temp/te.csv')
    tmp = tmp.fillna('')
    
    
    
    df = pd.merge(df,tmp,on=['OVL-PPID'],how='left').fillna('')






    
    df.to_csv('y:/overlay/compare_raw.csv',index=None)
    
    #df.to_csv('p:/compare_raw.csv',index=None)
    
    
    
    #df= pd.read_csv('y:/overlay/compare_raw.csv')
    
    
    
        
    
    df[['StepX', 'StepY', 'LDx', 'LDy', 'RDx', 'RDy', 'RUx', 'RUy', 'LUx', 'LUy', 'Count',
       'm11', 'm12', 'm21', 'm22', 'm31', 'm32', 'm41', 'm42', 'm51', 'm52',
       'm61', 'm62', 'm71', 'm72', 'm81', 'm82']]   = df[['StepX', 'StepY', 'LDx', 'LDy', 'RDx', 'RDy', 'RUx', 'RUy', 'LUx', 'LUy', 'Count',
       'm11', 'm12', 'm21', 'm22', 'm31', 'm32', 'm41', 'm42', 'm51', 'm52',
       'm61', 'm62', 'm71', 'm72', 'm81', 'm82']].apply(pd.to_numeric,errors='ignore')

    bak = df.copy()   

 
    
    df = df[df['RDx']==df['RDx']]
    df = df[df['m42']==df['m42']]  
    #Nikon large field
    df1 = df[df['Part'].str.endswith('-L')]
    df1 = df1[df1['ToolType']=='LII']
    df1 = df1[df1['Count']==8]
    
    df1['t11'] = (df1['LDx']/1000 + df1['StepY']/4)  * 1000 
    df1['t12'] = (df1['LDy']/1000 + df1['StepX']/2) * 1000 
    
    df1['t21'] = (df1['RDx']/1000 + df1['StepY']/4)  * 1000 
    df1['t22'] = (df1['RDy']/1000 + df1['StepX']/2)   * 1000 
    
    df1['t31'] = (df1['RUx']/1000 + df1['StepY']/4)  * 1000 
    df1['t32'] = (df1['RUy']/1000 + df1['StepX']/2)   * 1000 
    
    df1['t41'] = (df1['LUx']/1000 + df1['StepY']/4)   * 1000 
    df1['t42'] = (df1['LUy']/1000 + df1['StepX']/2)     * 1000 
    
    
    
    df1['d11'] = ((df1['LDx']/1000 + df1['StepY']/4) - df1['m11'])  * 1000 
    df1['d12'] = ((df1['LDy']/1000 + df1['StepX']/2) - df1['m12'])  * 1000 
    
    df1['d21'] = ((df1['RDx']/1000 + df1['StepY']/4) - df1['m21'])  * 1000 
    df1['d22'] = ((df1['RDy']/1000 + df1['StepX']/2) - df1['m22'])  * 1000 
    
    df1['d31'] = ((df1['RUx']/1000 + df1['StepY']/4) - df1['m31'])  * 1000 
    df1['d32'] = ((df1['RUy']/1000 + df1['StepX']/2) - df1['m32'])  * 1000 
    
    df1['d41'] = ((df1['LUx']/1000 + df1['StepY']/4) - df1['m41'])  * 1000 
    df1['d42'] = ((df1['LUy']/1000 + df1['StepX']/2) - df1['m42'])   * 1000   
    
    
    
    

    df1['c11'] = abs((df1['LDx']/1000 + df1['StepY']/4) - df1['m11']) <0.020
    df1['c12'] = abs((df1['LDy']/1000 + df1['StepX']/2) - df1['m12']) <0.020
    
    df1['c21'] = abs((df1['RDx']/1000 + df1['StepY']/4) - df1['m21']) <0.020
    df1['c22'] = abs((df1['RDy']/1000 + df1['StepX']/2) - df1['m22']) <0.020
    
    df1['c31'] = abs((df1['RUx']/1000 + df1['StepY']/4) - df1['m31']) <0.020
    df1['c32'] = abs((df1['RUy']/1000 + df1['StepX']/2) - df1['m32']) <0.020
    
    df1['c41'] = abs((df1['LUx']/1000 + df1['StepY']/4) - df1['m41']) <0.020
    df1['c42'] = abs((df1['LUy']/1000 + df1['StepX']/2) - df1['m42']) <0.020  
    
    df1['check'] = [ df1['c11'][i] and df1['c12'][i] and df1['c21'][i] and df1['c22'][i] and 
                     df1['c31'][i] and df1['c32'][i] and df1['c41'][i] and df1['c42'][i]     
                    for i in df1.index]

    #Asml large filed
    df2 = df[df['Part'].str.endswith('-L')]
    df2 = df2[df2['ToolType']=='LDI']
    df2 = df2[df2['Count']==16]
    
    
    df2['t11'] = (df2['RDy']/1000 + df2['StepX']/2)  * 1000 
    df2['t12'] = (-df2['RDx']/1000 + df2['StepY']/4)  * 1000 
    
    df2['t21'] = (df2['RUy']/1000 + df2['StepX']/2)  * 1000 
    df2['t22'] = (-df2['RUx']/1000 + df2['StepY']/4) * 1000 
    
    df2['t31'] = (df2['LUy']/1000 + df2['StepX']/2)  * 1000 
    df2['t32'] = (-df2['LUx']/1000 + df2['StepY']*3/4)  * 1000 
    
    df2['t41'] = (df2['LDy']/1000 + df2['StepX']/2)  * 1000 
    df2['t42'] = (-df2['LDx']/1000 + df2['StepY']*3/4)  * 1000 
    
    df2['t51'] = (df2['RDy']/1000 + df2['StepX']/2)  * 1000 
    df2['t52'] = (-df2['RDx']/1000 + df2['StepY']*3/4)  * 1000 
    
    df2['t61'] = (df2['RUy']/1000 + df2['StepX']/2)  * 1000 
    df2['t62'] = (-df2['RUx']/1000 + df2['StepY']*3/4)  * 1000 
    
    df2['t71'] = (df2['LUy']/1000 + df2['StepX']/2) * 1000 
    df2['t72'] = (-df2['LUx']/1000 + df2['StepY']/4) * 1000 
    
    df2['t81'] = (df2['LDy']/1000 + df2['StepX']/2)  * 1000 
    df2['t82'] = (-df2['LDx']/1000 + df2['StepY']/4)  * 1000 





    
    
    df2['d11'] = ((df2['RDy']/1000 + df2['StepX']/2) - df2['m11'])  * 1000 
    df2['d12'] = ((-df2['RDx']/1000 + df2['StepY']/4) - df2['m12'])  * 1000 
    
    df2['d21'] = ((df2['RUy']/1000 + df2['StepX']/2) - df2['m21'])  * 1000 
    df2['d22'] = ((-df2['RUx']/1000 + df2['StepY']/4) - df2['m22']) * 1000 
    
    df2['d31'] = ((df2['LUy']/1000 + df2['StepX']/2) - df2['m31'])  * 1000 
    df2['d32'] = ((-df2['LUx']/1000 + df2['StepY']*3/4) - df2['m32'])  * 1000 
    
    df2['d41'] = ((df2['LDy']/1000 + df2['StepX']/2) - df2['m41'])  * 1000 
    df2['d42'] = ((-df2['LDx']/1000 + df2['StepY']*3/4) - df2['m42'])  * 1000 
    
    df2['d51'] = ((df2['RDy']/1000 + df2['StepX']/2) - df2['m51'])  * 1000 
    df2['d52'] = ((-df2['RDx']/1000 + df2['StepY']*3/4) - df2['m52'])  * 1000 
    
    df2['d61'] = ((df2['RUy']/1000 + df2['StepX']/2) - df2['m61']) * 1000 
    df2['d62'] = ((-df2['RUx']/1000 + df2['StepY']*3/4) - df2['m62'])  * 1000 
    
    df2['d71'] = ((df2['LUy']/1000 + df2['StepX']/2) - df2['m71'])  * 1000 
    df2['d72'] = ((-df2['LUx']/1000 + df2['StepY']/4) - df2['m72'])  * 1000 
    
    df2['d81'] = ((df2['LDy']/1000 + df2['StepX']/2) - df2['m81'])  * 1000 
    df2['d82'] = ((-df2['LDx']/1000 + df2['StepY']/4) - df2['m82'])  * 1000 
    
    
    
    
    
    
    
    
    
    
    df2['c11'] = abs((df2['RDy']/1000 + df2['StepX']/2) - df2['m11']) <0.020
    df2['c12'] = abs((-df2['RDx']/1000 + df2['StepY']/4) - df2['m12']) <0.020
    
    df2['c21'] = abs((df2['RUy']/1000 + df2['StepX']/2) - df2['m21']) <0.020
    df2['c22'] = abs((-df2['RUx']/1000 + df2['StepY']/4) - df2['m22']) <0.020
    
    df2['c31'] = abs((df2['LUy']/1000 + df2['StepX']/2) - df2['m31']) <0.020
    df2['c32'] = abs((-df2['LUx']/1000 + df2['StepY']*3/4) - df2['m32']) <0.020
    
    df2['c41'] = abs((df2['LDy']/1000 + df2['StepX']/2) - df2['m41']) <0.020
    df2['c42'] = abs((-df2['LDx']/1000 + df2['StepY']*3/4) - df2['m42']) <0.020
    
    df2['c51'] = abs((df2['RDy']/1000 + df2['StepX']/2) - df2['m51']) <0.020
    df2['c52'] = abs((-df2['RDx']/1000 + df2['StepY']*3/4) - df2['m52']) <0.020
    
    df2['c61'] = abs((df2['RUy']/1000 + df2['StepX']/2) - df2['m61']) <0.020
    df2['c62'] = abs((-df2['RUx']/1000 + df2['StepY']*3/4) - df2['m62']) <0.020
    
    df2['c71'] = abs((df2['LUy']/1000 + df2['StepX']/2) - df2['m71']) <0.020
    df2['c72'] = abs((-df2['LUx']/1000 + df2['StepY']/4) - df2['m72']) <0.020
    
    df2['c81'] = abs((df2['LDy']/1000 + df2['StepX']/2) - df2['m81']) <0.020
    df2['c82'] = abs((-df2['LDx']/1000 + df2['StepY']/4) - df2['m82']) <0.020 
    
    df2['check'] = [ df2['c11'][i] and df2['c12'][i] and df2['c21'][i] and df2['c22'][i] and 
                     df2['c31'][i] and df2['c32'][i] and df2['c41'][i] and df2['c42'][i] and
                     df2['c51'][i] and df2['c52'][i] and df2['c61'][i] and df2['c62'][i] and 
                     df2['c71'][i] and df2['c72'][i] and df2['c81'][i] and df2['c82'][i] 
                    for i in df2.index]
    
    
    
    
    
    

    #standard field
    df3 = df[df['Part'].str[-2:] != '-L']
    
    df3['t11'] = (df3['LDx']/1000 + df3['StepX']/2) * 1000
    df3['t12'] = (df3['LDy']/1000 + df3['StepY']/2) * 1000 
    
    df3['t21'] = (df3['RDx']/1000 + df3['StepX']/2) * 1000  
    df3['t22'] = (df3['RDy']/1000 + df3['StepY']/2) * 1000   
    
    df3['t31'] = (df3['RUx']/1000 + df3['StepX']/2) * 1000  
    df3['t32'] = (df3['RUy']/1000 + df3['StepY']/2) * 1000   
    
    df3['t41'] = (df3['LUx']/1000 + df3['StepX']/2) * 1000  
    df3['t42'] = (df3['LUy']/1000 + df3['StepY']/2) * 1000   


    
    df3['d11'] = ((df3['LDx']/1000 + df3['StepX']/2) - df3['m11']) * 1000 
    df3['d12'] = ((df3['LDy']/1000 + df3['StepY']/2) - df3['m12']) * 1000 
    
    df3['d21'] = ((df3['RDx']/1000 + df3['StepX']/2) - df3['m21'])  * 1000 
    df3['d22'] = ((df3['RDy']/1000 + df3['StepY']/2) - df3['m22'])  * 1000 
    
    df3['d31'] = ((df3['RUx']/1000 + df3['StepX']/2) - df3['m31'])  * 1000 
    df3['d32'] = ((df3['RUy']/1000 + df3['StepY']/2) - df3['m32']) * 1000  
    
    df3['d41'] = ((df3['LUx']/1000 + df3['StepX']/2) - df3['m41'])  * 1000 
    df3['d42'] = ((df3['LUy']/1000 + df3['StepY']/2) - df3['m42'])  * 1000 
    
    
    
    
    df3['c11'] = abs((df3['LDx']/1000 + df3['StepX']/2) - df3['m11']) <0.020
    df3['c12'] = abs((df3['LDy']/1000 + df3['StepY']/2) - df3['m12']) <0.020
    
    df3['c21'] = abs((df3['RDx']/1000 + df3['StepX']/2) - df3['m21']) <0.020
    df3['c22'] = abs((df3['RDy']/1000 + df3['StepY']/2) - df3['m22']) <0.020
    
    df3['c31'] = abs((df3['RUx']/1000 + df3['StepX']/2) - df3['m31']) <0.020
    df3['c32'] = abs((df3['RUy']/1000 + df3['StepY']/2) - df3['m32']) <0.020
    
    df3['c41'] = abs((df3['LUx']/1000 + df3['StepX']/2) - df3['m41']) <0.020
    df3['c42'] = abs((df3['LUy']/1000 + df3['StepY']/2) - df3['m42']) <0.020
    
    df3['check']  = [ df3['c11'][i] and df3['c12'][i] and df3['c21'][i] and df3['c22'][i] and 
                     df3['c31'][i] and df3['c32'][i] and df3['c41'][i] and df3['c42'][i]     
                    for i in df3.index]
    
    
    df = pd.concat([df1,df2,df3])[[
            't11', 't12', 't21', 't22', 't31', 't32', 't41', 't42', 
            't51', 't52', 't61', 't62', 't71', 't72', 't81', 't82',
            'd11', 'd12', 'd21', 'd22', 'd31', 'd32', 'd41', 'd42', 
            'd51', 'd52', 'd61', 'd62', 'd71', 'd72', 'd81', 'd82',
            'c11', 'c12', 'c21', 'c22', 'c31', 'c32', 'c41', 'c42', 
            'c51', 'c52', 'c61', 'c62', 'c71', 'c72', 'c81', 'c82', 
            'check']].fillna('')
    
    
    df = pd.concat([bak,df],axis=1).fillna('')
    df['No'] = df['Part'].str[2:6]
    df=df.sort_values(by='No')
    df = df[df['No'].str.isdigit()==True]
    
    
    df.to_csv('Y:/overlay/check.csv')
    
    log = open('y:/overlay/log.txt','a')
    log.write("\n\n" + str(datetime.datetime.now())[0:19] +'_  '+ str(df.shape[0]) +'  _Total Recipes Actually')
    log.write("\n" + str(datetime.datetime.now())[0:19] +'_  '+ str(df[df['check']!=''].shape[0]) +'  _OVL Recipes Are Checked')
    log.write("\n" + str(datetime.datetime.now())[0:19] +'_  '+ str(df[df['check'] ==True].shape[0]) +'  _OVL Recipes Are Correct')
    log.write("\n" + str(datetime.datetime.now())[0:19] +'_  '+ str(df[df['check'] == False].shape[0]) +'  _OVL Recipes Are Wrong')
    log.close()
    
    return df
    
    
    
    
    



    
    




def list_measurement_files_to_be_download(df):

    #df =  pd.read_csv('y:/overlay/check.csv',header=0,usecols=['Part','Stage','OVL-PPID','LUy','No','check'])
    #df = df[df['LUy']==df['LUy']]
    #df=df.fillna('')
    #df['No']=df['No'].astype('str')
    #df = df[['Part', 'Stage', 'OVL-PPID',  'check', 'No']]
    
    df = df[df['LUy'] != '']
    
    
    
    tmp = pd.read_excel(r'D:\HuangWeiScript\PyTaskCode\R2R_New_Part.xlsm',sheet_name = 'PartLayer',header = 0)[['PartVer','Stage','Flag1','MaskNo']].dropna()
    
    tmp['PartVer'] = tmp['PartVer'].str[0:-3]
    tmp['Flag1'] = tmp['Flag1'].astype('bool')
    tmp.columns= ['Part', 'Stage', 'Flag1', 'No']
    
    
    df = pd.merge(df,tmp,on= ['Part','Stage','No'],how='left')
    #df['PendingDownload']=df['check'].astype('bool')
    
    PendingDownload=[]
    x1= list (df['check'])
    x2= list(df['Flag1'])
    for i in range(df.shape[0]):
        try:
            if len(x1[i])<2 and x2[i] == True:
                PendingDownload.append(True)
            else:
                PendingDownload.append('')
        except:
            PendingDownload.append('')
    df['PendingDownload']=PendingDownload
    





















    
    
    
    #df.columns = ['Part', 'Stage', 'OVL-PPID', 'Flag', 'No','Flag1', 'PendingDownload']
    #df = df[['No','Part', 'Stage', 'OVL-PPID', 'Flag', 'Flag1', 'PendingDownload']]
    df = df.sort_values(by='No') 
    
    
    #tmp = pd.read_csv('Y:/overlay/reference.csv',usecols=['Path','PPID'])
    #tmp['Path'] = [i.split('\\')[3].split('.')[0] for i in list(tmp['Path']) ]
    #tmp['Part'] = tmp['Path']
    
    #tmp = pd.merge(,df,on=['Part'],how='left')
    
    
    
    df.to_csv('y:/overlay/Result.csv',index=False)   
    log = open('y:/overlay/log.txt','a')
    log.write("\n" + str(datetime.datetime.now())[0:19] +'_  '+ str(df[df['PendingDownload']==True].shape[0]) +'  _recipes to be downloaded for check\n')
    log.close()
    
    
   
    
    
    
    
    
    
    
    
def read_Q200_recipes():
    FileDir = 'Z:\\_DailyCheck\\Q200_LD\\'
    filenamelist=[]
    for root, dirs, files in os.walk(FileDir, False):  #root:所有目录名-->字符串 #dirs: root下的子目录名-->列表 #files：root下的文件名-->列表 # name.endswith(ext)-->文件名筛选 
        for names in files:
            if names[-2:] == 'ld':
                filenamelist.append( root  + '\\' + names) 
    filenamelist.sort(reverse = False)
    
    
    old = pd.read_csv('y:/overlay/q200.csv',header=0,usecols=['Path'])
    
    filenamelist = set(filenamelist)-set(old['Path'])
    
    
    Q200=[]
    for file in filenamelist:
        print(file)
        data = []
        try:
            f = [i.strip('\n') for i in open(file).readlines()]
            for n,tmp in enumerate(f):
                if tmp == '\t\t\tlocations=4,':
                    data.append(file.split('\\')[5][:-3])
                    data.extend(  [eval(f[n+2][10:].split(',')[0]), eval(f[n+2][10:].split(',')[1][0:-1])] )
                    data.extend(  [eval(f[n+4][10:].split(',')[0]), eval(f[n+4][10:].split(',')[1][0:-1])] )
                    data.extend(  [eval(f[n+6][10:].split(',')[0]), eval(f[n+6][10:].split(',')[1][0:-1])] )
                    data.extend(  [eval(f[n+8][10:].split(',')[0]), eval(f[n+8][10:].split(',')[1][0:-1])] )
                    data.append(file)
            if len(data)  == 10:
                Q200.append(data)
        except:
            pass
    if len(Q200)>0:
        Q200 = pd.DataFrame(Q200)
        Q200.columns=['PPID', 'm11', 'm12', 'm21', 'm22', 'm31', 'm32', 'm41', 'm42', 'Path']
        
    
        Q200.to_csv('y:/overlay/Q200.csv',mode='a',index = None,header=None)
        
        log = open('y:/overlay/log.txt','a')
        log.write("\n" + str(datetime.datetime.now())[0:19] +'_  '+ str(Q200.shape[0]) +'  _rows Q200 Data Added')
        log.close()    
        
    
    
    
    
    
    
    
    
    


if __name__ == "__main__":
    # get coordinate in recipe

    
    read_Q200_recipes()
    read_raw_data()         

    
    #get standard coordinates in tooling form
    read_standard_coordinate()
    
    #step size in asml file
    read_asml_step_size()
    
    #bias table 
    read_bias_table()
    

    #DREAMS flow data
    flow =  partname_to_be_checked(referencepath='Y:/overlay/reference.csv')
 
    #read data and compare
    df = compare(flow)
    
    flow = None
    
    list_measurement_files_to_be_download(df)
    
    

    




    
#    log = open('y:/overlay/log.txt','a')
#    log.write("\n" + str(datetime.datetime.now())[0:19] +'_  '+ str(flow.shape[0]) +'  _are standard PPID qty')
#    log.close()
    
    
    
    
    
    


#        ['Part', 'Stage', 'OVL-PPID', 'Tech', 'ToolType', 'PPID', 'LDx', 'LDy',
#       'LUx', 'LUy', 'RDx', 'RDy', 'RUx', 'RUy', 'Path']

#       ['Part', 'Stage', 'OVL-PPID', 'Tech', 'ToolType', 'PPID', 'LDx', 'LDy',
#       'LUx', 'LUy', 'RDx', 'RDy', 'RUx', 'RUy', 'Path', 'StepX', 'StepY']

#       ['Part_x', 'Stage', 'OVL-PPID', 'Tech', 'ToolType', 'PPID', 'LDx', 'LDy',
#       'LUx', 'LUy', 'RDx', 'RDy', 'RUx', 'RUy', 'Path_x', 'StepX', 'StepY',
#       'RiQi', 'Part_y', 'Max_x', 'Max-y', 'Path_y', 'Count', '6', '7', '8',
#       '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20',
#       '21', 'part'],


    #df = df [['Part_x', 'Stage', 'OVL-PPID', 'Tech', 'ToolType', 'PPID', 'LDx', 'LDy','RDx', 'RDy','RUx', 'RUy',
    #   'LUx', 'LUy',  'Path_x', 'StepX', 'StepY', 'RiQi', 'Part_y', 'Max_x', 'Max-y', 'Path_y', 'Count', '6', '7', '8',
    #   '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20','21', 'part']] 









'''
word = client.Dispatch('Word.Application')
for file in filelist:
    doc =  word.Documents.Open(file)

    #doc.SaveAs('C:/temp/0000.html',8)
    #doc.SaveAs('y:/overlay/coordinateTxt/' + file.split('\\')[3].split('.')[0][2:6] + '.txt' ,7)
    doc.SaveAs('y:/overlay/coordinateTxt/' + file.split('\\')[3].split('.')[0] + '.txt' ,5)
    doc.Close()
word.Quit()
'''



'''
    
    #==============================================================================
    #partlist: ovl coordinate available from file saved by LiYan, extracted and saved in reference.csv
  
    # Flag1==True, coordinate data available
    tmp = pd.DataFrame(partlist)   
    tmp.columns=['Part'] 
    tmp['Flag']=True    
    flow = pd.merge(flow,tmp,on=['Part'],how = 'left').fillna(False)    

    
    flow.to_csv('y:/overlay/StandardFlow.csv',index=False)  ##all part,ppid -->referesh move,ovl
    
    
    
    
    flow = pd.merge(flow,tmp1,on=['Part','OVL-PPID'],how = 'left').fillna('')

    #================================================
    #read coordinate data

    table = pd.merge(flow,coordinate,on=['Part','PPID'],how = 'left').fillna('') 
    table.to_csv('y:/overlay/StandardFlow.csv',index = False)

    return table


'''












#    INPUT_DIR = r'C:\Users\pi\Desktop\New folder'
#    OUTPUT_DIR = r'C:\Users\pi\Desktop\txts'
#    word = client.Dispatch('Word.Application')
#    for doc_name in listdir(INPUT_DIR):
#        print(doc_name)
#        doc_full_name = path.join(INPUT_DIR, doc_name)
#        doc = word.Documents.Open(doc_full_name)
#        doc.SaveAs(path.join(OUTPUT_DIR, doc_name.split('.')[0]), 4)
#        doc.Close()
#    word.Quit()
    
    
#    wdFormatDocument                    =  0
#wdFormatDocument97                  =  0
#wdFormatDocumentDefault             = 16
#wdFormatDOSText                     =  4
#wdFormatDOSTextLineBreaks           =  5
#wdFormatEncodedText                 =  7
#wdFormatFilteredHTML                = 10
#wdFormatFlatXML                     = 19
#wdFormatFlatXMLMacroEnabled         = 20
#wdFormatFlatXMLTemplate             = 21
#wdFormatFlatXMLTemplateMacroEnabled = 22
#wdFormatHTML                        =  8
#wdFormatPDF                         = 17
#wdFormatRTF                         =  6
#wdFormatTemplate                    =  1
#wdFormatTemplate97                  =  1
#wdFormatText                        =  2
#wdFormatTextLineBreaks              =  3
#wdFormatUnicodeText                 =  7
#wdFormatWebArchive                  =  9
#wdFormatXML                         = 11
#wdFormatXMLDocument                 = 12
#wdFormatXMLDocumentMacroEnabled     = 13
#wdFormatXMLTemplate                 = 14
#wdFormatXMLTemplateMacroEnabled     = 15
#wdFormatXPS                         = 18




#from docx import Document #导入库
#import os

#filelist = []
#path = r'P:\Recipe\Coordinate'
#for file  in os.listdir(path):
#    if file[-3:]=='doc' or file[-4:]=='docx':
#        filelist.append(os.path.join(path, file))
        
#for file in filelist:
#    document = Document(file) #读入文件
#    tables = document.tables #获取文件中的表格集
#    if len(tables)>0:
#        table = tables[0  ]#获取文件中的第一个表格#

#        for i in range(1,len(table.rows)):#从表格第二行开始循环读取表格数据
#            tmp=[]
#            for j in range(1,len(table.columns)):
#                tmp.append(table.cell(i-1,j-1).text)
#            print(tmp)