# -*- coding: utf-8 -*-




#import os.path
import win32com.client
import pandas as pd
import datetime
import time
import os
from math import isnan
import matplotlib.pyplot as plt
import gc
import shutil
#from matplotlib.gridspec import GridSpec


def Excel_Macro():
    # Run Excel Macro
    xlApp = win32com.client.DispatchEx('Excel.Application')
    xlsPath = os.path.expanduser('P:\\TEMP\\NikonShot\\transfer\\move.xls')
    wb = xlApp.Workbooks.Open(Filename=xlsPath)
    xlApp.Run('TotalMove')
    wb.Save()
    xlApp.Quit()

def get_imagename():
    foldername =  r'p:\TEMP\NikonShot\transfer'
    #foldername = r'Z:\0_CDU_QC_TopDownImages'
    filename = []
    for root,dirs,files in os.walk(foldername,False):      
        for file in files:
            if ('jpg' in file or 'png' in file) and (not 'Done' in file) and len(file) > 50 :  #部分文件名不规范，无lotid等，用>50剔除部分，后续重命名，用try/except
                filename.append(file)
    return filename



def rename_imgname():

    
    #待确认作业设备的图片文件
    filename = get_imagename()
    
    #数据按TRACKOUTTIME降序排
    #Read Data from Excel
    move = pd.read_excel('P:\\TEMP\\NikonShot\\transfer\\move.xls',sheetname=0)[['LOTID','EQPID','TRACKOUTTIME']].sort_values(by = ['TRACKOUTTIME'],ascending=False)
    
    
    
    
    
    for name in filename:
        tmp = name.split('_')
        lotid = tmp[4] + '.1'
        date =  tmp[1] + ' ' + tmp[2]                                    #时间以字符串表示，格式YYYYMMDD HHMMSS，与move中格式不同，需转两次
        date = time.strptime(date, "%Y%m%d %H%M%S")                      #字符串转时间   YYMMDD HHMMSS
        date = time.strftime("%Y-%m-%d %H:%M:%S",date)                   #时间转字符串   YYYY-MM-DD HH：MM：SS
        date =datetime.datetime.strptime(date, "%Y-%m-%d %H:%M:%S")      #字符串转时间   YYYY-MM-DD HH:MM:SS    
        tmp =  move[ move['LOTID'].str.contains(lotid) ]                 #列出包含特定LotID的数据
       
        try: #部分文件名不规范，无lotid
            tmp = tmp [tmp['TRACKOUTTIME']<date ]                             #小于date，CD SEM测试时间的第一笔stepper作业时间                                          
            toolname = list(tmp.iloc[0])[1]                                   #曝光设备名
            
            oldfilename =   'p:\\TEMP\\NikonShot\\transfer\\' + name 
            newfilename =   'p:\\TEMP\\NikonShot\\transfer\\' + toolname + '_' + 'Done_' + name 
            
            #oldfilename = 'Z:\\0_CDU_QC_TopDownImages\\' + name            
            #newfilename = 'Z:\\0_CDU_QC_TopDownImages\\' + toolname + '_' + 'Done_' + name 
            
            os.rename (oldfilename,newfilename )
        except:
            pass




def cd():
    df = pd.read_csv('P:\\temp\\nikonshot\\cd.csv')
    move = pd.read_excel('P:\\TEMP\\NikonShot\\transfer\\move.xls',sheet_name=0)[['LOTID','EQPID','TRACKOUTTIME']].sort_values(by = ['TRACKOUTTIME'],ascending=False)
    
    l_toolid = list (df ['ToolID'])
    l_lotid = list (df['LotID'])
    l_riqi = list(df ['RiQi'])
    tool = []
        
    for i in range( df.shape[0]):


        try:
            isnan(l_toolid[i]) == True #未标注toolid
            date = l_riqi[i]
            date = time.strptime(date, "%Y%m%d %H%M%S")                      #字符串转时间   YYMMDD HHMMSS
            date = time.strftime("%Y-%m-%d %H:%M:%S",date)                   #时间转字符串   YYYY-MM-DD HH：MM：SS
            date =datetime.datetime.strptime(date, "%Y-%m-%d %H:%M:%S")      #字符串转时间   YYYY-MM-DD HH:MM:SS  
     
            tmp =  move[ move['LOTID'].str.contains(l_lotid[i]) ]                 #列出包含特定LotID的数据 
            tmp = tmp [tmp['TRACKOUTTIME']<date ]                             #小于date，CD SEM测试时间的第一笔stepper作业时间    
            toolname = list(tmp.iloc[0])[1]                                   #曝光设备名
            tool.append(toolname)
            
        except:
            tool.append ( l_toolid[i] )
        
        
    df['ToolID']=tool
    df.to_csv('P:\\temp\\nikonshot\\cd.csv',index = False, header=True)
    df.to_csv('P:\\temp\\nikonshot\\cd_bak.csv',index = False, header=True)
        
        
                 



def nikon(toollist,df,days):
    #days = 100
    toollist = [ i for i in toollist if 'D' not in i]
    for tool in toollist:
    
        tmp = df[ df['ToolID'].str.contains( tool ) ][[ 'RiQi','R2','R3','R4','Direction']]
        #split data by 'RiQi' for boxplot
        l1 = tmp['RiQi'].unique()        
        data_v1=[]   #reserve for slope R3
        data_h1=[]
        data_v = []  # reserve for top/bottome R2
        data_h = []
        
        for i in l1:            
            v=[]
            h=[]
            v1=[]
            h1=[]
            
            v.append(i)
            h.append(i)
            v1.append(i)
            h1.append(i)
                        
            tmp1 = tmp[ tmp['RiQi'] == i]
            
            tmp_v = tmp1[ tmp1['Direction'].str.contains('Vertical') ]    ['R2']
            tmp_h = tmp1[ tmp1['Direction'].str.contains('Horizontal') ]  ['R2']
            
            v.extend ( tmp_v )
            h.extend ( tmp_h )
            data_v.append(v)
            data_h.append(h)
            
            
          
            tmp_v1 = tmp1[ tmp1['Direction'].str.contains('Vertical') ]    ['R4']
            tmp_h1 = tmp1[ tmp1['Direction'].str.contains('Horizontal') ]  ['R4']
            
            v1.extend ( tmp_v1 )
            h1.extend ( tmp_h1 )
            data_v1.append(v1)
            data_h1.append(h1)            
            
            
        # convert data to DataFrame format, index by RiQi    
        data_v = pd.DataFrame(data_v).tail(days)
        data_v = data_v.set_index([0])
        
        data_h = pd.DataFrame(data_h).tail(days)
        data_h = data_h.set_index([0])
                
        data_v1 = pd.DataFrame(data_v1).tail(days)
        data_v1 = data_v1.set_index([0])
        
        data_h1 = pd.DataFrame(data_h1).tail(days)
        data_h1 = data_h1.set_index([0])        
        
     
        # plot image
        fig = plt.figure(figsize =(24,16)) 

        ax1 = fig.add_subplot(2,2,1)
        data_v.T.boxplot(showmeans=True,patch_artist=True)        
        ax1.set_xticklabels(data_v.index,rotation=90)
        ax1.set_title(tool + ' Vertical L-Bar Within Shot:Top CD/Bottom CD  100% Threshold Linear 1_4_1')
        plt.ylim(0.4,0.9)
        #plt.show
        
        ax2 = fig.add_subplot(2,2,2)
        data_h.T.boxplot(showmeans=True,patch_artist=True)
        ax2.set_xticklabels(data_h.index,rotation=90)
        ax2.set_title(tool + ' Horizontal L-Bar Within Shot:Top CD/Bottom CD  100% Threshold Linear 1_4_1')
        plt.ylim(0.4,0.9)
        #plt.show
        
        ax3 = fig.add_subplot(2,2,3)
        data_v1.T.boxplot(showmeans=True,patch_artist=True)
        ax3.set_xticklabels(data_v1.index,rotation=90)
        ax3.set_title(tool + ' Vertical L-Bar Within Shot Slope: (Right-Left)/(Right+Left)')
        plt.ylim(-0.5,0.5)
        #plt.show  
        
        
        ax4 = fig.add_subplot(2,2,4)
        data_h1.T.boxplot(showmeans=True,patch_artist=True)
        ax4.set_xticklabels(data_h1.index,rotation=90)
        ax4.set_title(tool + ' Horizontal L-Bar Within Shot Slope: (Upper - Lower)/(Upper + Lower)')
        plt.ylim(-0.5,0.5)
        #plt.show  
        
        fig.subplots_adjust(hspace=0.4)
        plt.savefig('P:\\TEMP\\Nikonshot\\' + tool + '.jpg',dpi=200, bbox_inches='tight')
        print('P:\\TEMP\\Nikonshot\\' + tool + '.jpg saved' )
        
        plt.clf() # 清图。
        plt.cla() # 清坐标轴。
        plt.close() # 关窗口
        gc.collect()
        


def asml(toollist,df,days):
    #days = 100
    toollist = [ i for i in toollist if 'D'  in i]
    #toollist = ['ALDI05']
    for tool in toollist:
    
        tmp = df[ df['ToolID'].str.contains( tool ) ][[ 'RiQi','R2','R3','R4','CD1_50','CD2_50','CD3_50','CD4_50']]
        #split data by 'RiQi' for boxplot
        l1 = tmp['RiQi'].unique()        
        data1=[]   #reserve   R2
        data2=[]   #reserve   bottom CD
        data3=[]   #reserve   R4
        data4=[]
        data5=[]
 

       
        for i in l1:            
            d1=[]            
            d1.append(i)                        
            tmp1 = tmp[ tmp['RiQi'] == i]['R2']            
            d1.extend ( tmp1 )           
            data1.append(d1)
            
            d2=[]            
            d2.append(i)
            
            if tool in ['ALDI02','ALDI03','ALDI06','ALDI07','ALDI09','ALDI10']:                                        
                tmp1 = tmp[ tmp['RiQi'] == i]['CD2_50']            
                d2.extend ( tmp1 )           
                data2.append(d2)
            else:                                  
                tmp1 = tmp[ tmp['RiQi'] == i]['CD1_50']            
                d2.extend ( tmp1 )           
                data2.append(d2)                
                
            
            d3=[]            
            d3.append(i)                        
            tmp1 = tmp[ tmp['RiQi'] == i]['R4']            
            d3.extend ( tmp1 )           
            data3.append(d3)            
            
   
            d4=[]            
            d4.append(i)                        
            tmp1 = tmp[ tmp['RiQi'] == i]['CD3_50']            
            d4.extend ( tmp1 )           
            data4.append(d4)

            d5=[]            
            d5.append(i)                        
            tmp1 = tmp[ tmp['RiQi'] == i]['CD4_50']            
            d5.extend ( tmp1 )           
            data5.append(d5)            
                     
            
            
        # convert data to DataFrame format, index by RiQi    
        data1 = pd.DataFrame(data1).tail(days)
        data1 = data1.set_index([0])
        
        data2 = pd.DataFrame(data2).tail(days)
        data2 = data2.set_index([0])

        data3 = pd.DataFrame(data3).tail(days)
        data3 = data3.set_index([0])                

        data4 = pd.DataFrame(data4).tail(days)
        data4 = data4.set_index([0])

        data5 = pd.DataFrame(data5).tail(days)
        data5 = data5.set_index([0])

        
     
        # plot image
        fig = plt.figure(figsize =(24,16)) 

        ax1 = fig.add_subplot(2,2,1)
        data1.T.boxplot(showmeans=True,patch_artist=True)        
        ax1.set_xticklabels(data1.index,rotation=90)
        ax1.set_title(tool + ' Vertical L-Bar Within Shot:Top CD/Bottom CD  100% Threshold Linear 1_4_1')
        plt.ylim(0.35,0.75)
        #plt.show
        
        ax2 = fig.add_subplot(2,2,2)
        data2.T.boxplot(showmeans=True,patch_artist=True)
        ax2.set_xticklabels(data2.index,rotation=90)
        ax2.set_title(tool + ' Vertical L-Bar Within Shot CDU_Bottom CD (unit:pixel)')
        if tool in ['ALDI02','ALDI03','ALDI06','ALDI07','ALDI09','ALDI10']: 
            plt.ylim(80,140)
        else:
            plt.ylim(100,170)

        #plt.show
        
        ax3 = fig.add_subplot(2,2,3)
        data3.T.boxplot(showmeans=True,patch_artist=True)
        ax3.set_xticklabels(data3.index,rotation=90)
        ax3.set_title(tool + ' Vertical L-Bar Within Shot Slope: (Right-Left)/(Right+Left)')
        plt.ylim(-0.4,0.4)
        #plt.show  
        
        
        ax4 = fig.add_subplot(2,2,4)
      
        f=data4.T.boxplot(patch_artist=True)      
        data5.T.boxplot()#notch = True)
        ax4.set_xticklabels(data4.index,rotation=90)
        ax4.set_title(tool + ' Vertical L-Bar Within Shot Slope: Green_Left Slope     Blue_Right Slope ')
        plt.ylim(20,60)
        #plt.show  
        
        fig.subplots_adjust(hspace=0.4)
        plt.savefig('P:\\TEMP\\Nikonshot\\' + tool + '.jpg',dpi=200, bbox_inches='tight')
        print('P:\\TEMP\\Nikonshot\\' + tool + '.jpg saved' )
        
        plt.clf() # 清图。
        plt.cla() # 清坐标轴。
        plt.close() # 关窗口
        gc.collect()
        
        #df.boxplot(sym='r*',vert=False,patch_artist=True,meanline=False,showmeans=True)
        #for box in f['boxes']:
            # 箱体边框颜色
        #    box.set( color='#7570b3', linewidth=2)
            # 箱体内部填充颜色
        #    box.set( facecolor = '#1b9e77' )
        #for whisker in f['whiskers']:
        #    whisker.set(color='r', linewidth=2)
        #for cap in f['caps']:
        #    cap.set(color='g', linewidth=3)
        #for median in f['medians']:
        #    median.set(color='DarkBlue', linewidth=3)
        #for flier in f['fliers']:
        #    flier.set(marker='o', color='y', alpha=0.5)


        
'''        
        for box in f['boxes']:
            # 箱体边框颜色
            box.set( color='green', linewidth=2,alpha=0.5)
            # 箱体内部填充颜色
            box.set( facecolor = 'green' )
        for whisker in f['whiskers']:
            whisker.set(color='green', linewidth=2,alpha=0.5)
        for cap in f['caps']:
            cap.set(color='green', linewidth=2,alpha=0.5)
        for median in f['medians']:
            median.set(color='purple', linewidth=2)
        for flier in f['fliers']:
            flier.set(color='green', alpha=0.5)

'''

       

        



def plot_cd_image(days):

    toollist = ['ALII01','ALII02','ALII03','ALII04','ALII05','ALII10','ALII11',
                'ALII12','ALII13','ALII14','ALII15','ALII16','ALII17','ALII18',
                'ALSIB6','ALSIB7','ALSIB8','ALSIB9','ALSIBJ','BLSIBK','BLSIBL',
                'BLSIE1','ALDI02','ALDI03','ALDI05','ALDI06','ALDI07','ALDI09','ALDI10','ALDI11','ALDI12','BLDI08','BLDI13']
    
                           
    df = pd.read_csv('P:\\temp\\nikonshot\\cd.csv')
    df['R1'] = df['CD2'] /df['CD1']                                  # 100% threshold top/bottom
    df['R2'] = df['CD2_50'] /df['CD1_50']                            # 50% threshold top/bottom
    df['R3'] =( df['CD4_50'] + df['CD3_50'] ) /df['CD1_50']          # 50% threshold slope/bottom
    df['R4'] = ( df['CD4_50'] - df['CD3_50'] )/( df['CD4_50'] + df['CD3_50'] )

    
    df['RiQi'] = pd.to_datetime(df['RiQi'])                          # convert string to datatime format -->not necessary
    df = pd.DataFrame(df).sort_values(by = ['RiQi'],ascending = True)   
    df =df [df['ToolID'] == df['ToolID'] ] # remove NaN              # error triggered if not done 

                

    
    nikon(toollist,df,days)
    asml(toollist,df,days)








def move_file_to_Z_drive():
    
    toollist = ['ALII01','ALII02','ALII03','ALII04','ALII05','ALII10','ALII11',
                'ALII12','ALII13','ALII14','ALII15','ALII16','ALII17','ALII18',
                'ALSIB6','ALSIB7','ALSIB8','ALSIB9','ALSIBJ','BLSIBK','BLSIBL',
                'BLSIE1','ALDI02','ALDI03','ALDI05','ALDI06','ALDI07','ALDI09','ALDI10','ALDI11','ALDI12','BLDI08','BLDI13']
                
    filefolder =  'p:\\TEMP\\NikonShot\\transfer\\'
    newfolder = 'Z:\\0_CDU_QC_TopDownImages\\'
    newfolder = 'Y:\\QC_CDU_IMAGES\\'

    for root,dirs,files in os.walk(filefolder,False):      
        for file in files:

            if ('jpg' in file or 'png' in file ) and ( 'Done' in file) and (file[0:6] in toollist) and (len(file) > 50):  #部分文件名不规范，无lotid等，用>50剔除部分，后续重命名，用try/except
                old = filefolder + file
                new =  newfolder  + file[0:6] + '\\' + file
                shutil.move(old,new)
                print(old + '  has been moved to Z drive')















if __name__ == '__main__':
    
    Excel_Macro() #读入  天move数据
    rename_imgname()
    cd()
    plot_cd_image(days=30)

    move_file_to_Z_drive()
    
    tmp = open(r'C:\anaconda3\log.txt','a')
    tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___003-CDU_IMAGE_Plot Done\n")
    tmp.close()
   
'''    
[python] view plain copy
# 导入第三方模块  
import pandas as pd  
import matplotlib.pyplot as plt  
  
# 读取Titanic数据集  
titanic = pd.read_csv('titanic_train.csv')  
# 检查年龄是否有缺失  
any(titanic.Age.isnull())  
# 不妨删除含有缺失年龄的观察  
titanic.dropna(subset=['Age'], inplace=True)  
  
# 设置图形的显示风格  
plt.style.use('ggplot')  
  
# 设置中文和负号正常显示  
plt.rcParams['font.sans-serif'] = 'Microsoft YaHei'  
plt.rcParams['axes.unicode_minus'] = False  
  
# 绘图：整体乘客的年龄箱线图  
plt.boxplot(x = titanic.Age, # 指定绘图数据  
            patch_artist=True, # 要求用自定义颜色填充盒形图，默认白色填充  
            showmeans=True, # 以点的形式显示均值  
            boxprops = {'color':'black','facecolor':'#9999ff'}, # 设置箱体属性，填充色和边框色  
            flierprops = {'marker':'o','markerfacecolor':'red','color':'black'}, # 设置异常值属性，点的形状、填充色和边框色  
            meanprops = {'marker':'D','markerfacecolor':'indianred'}, # 设置均值点的属性，点的形状、填充色  
            medianprops = {'linestyle':'--','color':'orange'}) # 设置中位数线的属性，线的类型和颜色  
# 设置y轴的范围  
plt.ylim(0,85)  
  
# 去除箱线图的上边框与右边框的刻度标签  
plt.tick_params(top='off', right='off')  
# 显示图形  
plt.show()  
    
'''   



















