# -*- coding: utf-8 -*-
"""
Created on Wed Nov 28 07:04:46 2018

@author: HUANGWEI45
"""




from matplotlib.patches import  Circle,Rectangle
import matplotlib.pyplot as plt
from  math import sqrt as sqrt

tmpcount = 0
stepX = eval( input(" Please Input Step X (mm): "))
stepY = eval( input(" Please Input Step Y (mm): "))
dieX = eval( input(" Please Input Die X (mm): "))
dieY = eval( input(" Please Input Die Y (mm): "))
offX = eval( input(" Please Input Map Offset X (mm): "))
offY = eval( input(" Please Input Map Offset Y (mm): "))
wee = 100 - eval( input(" Please Input Edge Exclusion (mm): "))
part = input('Please Input Part Name: ')
gdw = eval(input('Please Inpout GDW: '))





def gating(shotDie,gdw,dieX,dieY,col2,row2,llx,lly,stepX,stepY):
    tmpcount = 0
    tmpcount1 = 0

    for k in range(0,col2):
        for l in range(0,row2):
            sx = llx + k * dieX
            sy = lly + l * dieY
                       
                       
                       
            f1 = ( pow(sx,2) + pow(sy,2) ) < pow(wee,2)
            f2 = ( pow(sx + dieX,2) + pow(sy,2) )< pow(wee,2) 
            f3 = ( pow(sx + dieX,2) + pow(sy + dieY,2) )< pow(wee,2) 
            f4 = ( pow(sx ,2) + pow(sy + dieY,2) )< pow(wee,2)
            f5 =  ((sy + dieY) > 92) and ((sx+dieX < 13 and  sx+dieX>-13) or (sx < 13 and  sx>-13))
            f5 = not f5
                       
            f6 =  (sy < -94) and ((sx+dieX < 14 and  sx+dieX>-14) or (sx < 14 and  sx>-14))
            f6 = not  f6                        
                        
                        
            if (f1 and f2 and f3 and f4 and f5 and f6): 
                tmpcount += 1
                
            tmpcount1 = tmpcount1 + len([ i for i in [f1,f2,f3,f4] if i == True])/4


 
    return  (tmpcount1/shotDie<0.15) and  (tmpcount /gdw < 0.005)
        
  

























col1 = int( wee  // stepX )
row1 = int ( wee // stepY )

col2 = int( stepX / dieX)
row2 = int( stepY / dieY)


shotDie = stepX/dieX * stepY/dieY

totalDie = 0


fig = plt.figure(figsize=(10,10))
ax = fig.add_subplot(111)

#ell1 = Ellipse(xy = (0.0, 0.0), width = 4, height = 8, angle = 30.0, facecolor= 'yellow', alpha=0.3)
#ax.add_patch(ell1)

cir1 = Circle(xy = (0, 0), radius=100, alpha=1,fill=False, edgecolor='black', linewidth=0.3)
ax.add_patch(cir1)
cir1 = Circle(xy = (0, 0), radius = wee, alpha=1,fill=False, edgecolor='red', linewidth=0.3)
ax.add_patch(cir1)



for i in range (-col1-1,col1+2):
#for i in range(-100,100):
    for j in range(-row1-1,row1+2):
        
        llx = i*stepX-stepX/2 + offX
        lly = j*stepY-stepY/2 + offY
        
        f1 = ( pow(llx,2) + pow(lly,2) ) < pow(wee,2) 
        f2 = ( pow(llx + stepX,2) + pow(lly,2) )< pow(wee,2) 
        f3 = ( pow(llx + stepX,2) + pow(lly + stepY,2) )< pow(wee,2) 
        f4 = ( pow(llx ,2) + pow(lly + stepY,2) )< pow(wee,2)
        #laser mark
        f5 =  ((lly + stepY) > 92) and ((llx+stepX < 13 and  llx+stepX>-13) or (llx < 13 and  llx>-13))
        f5 = not f5 
        #notch
        f6 =  (lly  < -94) and ((llx+stepX < 14 and  llx+stepX>-14) or (llx < 14 and  llx>-14))
        f6 = not f6         
        
        if f1 and f2 and f3 and f4 and f6:
            square = Rectangle(xy = (llx,lly),
                               width = stepX ,height = stepY,
                               alpha=1,fill=False, edgecolor='red', linewidth=0.3)
            ax.add_patch(square)
            totalDie = totalDie + shotDie
        else:
            if f1 or f2 or f3 or f4:
                square = Rectangle(xy = (llx,lly),
                               width = stepX ,height = stepY,
                               alpha=1,fill=False, edgecolor='green', linewidth=0.3)
                #ax.add_patch(square)
                partialShotDie = 0
                
                flag = gating(shotDie,gdw,dieX,dieY,col2,row2,llx,lly,stepX,stepY)

             
                
                for k in range(0,col2):
                    for l in range(0,row2):
                        sx = llx + k * dieX
                        sy = lly + l * dieY
                        
                        
                        
                        f1 = ( pow(sx,2) + pow(sy,2) ) < pow(wee,2)
                        f2 = ( pow(sx + dieX,2) + pow(sy,2) )< pow(wee,2) 
                        f3 = ( pow(sx + dieX,2) + pow(sy + dieY,2) )< pow(wee,2) 
                        f4 = ( pow(sx ,2) + pow(sy + dieY,2) )< pow(wee,2)
                        f5 =  ((sy + dieY) > 92) and ((sx+dieX < 13 and  sx+dieX>-13) or (sx < 13 and  sx>-13))
                        f5 = not f5
                       
                        f6 =  (sy < -94) and ((sx+dieX < 14 and  sx+dieX>-14) or (sx < 14 and  sx>-14))
                        f6 = not  f6                        
                        
                        
                        if f1 and f2 and f3 and f4 and f5 and f6:
                            if flag==True:
                                square = Rectangle(xy = (sx,sy),
                                   width = dieX ,height = dieY,
                                   facecolor = 'pink',
                                   alpha=1,fill=True, edgecolor='pink', linewidth=0.3)
                                ax.add_patch(square)
                                
                            else:
                                
                                square = Rectangle(xy = (sx,sy),
                                   width = dieX ,height = dieY,
                                   facecolor = 'green',
                                   alpha=1,fill=True, edgecolor='red', linewidth=0.3)
                                ax.add_patch(square)
                                partialShotDie += 1
                            
                        else:
                            if f1 or f2 or f3 or f4 :
                                square = Rectangle(xy = (sx,sy),
                                   width = dieX ,height = dieY,
                                   facecolor = 'grey',
                                   alpha=0.3,fill=True, edgecolor='green', linewidth=0.3)
                                ax.add_patch(square) 
                totalDie = totalDie + partialShotDie
                        
        
square = Rectangle(xy = (-13,92),
        width = 26 ,height = 8,
        facecolor = 'yellow',
        alpha=0.5,fill=True, edgecolor='black', linewidth=0.3)
ax.add_patch(square)

square = Rectangle(xy = (-14,-100),
        width = 28 ,height = 6,
        facecolor = 'yellow',
        alpha=0.5,fill=True, edgecolor='black', linewidth=0.3)
ax.add_patch(square)



x, y = 0, 0
ax.plot(x, y, 'ro')

plt.axis('scaled')
#ax.set_xlim(-8, 8)
#ax.set_ylim(-8,8)
plt.axis('equal') #changes limits of x or y axis so that equal increments of x and y have the same length






plt.text(-50, 50,'Total Die Qty: ' + str(int(totalDie)))    
plt.text(-50,40, 'Step Size: ' + str(stepX) + ', ' + str(stepY))
plt.text(-50,30, 'Die Size ' + str(dieX) + ', ' + str(dieY))
plt.text(-50,20, 'Offset Size: ' + str(offX) + ', ' + str(offY))
plt.text( -50,10,'Edge Exclusion: ' + str(100 - wee ))
plt.text( -50,0,'Unit: mm ' )
plt.text( -50,-10,'Product: ' + part)



plt.savefig('c:\\temp\\' + part + '1.jpg',dpi=600)
plt.savefig('c:\\temp\\' + part + '2.jpg',dpi=100)
plt.show()
















  

