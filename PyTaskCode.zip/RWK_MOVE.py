# -*- coding: utf-8 -*-
"""
Created on Fri Apr 27 12:38:02 2018

@author: HUANGWEI45
"""

import win32com.client
import datetime
import pandas as pd
import xlwings as xw
import matplotlib.pyplot as plt
import gc



def get_PE1_PE2_BreakDown():

    df = pd.read_csv('c:/temp/stage.csv')
    
    FEOL_Nikon = []
    FEOL_Asml =[]
    BEOL_Nikon = []
    BEOL_Asml = []
    
    partlist = df['Part'].unique()
    
    partlist = [ i for i in partlist if len(i)==11]
    
    
    for n,part in enumerate(partlist):
        flag = False
        
        
        
        tmp = df[df['Part']==part].reset_index()[['Stage','Tool']]
        
        if "CT-PH" in list(tmp['Stage']):
            print(n,len(partlist),'True')
        
            for i in range(tmp.shape[0]):
                if tmp.iloc[i][0]=='CT-PH':
                    flag = True
                if flag == False:
                    if tmp.iloc[i][1] == 'LDI':
                        FEOL_Asml.append(tmp.iloc[i][0])
                    else:
                        FEOL_Nikon.append(tmp.iloc[i][0])
                else:
                    if tmp.iloc[i][1] == 'LDI':
                        BEOL_Asml.append(tmp.iloc[i][0])
                    else:
                        BEOL_Nikon.append(tmp.iloc[i][0])  
                
    FN = set(FEOL_Nikon)
    BN = set(BEOL_Nikon)
    FA = set (FEOL_Asml)
    BA = set (BEOL_Asml)    
    
    
    
    
    
    fn = list(FN)
    bn = list(BN- (FN & BN))
    fa = list(FA)
    ba = list(BA - (FA & BA))
    return fn,bn,fa,ba




NikonF = ['VTP-PH', 'SDG-PH', 'CSD-PH', 'HVEB-PH', 'FPB-PH', 'VTN-PH',
 'ESD-PH', 'NCL-PH', 'JFP-PH', 'LVPW-PH', 'HVNW-PH', 'PSD-PH', 'PRS-PH', 'LLD-PH',
 'UPZ-PH', 'NSF-PH', 'PPW-PH', 'RN-PH', 'NSK-PH', 'LNS-PH', 'LVNW-PH', 'ZEN-PH',
 'LVTN-PH', 'BRN-PH', 'CLD-PH', 'ST3-PH', 'FPT-PH', 'LPL-PH', 'PO1-PH', 'HTN-PH',
 'TOR-PH', 'PBD-PH', 'PGD-PH', 'NED-PH', 'MVTN-PH', 'SAS-PH', 'VTHN-PH', 'NFI-PH',
 'DPE-PH', 'DVTN-PH', 'VTB-PH', 'NCA-PH', 'LTC-PH', 'ST2-PH', 'NLDD-PH', 'PGP-PH',
 'PCL-PH', 'DPW-PH', 'PVT-PH', 'MVTP-PH', 'LVT-PH', 'TG-PH', 'HVP-PH', 'VSD-PH',
 'PED-PH', 'HBP-PH', 'BRP-PH', 'LPS-PH', 'NDI-PH', 'UNW-PH', 'HVT-PH', 'HPL-PH',
 'RTR-PH', 'ONO-PH', 'CWL-PH', 'LVTP-PH', 'NGP-PH', 'NB-PH', 'PSF-PH', 'BAS-PH',
 'IMM-PH', 'DNW-PH', 'DG-PH', 'UPW-PH', 'NGD-PH', 'HVPW-PH', 'HR-PH', 'ST1-PH',
 'PW-PH', 'LLN-PH', 'PO0-PH', 'NSD-PH', 'NW-PH', 'LNL-PH', 'CVT-PH', 'CELL-PH',
 'SAB-PH', 'FN-PH', 'HNL-PH', 'PSK-PH', 'PO2-PH', 'DVTP-PH', 'PLDD-PH', 'PFI-PH']

NikonB = ['MIM-PH', 'PAJ-PH', 'VIA1-PH', 'FU-PH',
 'M2-PH', 'MI2-PH', 'CTP-PH', 'VIAT-PH',
 'CT-PH', 'PARC-PH', 'VIA2-PH', 'TM-PH',
 'M4-PH', 'CTN-PH', 'M1-PH', 'PAD-PH',
 'PI-PH', 'PAN-PH', 'PAF-PH', 'M3-PH']

AsmlF = ['SCW-PH', 'SDG-PH',
 'CSD-PH', 'LPL-PH', 'CGT-PH', 'TUN-PH', 'HR-PH', 'PO1-PH', 'TTR-PH', 'UHN-PH',
 'NVT-PH', 'TBO-PH', 'PBD-PH', 'PED-PH', 'PW-PH', 'PO0-PH', 'ESD-PH', 'DMP-PH',
 'HBP-PH', 'NSD-PH', 'ZERO-PH', 'NW-PH', 'NCL-PH', 'BN-PH', 'LNL-PH', 'IRS-PH',
 'CVT-PH', 'NLJ-PH', 'NLDD-PH', 'SAS-PH', 'VTHN-PH', 'HPL-PH', 'PLDD-PH', 'VTLN-PH',
 'VTLP-PH', 'NFI-PH', 'MP1-PH', 'NRO-PH', 'HVNW-PH', 'PSD-PH', 'ONO-PH', 'ZER2-PH',
 'SAB-PH', 'DVTN-PH', 'LLD-PH', 'PLK-PH', 'CLD-PH', 'LVTP-PH', 'PRO-PH', 'NSF-PH',
 'PPW-PH', 'NGP-PH', 'HNL-PH', 'TRE-PH', 'PSF-PH', 'NB-PH', 'NSK-PH', 'BAS-PH',
 'RN-PH', 'NPC-PH', 'LTP-PH', 'IMM-PH', 'DNW-PH', 'ZMS-PH', 'ZEN-PH', 'EMI-PH',
 'PO2-PH', 'VTHP-PH', 'UHP-PH', 'DG-PH', 'BRN-PH', 'LTN-PH', 'NGD-PH', 'PFI-PH']

AsmlB =['MGE-PH', 'CT-PH',
 'MAL-PH', 'OE-PH', 'CTP-PH', 'VIA2-PH', 'MGF-PH', 'M3-PH', 'VIA4-PH', 'M5-PH',
 'M2-PH', 'M7-PH', 'MVA-PH', 'M4-PH', 'TM-PH', 'M1-PH', 'VIA3-PH', 'VIA5-PH',
 'VIA1-PH', 'MIM-PH', 'OV-PH', 'VIAT-PH', 'M6-PH', 'MCW-PH', 'VIA6-PH', 'CTN-PH']






















def dict_list():
    key = ['DYN_PERF_MA_Z_ERROR_MAXRecipe', 'G3SIGXRecipe', 'DOSE_3SIGMA',
     'WFR_NONORTHOGONALITY_AVERecipe', 'GORTOGRecipe', 'ERROR161', '_80_TO_88',
     'IQ_IMAGE_TILT', '_PLATETEMPRecipe', 'DYN_PERF_MA_X_ERROR_MAXRecipe',
     'G3SIGYRecipe', 'S2F21',  'BuiltIn_TimePeriodRecip',
     'AUTOFUNC', '晶圆数量不匹配', 'IQ_STN_LNS_TILT', 'DYN_PERF_MSD_X_ERROR_MAX',
     'S7F1', 'ParameterIsInvalid', 'DYN_PERF_MSD_Y_ERROR_MAX',
     'ILMNIDRecipe', 'CannotPerformNow', 'S7F3', 'DYN_PERF_MA_Y_ERROR_MAX', 
     '[LOTHOLD]CMT=CIM/EAP/',
     'LARGEST_ORDER','LEVEL_TILT_MATCHING',
     'DEV_DEVELOPERTEMPRecipe','DEV_DEVELOPERFLOW1Recipe','CUP_1_HUMIDITYRecipe','DEV_BACKRINSEFLOW1Recipe',
     'ENERGY_ACTUALRecipe','WEE_ILLUMINATIONRecipe','_RESISTTEMPRecipe',
    'DYN_PERF_MSD_Z_ERROR_MAXRecipe','GSIFT','GSCAL','SPIN_ROTATION_SPEEDRecipe',
    'RESISTTEMPRecipe','IQCRecipe','HMDSFLOWRecipe','MOTORFLANGETEMPRecipe',
    'DYN_PERF_MA_RZ_ERROR_MAXRecipe','DYN_PERF_MSD_Z_ERROR_MAXRecipe',
    'IQ_ACTUATOR_TILT','Q_ABOVE_PRecipe','CUP_1_TEMPRecipe','DYN_PERF_MSD_RZ_ERROR_MAXRecipe']
     
    category = ['MA_Z', 'Alignment', 'Dose Error', 
    'Alignment', 'Alignment', 'Tool Status', 'Alignment',
     'Scanner', 'Track', 'Dynamic', 
     'Alignment', 'Offline Nikon',  'Scanner', 
     'AUTOFUNC', 'WfrQtyMismatch', 'Scanner', 'Dynamic', 
     'Offline Nikon', 'Track Recipe', 'Dynamic', 
     'Scanner', 'MFG', 'Offline Nikon', 'Dynamic',
     'EAP',
     'Alignment', 'Scanner', 
     'Track', 'Track', 'Track', 'Track',
     'Scanner', 'Track', 'Track', 'Dynamic',
      'Alignment', 'Alignment','Track','Track','Scanner','Track','Track',
      'Dynamic','Dynamic','Scanner','Scanner','Track','Dynamic']
     
    comment = ['', '', '', '', '', '当Tool status非Run状态（QCHOLD,WAITEND,DOWN,MONDOWN,PM等)下,lot不能正常出账',
     '', '', '', '', '', 'Offline NIKON因发送run 货命令失败造成（MASK对位报警；打开除RUN界面以外的界面等）',
     '', 'Scanner tool上线的FDC，延时原因：发生wafer reject或者EAP延时收集数据',
     '手动HOLD Lot触发E-RRC，主要为Track/scanner设备故障报警（此类报警非FDC 触发）',
     'RUN前扫描片数不对（TOOL WaferSensor）；wafer reject',
     '', '', 'Offline NIKON因发送run 货命令失败造成（MASK对位报警；打开除RUN界面以外的界面等）',
     '', '无Track Recipe或Track recipe校对失败或Track recipe 第一步被点灰不能使用，\n由EAP Running hold且不抽片',
     '', '', '多属于MFG MA操作不当造成，wafer放置stage上未等到Arm sensor 扫描cassette slot完成，就立即按RFID按钮',
     'Offline NIKON因发送run 货命令失败造成（MASK对位报警；打开除RUN界面以外的界面等）', '', ''] 
    #classification = pd.DataFrame( (np.array([key,category])).T,columns = ['key','category'])
    
    
    dic_stage_layer={'BAS-PH': 'BA','BN-PH': 'BN','BRN-PH': 'BN','BRP-PH': 'BP',  'CELL-PH': 'CI','CGT-PH': 'GC','CLD-PH': 'CL','CSD-PH': 'CS','CT-PH': 'W1',  'CTN-PH': 'NP','CTP-PH': 'PP','CVT-PH': 'VC','CWL-PH': 'CC','DG-PH': 'HV',  'DNW-PH': 'DN','DPE-PH': 'PE','DPW-PH': 'DP','DVTN-PH': 'ND','DVTP-PH': 'PD',  'ESD-PH': 'SE','FPB-PH': 'FB','FPT-PH': 'FT','FU-PH': 'FU','HBP-PH': 'XP',  'HNL-PH': 'HA','HPL-PH': 'HB','HR-PH': 'HR','HVEB-PH': 'WE','HVNW-PH': 'NX',  'HVP-PH': 'HP',  'HVPW-PH': 'PX',  'HVT-PH': 'HN',  'IMM-PH': 'IM',  'IRS-PH': 'IR',  'JFP-PH': 'JP',  'LLD-PH': 'LD',  'LNL-PH': 'LA',  'LNS-PH': 'NS',  'LPL-PH': 'LB',
      'LPS-PH': 'PS',  'LTC-PH': 'TC',  'LTN-PH': 'WN',  'LTP-PH': 'WP',  'LVNW-PH': 'NV',  'LVPW-PH': 'PV',  'LVT-PH': 'LV',  'LVTN-PH': 'LN',  'LVTP-PH': 'LP',  'M1-PH': 'A1',  'M2-PH': 'A2',  'M3-PH': 'A3',  'M4-PH': 'A4',  'M5-PH': 'A5',  'M6-PH': 'A6',  'M7-PH': 'A7',  'MAL-PH': 'MA',  'MCW-PH': 'MC',  'MGE-PH': 'GE',  'MGF-PH': 'GF',  'MI2-PH': 'MT',  'MIM-PH': 'CT',  'MP1-PH': 'T1',  'MVA-PH': 'MV',  'MVTN-PH': 'MN',  'MVTP-PH': 'MP',  'NB-PH': 'NB',  'NCA-PH': 'CA',
      'NCL-PH': 'RA',  'NED-PH': 'EN',  'NFI-PH': 'NF',  'NGD-PH': 'NG',  'NGP-PH': 'GN',  'NLDD-PH': 'NL',  'NLJ-PH': 'LJ',  'NRO-PH': 'RO',  'NSD-PH': 'SN',  'NSF-PH': 'NM',  'NSK-PH': 'NK',  'NW-PH': 'TB',  'OE-PH': 'OE',  'ONO-PH': 'ON',  'OV-PH': 'OV',  'PAD-PH': 'CP',  'PAF-PH': 'CF',  'PAJ-PH': 'PJ',  'PAN-PH': 'PN',  'PARC-PH': 'P2',  'PBD-PH': 'PB',  'PCL-PH': 'RB',  'PED-PH': 'EP',  'PFI-PH': 'PF',  'PGD-PH': 'PG',  'PI-PH': 'PI',  'PLDD-PH': 'PL',  'PLK-PH': 'LK',  'PO0-PH': 'P0',  'PO1-PH': 'GT',  'PO2-PH': 'PC',  'PPW-PH': 'PW',
      'PRO-PH': 'PR',  'PRS-PH': 'RS',  'PSD-PH': 'SP',  'PSF-PH': 'PM',  'PSK-PH': 'PK',  'PVT-PH': 'VT',  'PW-PH': 'PT',  'RN-PH': 'RN',  'RTR-PH': 'RT',  'SAB-PH': 'SI',  'SAS-PH': 'SS',  'SCW-PH': 'SW',  'SDG-PH': 'TO2',  'TG-PH': 'TG',  'TM-PH': 'TT',  'TOR-PH': 'RE',  'TRE-PH': 'TR',  'TTR-PH': 'TR',  'TUN-PH': 'TU',  'UHN-PH': 'UA',  'UHP-PH': 'UB',  'UNW-PH': 'UN',  'UPW-PH': 'UP',  'UPZ-PH': 'UZ',  'VIA1-PH': 'W2',  'VIA2-PH': 'W3',  'VIA3-PH': 'W4',  'VIA4-PH': 'W5',  'VIA5-PH': 'W6',  'VIA6-PH': 'W7',  'VIAT-PH': 'WT',  'VSD-PH': 'SD',
      'VTB-PH': 'BC',  'VTHN-PH': 'NH',  'VTHP-PH': 'PH',  'VTLP-PH': 'PA',  'VTN-PH': 'VN',  'ZEN-PH': 'ZP',  'ZERO-PH': 'ZO'}
    
    dic_layer_stage={'A1': 'M1-PH',  'A2': 'M2-PH',
      'A3': 'M3-PH',  'A4': 'M4-PH',  'A5': 'M5-PH',  'A6': 'M6-PH',  'A7': 'M7-PH',  'AT': 'TM-PH',  'BA': 'BAS-PH',  'BC': 'VTB-PH',
      'BN': 'BRN-PH',  'BP': 'BRP-PH',  'CA': 'NCA-PH',  'CC': 'CWL-PH',  'CF': 'PAF-PH',  'CI': 'CELL-PH',  'CL': 'CLD-PH',  'CP': 'PAD-PH',  'CS': 'CSD-PH',  'CT': 'MIM-PH',  'DN': 'DNW-PH',  'DP': 'DPW-PH',  'EN': 'NED-PH',  'EP': 'PED-PH',  'FB': 'FPB-PH',  'FT': 'FPT-PH',  'FU': 'FU-PH',  'GC': 'CGT-PH',  'GE': 'MGE-PH',  'GF': 'MGF-PH',  'GN': 'NGP-PH',  'GT': 'PO1-PH',  'HA': 'HNL-PH',  'HB': 'HPL-PH',  'HN': 'HVT-PH',  'HP': 'HVP-PH',  'HR': 'HR-PH',  'HV': 'DG-PH',  'IM': 'IMM-PH',  'IR': 'IRS-PH',  'JP': 'JFP-PH',  'LA': 'LNL-PH',
      'LB': 'LPL-PH',  'LD': 'LLD-PH',  'LJ': 'NLJ-PH',  'LK': 'PLK-PH',  'LN': 'LVTN-PH',  'LP': 'LVTP-PH',  'LV': 'LVT-PH',  'MA': 'MAL-PH',  'MC': 'MCW-PH',  'MN': 'MVTN-PH',  'MP': 'MVTP-PH',  'MT': 'MI2-PH',  'MV': 'MVA-PH',  'NB': 'NB-PH',  'ND': 'DVTN-PH',  'NF': 'NFI-PH',  'NG': 'NGD-PH',  'NH': 'VTHN-PH',  'NK': 'NSK-PH',  'NL': 'NLDD-PH',  'NM': 'NSF-PH',  'NP': 'CTN-PH',  'NS': 'LNS-PH',  'NV': 'LVNW-PH',  'NX': 'HVNW-PH',  'OE': 'OE-PH',  'ON': 'ONO-PH',  'OV': 'OV-PH',  'P0': 'PO0-PH',  'P2': 'PARC-PH',  'PA': 'VTLP-PH',  'PB': 'PBD-PH',
      'PC': 'PO2-PH',  'PD': 'DVTP-PH',  'PE': 'DPE-PH',  'PF': 'PFI-PH',  'PG': 'PGD-PH',  'PH': 'VTHP-PH',  'PI': 'PI-PH',  'PJ': 'PAJ-PH',  'PK': 'PSK-PH',  'PL': 'PLDD-PH',  'PM': 'PSF-PH',  'PN': 'PAN-PH',  'PP': 'CTP-PH',  'PR': 'PRO-PH',  'PS': 'LPS-PH',  'PT': 'PW-PH',  'PV': 'LVPW-PH',  'PW': 'PPW-PH',  'PX': 'HVPW-PH',  'RA': 'NCL-PH',  'RB': 'PCL-PH',  'RE': 'TOR-PH',  'RN': 'RN-PH',  'RO': 'NRO-PH',  'RS': 'PRS-PH',  'RT': 'RTR-PH',  'SD': 'VSD-PH',  'SE': 'ESD-PH',  'SI': 'SAB-PH',  'SN': 'NSD-PH',  'SP': 'PSD-PH',  'SS': 'SAS-PH',
      'SW': 'SCW-PH',  'T1': 'MP1-PH',  'TB': 'NW-PH',  'TC': 'LTC-PH',  'TG': 'TG-PH',  'TO': 'SDG-PH',  'TO2': 'SDG-PH',  'TR': 'TTR-PH',  'TT': 'TM-PH',  'TU': 'TUN-PH',  'UA': 'UHN-PH',  'UB': 'UHP-PH',  'UN': 'UNW-PH',  'UP': 'UPW-PH',  'UZ': 'UPZ-PH',  'VC': 'CVT-PH',  'VN': 'VTN-PH',  'VT': 'PVT-PH',  'W1': 'CT-PH',  'W2': 'VIA1-PH',  'W3': 'VIA2-PH',  'W4': 'VIA3-PH',  'W5': 'VIA4-PH',  'W6': 'VIA5-PH',
      'W7': 'VIA6-PH',  'WE': 'HVEB-PH',  'WN': 'LTN-PH',  'WP': 'LTP-PH',  'WT': 'VIAT-PH',  'XP': 'HBP-PH',  'ZO': 'ZERO-PH',  'ZP': 'ZEN-PH'}
    
    dic_layer_type ={'A1': 'METAL',  'A2': 'METAL',  'A3': 'METAL',  'A4': 'METAL',
      'A5': 'METAL',  'A6': 'METAL',  'A7': 'METAL',  'AT': 'TM',  'BA': 'NCL PRE POLY',  'BC': 'NCL PRE POLY',  'BN': 'NCL PRE POLY',  'BP': 'NCL PRE POLY',
      'CA': 'NCL PRE POLY',  'CC': 'NCL POST POLY',  'CF': 'PAD',  'CI': 'NCL POST POLY',  'CL': 'NCL POST POLY',  'CP': 'PAD',  'CS': 'NCL POST POLY',  'CT': 'METAL',  'DN': 'NCL PRE POLY',  'DP': 'NCL PRE POLY',  'EN': 'NCL POST POLY',  'EP': 'NCL POST POLY',  'FB': 'NCL PRE POLY',  'FT': 'NCL PRE POLY',  'FU': 'PAD',  'GC': 'POLY',
      'GE': 'NCL PRE POLY',  'GF': 'NCL PRE POLY',  'GN': 'NCL PRE POLY',  'GT': 'POLY',  'HA': 'NCL POST POLY',  'HB': 'NCL POST POLY',  'HN': 'NCL PRE POLY',  'HP': 'NCL PRE POLY',  'HR': 'NCL POST POLY',  'HV': 'NCL PRE POLY',  'IM': 'NCL POST POLY',  'IR': 'NCL PRE POLY',  'JP': 'NCL PRE POLY',  'LA': 'NCL POST POLY',  'LB': 'NCL POST POLY',  'LD': 'NCL POST POLY',
      'LJ': 'NCL PRE POLY',  'LK': 'NCL PRE POLY',  'LN': 'NCL PRE POLY',  'LP': 'NCL PRE POLY',  'LV': 'NCL PRE POLY',  'MA': 'NCL PRE POLY',  'MC': 'NCL PRE POLY',  'MN': 'NCL PRE POLY',  'MP': 'NCL PRE POLY',  'MT': 'NCL PRE POLY',  'MV': 'NCL PRE POLY',  'NB': 'NCL PRE POLY',  'ND': 'NCL PRE POLY',  'NF': 'NCL PRE POLY',  'NG': 'NCL PRE POLY',  'NH': 'NCL PRE POLY',
      'NK': 'NCL PRE POLY',  'NL': 'NCL POST POLY',  'NM': 'NCL PRE POLY',  'NP': 'NCL PRE POLY',  'NS': 'NCL PRE POLY',  'NV': 'NCL PRE POLY',  'NX': 'NCL PRE POLY',  'OE': 'NCL POST POLY',  'ON': 'NCL PRE POLY',  'OV': 'NCL POST POLY',  'P0': 'POLY',  'P2': 'PAD',  'PA': 'NCL PRE POLY',  'PB': 'NCL PRE POLY',  'PC': 'POLY',  'PD': 'NCL PRE POLY',
      'PE': 'NCL POST POLY',  'PF': 'NCL PRE POLY',  'PG': 'NCL PRE POLY',  'PH': 'NCL PRE POLY',  'PI': 'PAD',  'PJ': 'NCL PRE POLY',  'PK': 'NCL PRE POLY',  'PL': 'NCL POST POLY',  'PM': 'NCL PRE POLY',  'PN': 'NCL PRE POLY',  'PP': 'NCL POST POLY',  'PR': 'NCL POST POLY',  'PS': 'NCL PRE POLY',  'PT': 'NCL PRE POLY',  'PV': 'NCL PRE POLY',  'PW': 'NCL PRE POLY',  'PX': 'NCL PRE POLY',
      'RA': 'NCL PRE POLY',  'RB': 'NCL PRE POLY',  'RE': 'NCL PRE POLY',  'RN': 'NCL PRE POLY',  'RO': 'NCL POST POLY',  'RS': 'NCL PRE POLY',  'RT': 'NCL PRE POLY',  'SD': 'NCL PRE POLY',  'SE': 'NCL PRE POLY',  'SI': 'NCL POST POLY',  'SN': 'NCL POST POLY',  'SP': 'NCL POST POLY',  'SS': 'NCL POST POLY',  'SW': 'NCL PRE POLY',  'T1': 'NCL PRE POLY',  'TB': 'NCL PRE POLY',  'TC': 'NCL PRE POLY',
      'TG': 'NCL PRE POLY',  'TO': 'SDG',  'TO2': 'SDG',  'TR': 'NCL PRE POLY',  'TT': 'TM',  'TU': 'NCL PRE POLY',  'UA': 'NCL POST POLY',  'UB': 'NCL POST POLY',  'UN': 'NCL PRE POLY',  'UP': 'NCL PRE POLY',  'UZ': 'NCL PRE POLY',  'VC': 'NCL PRE POLY',  'VN': 'NCL PRE POLY',  'VT': 'NCL PRE POLY',  'W1': 'CT',  'W2': 'VIA',  'W3': 'VIA',
      'W4': 'VIA',  'W5': 'VIA',  'W6': 'VIA',  'W7': 'VIA',  'WE': 'NCL PRE POLY',  'WN': 'NCL PRE POLY',  'WP': 'NCL PRE POLY',  'WT': 'VIA',
      'XP': 'NCL POST POLY',  'ZO': 'NCL PRE POLY',  'ZP': 'NCL POST POLY','T2':'TM','T3':'TM'}
    
    dic_group_section = {'TM':'PE1', 'POLY':'PE1', 'CT':'PE2', 'VIA':'PE2', 'NCL POST POLY':'PE1', 'NCL PRE POLY':'PE2', 'METAL':'PE1','SDG':'PE2','PAD':'PE2'}
    
    group = ('TM', 'POLY', 'CT', 'VIA', 'NCL POST POLY', 'NCL PRE POLY', 'METAL','SDG')
    
    delta=datetime.timedelta(days=0.3125)
    
    databasepath = r'Y:\ERRC_RWK_MOVE\RwkMove.mdb' 
    
     
    # compiled database
    rawRwkMoveOcap =r'Y:\ERRC_RWK_MOVE\RwkMoveOcapRaw.xlsm'
    # excel script for ectracting move/rwk/ovap data
    rawErrc = r'D:\HuangWeiScript\Temp\ErrcRaw.xlsx'
    # manual extract ERRC data
    
    
    #pd.DataFrame.from_dict(dic_layer_type,orient='index')
    # dict to dataframe

    return key,category,comment,dic_stage_layer,dic_layer_stage,dic_layer_type,dic_group_section, group,delta,databasepath,rawRwkMoveOcap,rawErrc
























#####################################################################################
def get_db_latest_date1():
    
    key,category,comment,dic_stage_layer,dic_layer_stage,dic_layer_type,dic_group_section, group,delta,databasepath,rawRwkMoveOcap,rawErrc = dict_list()
    
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)    
    rs_name = ['MOVE','RWK','ERRC','OCAP']
    
    ##Move Table###################################################### 

    rs = win32com.client.Dispatch(r'ADODB.Recordset') 
    sql = " SELECT TRACKOUTTIME FROM " + rs_name [0] + "  Order By TRACKOUTTIME asc "  
    rs.Open(sql, conn, 1, 3)
    rs.MoveLast()
    #MOVEdate = datetime.datetime.strptime(  str( rs.Fields[0].Value ).rstrip("+00:00"), '%Y-%m-%d %H:%M:%S')
    # if str = '2018-1-1 16:32:20+00:00', the result is 2018-1-1 16:32:02
    MOVEdate = datetime.datetime.strptime(  str( rs.Fields[0].Value )[0:-6], '%Y-%m-%d %H:%M:%S')
  
    print('The latest date of MOVE is ' + str(MOVEdate) +'\n')
 
    
    ##RWK Table###################################################### 

    rs.close
    sql = " SELECT TIMEREV FROM " + rs_name [1] + "  Order By TIMEREV asc "  
    rs.Open(sql, conn, 1, 3)    
    rs.MoveLast()
    #RWKdate = datetime.datetime.strptime(  str( rs.Fields[0].Value ).rstrip("+00:00"), '%Y-%m-%d %H:%M:%S')
    RWKdate = datetime.datetime.strptime(  str( rs.Fields[0].Value )[0:-6], '%Y-%m-%d %H:%M:%S')
  
    print('The latest date of RWK is ' + str(RWKdate) +'\n')


   





   
    
    return MOVEdate, RWKdate











######################################################################################
def get_latest_chart_data1(MOVEdate, RWKdate):
    key,category,comment,dic_stage_layer,dic_layer_stage,dic_layer_type,dic_group_section, group,delta,databasepath,rawRwkMoveOcap,rawErrc = dict_list()
    

    print(" ========== RWK Data is being read ==========  \n")    
    rwkNew = pd.read_excel(rawRwkMoveOcap ,sheet_name = 'RWK',header = 0)
    rwkNew['TIMEREV'] = pd.to_datetime(rwkNew['TIMEREV'] )
    rwkNew = rwkNew.sort_values(by = 'TIMEREV',axis = 0)
     

    rwkNew['Week'] = [ (i-delta).strftime("%W") for i in rwkNew['TIMEREV']] 
    rwkNew['Month'] = [ (i-delta).month for i in rwkNew['TIMEREV']]
    rwkNew['Day'] = [ (i-delta).date() for i in rwkNew['TIMEREV']]    
    
    
    tmpstage = []
    tmpsection = []
    for count in range (rwkNew.shape[0]):
        stagestr = rwkNew.iloc[count,4]
        if 'KLA' in stagestr:
            stagestr = stagestr.split('-')[0] + '-PH'
        try:
            if stagestr in NikonF and rwkNew.iloc[count][6] != 'LDI':
                tmpstage.append('FEOL_NIKON')
                tmpsection.append('PE2')
            elif stagestr in NikonB and rwkNew.iloc[count][6] != 'LDI':
                tmpstage.append("BEOL_NIKON")
                tmpsection.append('PE1')
            elif stagestr in AsmlF and rwkNew.iloc[count][6] == 'LDI':
                tmpstage.append('ASML_FEOL')
                tmpsection.append('PE1')
            elif stagestr in AsmlB and rwkNew.iloc[count][6] == 'LDI':
                tmpstage.append('ASML_BEOL')
                tmpsection.append('PE2')
            else:
                tmpstage.append('TBD')
                tmpsection.append('TBD')
                print()
        except:            
            pass
            
   
   
                    
    rwkNew['Layer'] = '' #layer name
    rwkNew['Group'] = tmpstage # group layer
    rwkNew['Section'] = tmpsection # PE1,PE2
    
    rwk_new = rwkNew[ rwkNew['TIMEREV'] > RWKdate ]
    rwkNew = None
    print(" ========== RWK Data is ready ========== \n ")
    print( " ==========" + str (rwk_new.shape[0]) + " rows to be updated ========== \n  ")




    print(" ========== Move Data is being read ==========  \n") 
    moveNew = pd.read_excel(rawRwkMoveOcap,sheet_name = 'MOVE',header = 0)
    moveNew['TRACKOUTTIME'] = pd.to_datetime(moveNew['TRACKOUTTIME'] )
    moveNew = moveNew.sort_values(by = 'TRACKOUTTIME',axis = 0)
 
    moveNew['Week'] = [ (i-delta).strftime("%W") for i in moveNew['TRACKOUTTIME']] 
    moveNew['Month'] = [ (i-delta).month for i in moveNew['TRACKOUTTIME']] 
    moveNew['Day'] = [ (i-delta).date() for i in moveNew['TRACKOUTTIME']]
    
    tmpstage = []
    tmpsection = []
    for count in range (moveNew.shape[0]):
        stagestr = moveNew.iloc[count,4]
        if 'KLA' in stagestr:
            stagestr = stagestr.split('-')[0] + '-PH'

        try:
            if stagestr in NikonF and moveNew.iloc[count][5][1:4] in ['LSI','LII']: 
                tmpstage.append('FEOL_NIKON')
                tmpsection.append('PE2')
            elif stagestr in NikonB and moveNew.iloc[count][5][1:4] in ['LSI','LII']: 
                tmpstage.append("BEOL_NIKON")
                tmpsection.append('PE1')
            elif stagestr in AsmlF and moveNew.iloc[count][5][1:4] in ['LDI']: 
                tmpstage.append('ASML_FEOL')
                tmpsection.append('PE1')
            elif stagestr in AsmlB and moveNew.iloc[count][5][1:4] in ['LDI']: 
                tmpstage.append('ASML_BEOL')
                tmpsection.append('PE2')
            else:
                tmpstage.append('TBD')
                tmpsection.append('TBD')
        except:            
            pass
            
    moveNew['Layer'] = '' #layer name
    moveNew['Group'] = tmpstage # group layer
    moveNew['Section'] = tmpsection # PE1,PE2
    
    move_new = moveNew[ moveNew['TRACKOUTTIME'] > MOVEdate ]
    moveNew = None



    

    
    return rwk_new, move_new

############################################################################################


 
    







def update_db(rwk_new, move_new):
    key,category,comment,dic_stage_layer,dic_layer_stage,dic_layer_type,dic_group_section, group,delta,databasepath,rawRwkMoveOcap,rawErrc = dict_list()
    
    #################################################
    #https://zhidao.baidu.com/question/1832218251617721020.html
    import pytz
    tz = pytz.timezone("GMT")  # settime zone
    #datetime.datetime(2009, 2, 21, 15, 12, 33, tzinfo=tz)    
    # datetime format of access:  pywintypes.datetime, with time zone information
    # datetime format of pandas:  pandas.tslib.Timestamp -->swith to datetime with time zone
    
    
    tmp = []
    for i in rwk_new['TRACKINTIME']:
        if i==i:
            tmp.append(i)
        else:
            tmp.append(datetime.datetime.now()  -datetime.timedelta(days=1))    
    rwk_new['TRACKINTIME'] = pd.to_datetime(tmp)
    # NaT switch to time
    # if fillna(0), error triggered while database update
    
    

    rwk_new = rwk_new.fillna(0)
    move_new = move_new.fillna(0)
      
    
                 
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)


    rs_name = ['MOVE','RWK','ERRC','OCAP']    
    
    
    print ('MOVE database is being updated................')
    move_new['TRACKOUTQTY'] = move_new['TRACKOUTQTY'].astype('object')
    move_new['TRACKINUSER'] = move_new['TRACKINUSER'].astype('object')
    move_new['TRACKOUTUSER'] = move_new['TRACKOUTUSER'].astype('object')
    move_new['Week'] = move_new['Week'].astype('object')
    move_new['Month'] = move_new['Month'].astype('object')
    move_new['ARRIVETIME'] = move_new['ARRIVETIME'].astype('object')
    move_new['TRACKINTIME'] = move_new['TRACKINTIME'].astype('object')
    move_new['Day'] = pd.to_datetime( move_new['Day'])
    
    
    rs = win32com.client.Dispatch(r'ADODB.Recordset')
    rs.Open(  rs_name[0] , conn, 1, 3)
    #rs.MoveLast()
    for i in range(move_new.shape[0]):

        rs.AddNew()  #添加一条新记录 
        for j in range(move_new.shape[1]):
           
           
            if j in [8,9,10,17]:
        
                tmp = move_new.iloc[i,j]
                tmp = datetime.datetime(tmp.year, tmp.month, tmp.day, tmp.hour, tmp.minute, tmp.second, tzinfo=tz)
                rs.Fields.Item(j).Value = tmp
                #rs.Fields.Item(j).Value = cd_new.iloc[i,j].tz_localize("Asia/Shanghai")  #GMT
            else:
                if j in [13,14]:
                    rs.Fields.Item(j).Value =str( move_new.iloc[i,j]) [0:255] #str > 255, alarm
                else:
                    if j ==11:
                        if type( move_new.iloc[i,j]) == str:   # empolyID like 'super user', data type not integer
                            rs.Fields.Item(j).Value = 888888
                    else:
                        rs.Fields.Item(j).Value = move_new.iloc[i,j]
        rs.Update()  #更新
    print ('Move database update is completed.    ' + str(move_new.shape[0]) + ' rows have been inserted')
    rs = None





    print ('RWK database is being updated................')
    rwk_new['PRI'] = rwk_new['PRI'].astype('object')
    rwk_new['QTY'] = rwk_new['QTY'].astype('object')    
    rwk_new['Week'] = rwk_new['Week'].astype('object')    
    rwk_new['Month'] = rwk_new['Month'].astype('object')    
    rwk_new['Day'] = pd.to_datetime ( rwk_new['Day'] )
    #rwk_new['TRACKINTIME'] = pd.to_datetime ( rwk_new['TRACKINTIME'] )
    
    
    
    
    rs = win32com.client.Dispatch(r'ADODB.Recordset')
    rs.Open(  rs_name[1] , conn, 1, 3)
    #rs.MoveLast()
    for i in range(rwk_new.shape[0]):
        
        rs.AddNew()  #添加一条新记录 
        for j in range(rwk_new.shape[1]):
            #print (i,j, asml_new.iloc[i,j])
           
            if j in [0,9,10,17]:
        
                tmp = rwk_new.iloc[i,j]
                tmp = datetime.datetime(tmp.year, tmp.month, tmp.day, tmp.hour, tmp.minute, tmp.second, tzinfo=tz)
                rs.Fields.Item(j).Value = tmp
                #rs.Fields.Item(j).Value = cd_new.iloc[i,j].tz_localize("Asia/Shanghai")  #GMT
            else:
                rs.Fields.Item(j).Value = rwk_new.iloc[i,j]
        rs.Update()  #更新
    print ('RWK database update is completed.    ' + str(rwk_new.shape[0]) + ' rows have been inserted')
    rs = None
   
    conn.close
        


def query_rwk():
    
    key,category,comment,dic_stage_layer,dic_layer_stage,dic_layer_type,dic_group_section, group,delta,databasepath,rawRwkMoveOcap,rawErrc = dict_list()
    
    #C1涂胶异常    MO误操作返工    NPSIN颗粒异常    P1先行片返工    P2对偏返工    P3聚焦返工    PA扩散炉管工艺中断    PCCD异常    POoverlay异常    Q1TRACK设备故障    Q2曝光设备故障    SNSIN全剥返工    T0光刻其他原因    T0光刻其它原因    T0光刻其它原因返工    T1形貌差    T2光刻工艺试验返工    T3来片原因    T4动力故障    T5划伤    T6沾污    T7表面颗粒    Z1EIP中断    Z1非光刻原因    Z2TD/PID原因返工    Z4Q-TIME超时    Z5短流程返工    Z6TD/PID CD 特殊需求    Z7腐蚀返工    Z7腐蚀原因返工
    
    #conn = win32com.client.Dispatch(r"ADODB.Connection")  
    
    conn =  win32com.client.Dispatch(r"ADODB.Connection")
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)        
    ##Move Table###################################################### 

    rs = win32com.client.Dispatch(r'ADODB.Recordset') 
    sql  = ' SELECT  RWK.Month, Count(RWK.QTY) AS Lot, Sum(RWK.QTY) AS Wafer \
           FROM RWK WHERE (RWK.CODE not in ("Q1","Q2","PA","SN","T4","Z1","Z7") )  \
           GROUP BY RWK.Month;'
           #PA扩散炉管工艺中断 Q1TRACK设备故障  Q2曝光设备故障  SNSIN全剥返工  T4动力故障  Z1EIP中断  Z7腐蚀返工  Z7腐蚀原因返工
           # Codes above are excluded
    rs.Open(sql, conn, 1, 3)
        
    rwkMonthSum=[]    
    rs.MoveFirst()
    while True:
        if rs.EOF:
            break
        else:
            tmp = [rs.Fields(0).value,rs.Fields(1).value,rs.Fields(2).value]
            rwkMonthSum.append(tmp)
        rs.MoveNext()
    rwkMonthSum = pd.DataFrame(rwkMonthSum,columns=['Month','Lot','Wafer'])
    rs.close
    

    sql  = ' SELECT  RWK.Week, Count(RWK.QTY) AS Lot, Sum(RWK.QTY) AS Wafer \
           FROM RWK WHERE (RWK.CODE not in ("Q1","Q2","PA","SN","T4","Z1","Z7") )  \
           GROUP BY RWK.Week;'
    rs.Open(sql, conn, 1, 3)
    rwkWeekSum=[]    
    rs.MoveFirst()
    while True:
        if rs.EOF:
            break
        else:
            tmp = [rs.Fields(0).value,rs.Fields(1).value,rs.Fields(2).value]
            rwkWeekSum.append(tmp)
        rs.MoveNext()
    rwkWeekSum = pd.DataFrame(rwkWeekSum,columns=['Week','Lot','Wafer'])
    rs.close


    sql  = ' SELECT  RWK.Month, RWK.Group,Count(RWK.QTY) AS Lot, Sum(RWK.QTY) AS Wafer \
           FROM RWK WHERE (RWK.CODE not in ("Q1","Q2","PA","SN","T4","Z1","Z7") )  \
           GROUP BY RWK.Month,RWK.Group;'
    rs.Open(sql, conn, 1, 3)
    rwkMonthBreakdown=[]    
    rs.MoveFirst()
    while True:
        if rs.EOF:
            break
        else:
            tmp = [rs.Fields(0).value,rs.Fields(1).value,rs.Fields(2).value,rs.Fields(3).value]
            rwkMonthBreakdown.append(tmp)
        rs.MoveNext()
    rwkMonthBreakdown = pd.DataFrame(rwkMonthBreakdown,columns=['Month','Group','Lot','Wafer'])
    rs.close


    sql  = ' SELECT  RWK.Week, RWK.Group,Count(RWK.QTY) AS Lot, Sum(RWK.QTY) AS Wafer \
           FROM RWK WHERE (RWK.CODE not in ("Q1","Q2","PA","SN","T4","Z1","Z7") )  \
           GROUP BY RWK.Week,RWK.Group;'
    rs.Open(sql, conn, 1, 3)
    rwkWeekBreakdown=[]    
    rs.MoveFirst()
    while True:
        if rs.EOF:
            break
        else:
            tmp = [rs.Fields(0).value,rs.Fields(1).value,rs.Fields(2).value,rs.Fields(3).value]
            rwkWeekBreakdown.append(tmp)
        rs.MoveNext()
    rwkWeekBreakdown = pd.DataFrame(rwkWeekBreakdown,columns=['Week','Group','Lot','Wafer'])
    rs.close


    sql  = ' SELECT  RWK.Day, RWK.Group,Count(RWK.QTY) AS Lot, Sum(RWK.QTY) AS Wafer \
           FROM RWK WHERE (RWK.CODE not in ("Q1","Q2","PA","SN","T4","Z1","Z7") )  \
           GROUP BY RWK.Day,RWK.Group;'
    rs.Open(sql, conn, 1, 3)
    rwkDayBreakdown=[]    
    rs.MoveFirst()
    while True:
        if rs.EOF:
            break
        else:
            tmp = [rs.Fields(0).value,rs.Fields(1).value,rs.Fields(2).value,rs.Fields(3).value]
            rwkDayBreakdown.append(tmp)
        rs.MoveNext()
    rwkDayBreakdown = pd.DataFrame(rwkDayBreakdown,columns=['Day','Group','Lot','Wafer'])
    rs.close
    
    
    
    
    
    #extract rwk data and save to xls file
    
    tmp = str((datetime.datetime.now()-datetime.timedelta(days=1)).date())
    sql  = "SELECT RWK.* FROM RWK WHERE RWK.HISTDATE = #" + tmp +"#"
    rs.Open(sql, conn, 1, 3)

    data = []
    tmp1 = []
    rs.MoveFirst()
    n = rs.Fields.count
    for i in range(n):
        tmp1.append( rs.Fields(i).name)

    
    while True:
        if rs.EOF:
            break
        else:
            tmp = []
            for i in range(n):
                tmp.append(rs.Fields(i).value)
            data.append(tmp)
        rs.MoveNext()
    data = pd.DataFrame(data,columns = tmp1)
    data['HISTDATE'] = [str(i) for i in data['HISTDATE']]
    data['TRACKINTIME'] = [str(i) for i in data['TRACKINTIME']]
    data['TIMEREV'] = [str(i) for i in data['TIMEREV']]
    data['Day'] = [str(i) for i in data['Day']]
   
    rs.close    
    
    #wb = xw.Book(r'p:\RoutineWork\ScriptSaving.xlsx')    
    #sht = wb.sheets["RWK"]
    #sht.cells.clear_contents()
    #sht.range("A1").value = data
    #wb.save()
    #wb.close()
    
    data.to_csv ('Z:\\_DailyCheck\\OptOvl_Others\\DailyRework\\RWK' + str(datetime.datetime.now().date()) + '.csv',encoding = 'GBK')
    
    
            
    conn.close
    
    return rwkMonthSum,rwkWeekSum,rwkMonthBreakdown,rwkWeekBreakdown,rwkDayBreakdown

  


def query_move():
    key,category,comment,dic_stage_layer,dic_layer_stage,dic_layer_type,dic_group_section, group,delta,databasepath,rawRwkMoveOcap,rawErrc = dict_list()
    
    
    
 
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)        


    rs = win32com.client.Dispatch(r'ADODB.Recordset') 
    sql  = ' SELECT  MOVE.Month, Count(MOVE.TRACKOUTQTY) AS Lot, Sum(MOVE.TRACKOUTQTY) AS Wafer \
           FROM MOVE    \
           GROUP BY MOVE.Month;'

    rs.Open(sql, conn, 1, 3)
        
    moveMonthSum=[]    
    rs.MoveFirst()
    while True:
        if rs.EOF:
            break
        else:
            tmp = [rs.Fields(0).value,rs.Fields(1).value,rs.Fields(2).value]
            moveMonthSum.append(tmp)
        rs.MoveNext()
    moveMonthSum = pd.DataFrame(moveMonthSum,columns=['Month','Lot','Wafer'])
    rs.close
    

    sql  = ' SELECT  MOVE.Week, Count(MOVE.TRACKOUTQTY) AS Lot, Sum(MOVE.TRACKOUTQTY) AS Wafer \
           FROM MOVE    \
           GROUP BY MOVE.Week;'
    rs.Open(sql, conn, 1, 3)
    moveWeekSum=[]    
    rs.MoveFirst()
    while True:
        if rs.EOF:
            break
        else:
            tmp = [rs.Fields(0).value,rs.Fields(1).value,rs.Fields(2).value]
            moveWeekSum.append(tmp)
        rs.MoveNext()
    moveWeekSum = pd.DataFrame(moveWeekSum,columns=['Week','Lot','Wafer'])
    rs.close


    sql  = ' SELECT  MOVE.Month, MOVE.Group,Count(MOVE.TRACKOUTQTY) AS Lot, Sum(MOVE.TRACKOUTQTY) AS Wafer \
           FROM MOVE    \
           GROUP BY MOVE.Month,MOVE.Group;'
    rs.Open(sql, conn, 1, 3)
    moveMonthBreakdown=[]    
    rs.MoveFirst()
    while True:
        if rs.EOF:
            break
        else:
            tmp = [rs.Fields(0).value,rs.Fields(1).value,rs.Fields(2).value,rs.Fields(3).value]
            moveMonthBreakdown.append(tmp)
        rs.MoveNext()
    moveMonthBreakdown = pd.DataFrame(moveMonthBreakdown,columns=['Month','Group','Lot','Wafer'])
    rs.close


    sql  = ' SELECT  MOVE.Week, MOVE.Group,Count(MOVE.TRACKOUTQTY) AS Lot, Sum(MOVE.TRACKOUTQTY) AS Wafer \
           FROM MOVE    \
           GROUP BY MOVE.Week,MOVE.Group;'
    rs.Open(sql, conn, 1, 3)
    moveWeekBreakdown=[]    
    rs.MoveFirst()
    while True:
        if rs.EOF:
            break
        else:
            tmp = [rs.Fields(0).value,rs.Fields(1).value,rs.Fields(2).value,rs.Fields(3).value]
            moveWeekBreakdown.append(tmp)
        rs.MoveNext()
    moveWeekBreakdown = pd.DataFrame(moveWeekBreakdown,columns=['Week','Group','Lot','Wafer'])
    rs.close


    sql  = ' SELECT  MOVE.Day, MOVE.Group,Count(MOVE.TRACKOUTQTY) AS Lot, Sum(MOVE.TRACKOUTQTY) AS Wafer \
           FROM MOVE    \
           GROUP BY MOVE.Day,MOVE.Group;'
    rs.Open(sql, conn, 1, 3)
    moveDayBreakdown=[]    
    rs.MoveFirst()
    while True:
        if rs.EOF:
            break
        else:
            tmp = [rs.Fields(0).value,rs.Fields(1).value,rs.Fields(2).value,rs.Fields(3).value]
            moveDayBreakdown.append(tmp)
        rs.MoveNext()
    moveDayBreakdown = pd.DataFrame(moveDayBreakdown,columns=['Day','Group','Lot','Wafer'])
    rs.close
    conn.close
    
    return moveMonthSum,moveWeekSum,moveMonthBreakdown,moveWeekBreakdown,moveDayBreakdown



    



def plot_rwk(rwkStat,moveStat):
    key,category,comment,dic_stage_layer,dic_layer_stage,dic_layer_type,dic_group_section, group,delta,databasepath,rawRwkMoveOcap,rawErrc = dict_list()
    
    
    #Monthly
    x = rwkStat[0].copy().reset_index().set_index(['Month'])
    x = x.drop(['index'],axis = 1)
    y = moveStat[0].copy().reset_index().set_index(['Month'])
    y = y.drop(['index'],axis = 1)
    df = pd.concat([x,y],axis =1 ,join_axes= [y.index])
    df.columns =['rwkLot','rwkWafer','moveLot','moveWafer']
    df['RwkRatioByLot'] = df['rwkLot']/df['moveLot']*100
    df['RwkRatioByWafer']=df['rwkWafer']/df['moveWafer']*100
    
    tmp=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
    df.index = [tmp[i] for i in range(df.shape[0])]
        
    
    #wb = xw.Book(r'p:\RoutineWork\ScriptSaving.xlsx')    
    #sht = wb.sheets["RWK"] 
    tmp = df['RwkRatioByWafer']        
    fig = plt.figure(figsize =(12,4))
    ax1 = fig.add_subplot(1,1,1) 
    ax1 = tmp.plot(kind='bar')
    ax1.set_xticklabels(df.index,rotation=90)
    ax1.set_title ('Monthly Rework Ratio By Wafer')
    ax1.set_ylabel("Percentage")
    ax1.legend()
    ax1.xaxis.grid(True)
    ax1.yaxis.grid(True)
    #sht.pictures.add(fig, name='MonthlyWfr', update=True,
    #                     left=sht.range('B57').left, top=sht.range('B57').top) 
    plt.savefig('Z:\\_DailyCheck\\OptOvl_Others\\DailyRework\\MonthlyByWafer.jpg' ,dpi=100, bbox_inches='tight')
                               
    plt.clf() # 清图。
    plt.cla() # 清坐标轴。
    plt.close() # 关窗口
    gc.collect()         
       
    
    tmp = df['RwkRatioByLot']
    fig = plt.figure(figsize =(12,4))        
    ax2 = fig.add_subplot(1,1,1) 
    ax2 = tmp.plot(kind='bar')
    ax2.set_xticklabels(df.index,rotation=90)
    ax2.set_title ('Monthly Rework Ratio By Lot')
    ax2.set_ylabel("Percentage")
    ax2.legend()
    ax2.xaxis.grid(True)
    ax2.yaxis.grid(True)
    #sht.pictures.add(fig, name='MonthlyByLot', update=True,
    #                     left=sht.range('U57').left, top=sht.range('U57').top) 
    plt.savefig('z:\\_DailyCheck\\OptOvl_Others\\DailyRework\\MonthlyByLot.jpg' ,dpi=100, bbox_inches='tight')
                   
    plt.clf() # 清图。
    plt.cla() # 清坐标轴。
    plt.close() # 关窗口
    gc.collect() 



    #Weekly
    x = rwkStat[1].copy().reset_index().set_index(['Week'])
    x = x.drop(['index'],axis = 1)
    y = moveStat[1].copy().reset_index().set_index(['Week'])
    y = y.drop(['index'],axis = 1)
    
    df = pd.concat([x,y],axis =1 ,join_axes= [y.index])
    df.columns =['rwkLot','rwkWafer','moveLot','moveWafer']
    df['RwkRatioByLot'] = df['rwkLot']/df['moveLot']*100
    df['RwkRatioByWafer']=df['rwkWafer']/df['moveWafer']*100
    

    df.index = ['WW' + str(int(i)) for i in df.index]

    tmp = df['RwkRatioByWafer']        
    fig = plt.figure(figsize =(12,4))
    ax1 = fig.add_subplot(1,1,1) 
    ax1 = tmp.plot(kind='bar')
    ax1.set_xticklabels(df.index,rotation=90)
    ax1.set_title ('Weekly Rework Ratio By Wafer')
    ax1.set_ylabel("Percentage")
    ax1.legend()
    ax1.xaxis.grid(True)
    ax1.yaxis.grid(True)
    #sht.pictures.add(fig, name='WeeklyWfr', update=True,
    #                     left=sht.range('B57').left, top=sht.range('B57').top)                    
    plt.savefig('z:\\_DailyCheck\\OptOvl_Others\\DailyRework\\WeeklyByWafer.jpg' ,dpi=100, bbox_inches='tight')
                       
    #plt.show()
        

    plt.clf() # 清图。
    plt.cla() # 清坐标轴。
    plt.close() # 关窗口
    gc.collect()        
        
        
    
    tmp = df['RwkRatioByLot']
    fig = plt.figure(figsize =(12,4))        
    ax2 = fig.add_subplot(1,1,1) 
    ax2 = tmp.plot(kind='bar')
    ax2.set_xticklabels(df.index,rotation=90)
    ax2.set_title ('Weekly Rework Ratio By Lot')
    ax2.set_ylabel("Percentage")
    ax2.legend()
    ax2.xaxis.grid(True)
    ax2.yaxis.grid(True)
    #sht.pictures.add(fig, name='WeeklyByLot', update=True,
    #                     left=sht.range('U57').left, top=sht.range('U57').top)
    plt.savefig('z:\\_DailyCheck\\OptOvl_Others\\DailyRework\\MonthlyByLot.jpg' ,dpi=100, bbox_inches='tight')
                   

    #plt.show()
    #plt.show()
    plt.clf() # 清图。
    plt.cla() # 清坐标轴。
    plt.close() # 关窗口
    gc.collect() 



    #daily breakdown
    
    
    x = rwkStat[4].copy()
    x['Day']= [ str(i.date()) for i in x['Day']]
    x = x.reset_index().set_index(['Day','Group'])
    x = x.drop(['index'],axis = 1)
    y = moveStat[4].copy()
    y['Day']= [ str(i.date()) for i in y['Day']]
    y = y.reset_index().set_index(['Day','Group'])
    y = y.drop(['index'],axis = 1)
    df = pd.concat([x,y],axis =1 ,join_axes= [y.index])
    df = df.fillna(0)
    
    df.columns =['rwkLot','rwkWafer','moveLot','moveWafer']
    df['RwkRatioByLot'] = df['rwkLot']/df['moveLot']*100
    df['RwkRatioByWafer']=df['rwkWafer']/df['moveWafer']*100

    df = df.reset_index().set_index(['Day'])
    df = df.fillna(0)


    for layer in ['CT', 'METAL', 'NCL POST POLY', 'NCL PRE POLY', 'PAD', 'POLY', 'SDG', 'TM', 'VIA']:

        
        tmp = df[ df['Group'] == layer ][-61:]['RwkRatioByLot']
        fig = plt.figure(figsize =(12,4))
        ax = fig.add_subplot(1,1,1)
        ax = tmp.plot(kind='bar')
        ax.set_xticklabels( tmp.index,rotation=90)
        ax.set_title ('Daily Rework Ratio ByLot_' + layer)
        ax.set_ylabel("Percentage")
        ax.legend()
        ax.xaxis.grid(True)
        ax.yaxis.grid(True)
        #sht.pictures.add(fig, name=('ByLot' + layer), update=True,
        #             left=sht.range('A2').left, top=sht.range('A2').top)
        plt.savefig('z:\\_DailyCheck\\OptOvl_Others\\DailyRework\\DailyByLot_' + layer + '.jpg' ,dpi=100, bbox_inches='tight')
                   
               
        #plt.show()
        #plt.show()
        plt.clf() # 清图。
        plt.cla() # 清坐标轴。
        plt.close() # 关窗口
        gc.collect()                


        
        tmp = df[ df['Group'] == layer ][-61:]['RwkRatioByWafer']
        fig = plt.figure(figsize =(12,4))
        ax = fig.add_subplot(1,1,1)
        ax = tmp.plot(kind='bar')
        ax.set_xticklabels( tmp.index,rotation=90)
        ax.set_title ('Daily Rework Ratio ByWfr_' + layer)
        ax.set_ylabel("Percentage")
        ax.legend()
        ax.xaxis.grid(True)
        ax.yaxis.grid(True)
        #sht.pictures.add(fig, name=('ByWafer' + layer), update=True,
        #             left=sht.range('A2').left, top=sht.range('A2').top)
        plt.savefig('z:\\_DailyCheck\\OptOvl_Others\\DailyRework\\DailyByWafer_' + layer + '.jpg' ,dpi=100, bbox_inches='tight')
           
        #plt.show()
        #plt.show()
        plt.clf() # 清图。
        plt.cla() # 清坐标轴。
        plt.close() # 关窗口
        gc.collect()                      
                         
    #wb.save()
    #wb.close()
        


def  query_plot_ocap():
    key,category,comment,dic_stage_layer,dic_layer_stage,dic_layer_type,dic_group_section, group,delta,databasepath,rawRwkMoveOcap,rawErrc = dict_list()
    
    #wb = xw.Book(r'p:\RoutineWork\ScriptSaving.xlsx')    
    #sht = wb.sheets["OCAP"]     
    
 
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)        


    rs = win32com.client.Dispatch(r'ADODB.Recordset') 
    
    sql = 'Select * from OCAP Where Day = #' + str(datetime.datetime.now().date()-datetime.timedelta(days = 1)) + '#' 
    rs.Open(sql, conn, 1, 3)

    dailydata = []
    rs.MoveFirst()
    while True:
        if rs.EOF:
            break
        else:
            dailydata.append( [ rs.fields.item(i).value for i in range (rs.fields.count)] )
        rs.MoveNext()
    dailydata = pd.DataFrame(dailydata,columns = [ rs.fields.item(i).name for i in range (rs.fields.count)])
    dailydata['TRIGGER_TIMESTAMP'] = dailydata['TRIGGER_TIMESTAMP'].astype('str')
    dailydata['Day'] = dailydata['Day'].astype('str')
    dailydata.to_csv('z:\\_DailyCheck\\OptOvl_Others\\DailyOcap\\_'  + str(datetime.datetime.now().date()) + '.csv' ,encoding = 'GBK' )
    
    
    
    
    
    rs.close
    sql  = ' SELECT OCAP.Month, OCAP.Week, OCAP.Day, OCAP.Group, OCAP.OOC_OR_OOS, Count(OCAP.OOC_OR_OOS) AS QTY  \
    FROM OCAP WHERE (((OCAP.OBJECT_ID) Not Like "L99*"))  \
    GROUP BY OCAP.Month, OCAP.Week, OCAP.Day, OCAP.Group, OCAP.OOC_OR_OOS   \
    ORDER BY OCAP.Day;'

    rs.Open(sql, conn, 1, 3)    
    ocapSum=[]    
    rs.MoveFirst()
    while True:
        if rs.EOF:
            break
        else:
            tmp = [rs.Fields(0).value,rs.Fields(1).value,rs.Fields(2).value,rs.Fields(3).value,rs.Fields(4).value,rs.Fields(5).value]
            ocapSum.append(tmp)
        rs.MoveNext()
    ocapSum = pd.DataFrame(ocapSum,columns=['Month','Week','Day','Group','OOC_OR_OOS','QTY'])
    rs.close
    ocapSum['Day'] =[ str(i.date()) for i in ocapSum['Day'] ]

    
    
 

    sql = 'SELECT OCAP.Month, OCAP.Week, OCAP.Day,  OCAP.OOC_OR_OOS,OCAP.OBJECT_ID, Count(OCAP.OOC_OR_OOS) AS QTY \
           FROM OCAP WHERE LEFT(OCAP.OBJECT_ID,3) = "L99"   \
           GROUP BY OCAP.Month, OCAP.Week, OCAP.Day,  OCAP.OOC_OR_OOS,OCAP.OBJECT_ID  ORDER BY OCAP.Day;'
    rs.Open(sql, conn, 1, 3)    
    ocapQcSum=[]    
    rs.MoveFirst()
    while True:
        if rs.EOF:
            break
        else:
            tmp = [rs.Fields(0).value,rs.Fields(1).value,rs.Fields(2).value,rs.Fields(3).value,rs.Fields(4).value,rs.Fields(5).value]
            ocapQcSum.append(tmp)
        rs.MoveNext()
    ocapQcSum = pd.DataFrame(ocapQcSum,columns=['Month','Week','Day','OOC_OR_OOS','OBJECT_ID','QTY'])
    rs.close        
    ocapQcSum['Day'] =[ str(i.date()) for i in ocapQcSum['Day'] ]



    #Monthly
    tmp = ocapSum['QTY'].groupby([ocapSum['Month'],ocapSum['OOC_OR_OOS']]).sum()
    tmp = tmp.unstack()
    tmp1=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
    tmp.index = [tmp1[i] for i in range(tmp.shape[0])]
    
    
    fig = plt.figure(figsize =(12,4))        
    ax1 = fig.add_subplot(1,2,1) 
    ax1 = tmp['OOC'].plot(kind='bar')
    ax1.set_xticklabels(tmp.index,rotation=90)
    ax1.set_title ('Monthly OOC COUNT')
    ax1.set_ylabel("Count")
    ax1.legend()
    ax1.xaxis.grid(True)
    ax1.yaxis.grid(True)
    
    ax2 = fig.add_subplot(1,2,2) 
    ax2 = tmp['OOS'].plot(kind='bar')
    ax2.set_xticklabels(tmp.index,rotation=90)
    ax2.set_title ('Monthly OOS COUNT')
    ax2.set_ylabel("Count")
    ax2.legend()
    ax2.xaxis.grid(True)
    ax2.yaxis.grid(True)
   
    #sht.pictures.add(fig, name='Monthly OCAP', update=True,
    #                 left=sht.range('A2').left, top=sht.range('A2').top)
    plt.savefig('z:\\_DailyCheck\\OptOvl_Others\\DailyOcap\\Monthly.jpg' ,dpi=100, bbox_inches='tight')
           

    #plt.show()
   
    plt.clf() # 清图。
    plt.cla() # 清坐标轴。
    plt.close() # 关窗口
    gc.collect() 

    #Weekly
    tmp = ocapSum['QTY'].groupby([ocapSum['Week'],ocapSum['OOC_OR_OOS']]).sum()
    tmp = tmp.unstack()
    tmp.index = ["WW" + str(int(i)) for i in tmp.index]
    
    
    fig = plt.figure(figsize =(12,4))        
    ax1 = fig.add_subplot(1,2,1) 
    ax1 = tmp['OOC'].plot(kind='bar')
    ax1.set_xticklabels(tmp.index,rotation=90)
    ax1.set_title ('Weekly OOC COUNT')
    ax1.set_ylabel("Count")
    ax1.legend()
    ax1.xaxis.grid(True)
    ax1.yaxis.grid(True)
    
    ax2 = fig.add_subplot(1,2,2) 
    ax2 = tmp['OOS'].plot(kind='bar')
    ax2.set_xticklabels(tmp.index,rotation=90)
    ax2.set_title ('Weekly OOS COUNT')
    ax2.set_ylabel("Count")
    ax2.legend()
    ax2.xaxis.grid(True)
    ax2.yaxis.grid(True)
   
    #sht.pictures.add(fig, name='Weekly OCAP', update=True,
    #                 left=sht.range('A2').left, top=sht.range('A2').top)
    plt.savefig('z:\\_DailyCheck\\OptOvl_Others\\DailyOcap\\Weekly.jpg' ,dpi=100, bbox_inches='tight')
         

    #plt.show()
   
    plt.clf() # 清图。
    plt.cla() # 清坐标轴。
    plt.close() # 关窗口
    gc.collect() 



    
    enddate = datetime.datetime.now()
    startdate = enddate - datetime.timedelta(days=61)
    newindex=[datetime.datetime.strftime(x,'%Y-%m-%d') for x in list(pd.date_range(start=startdate, end=enddate))]
    ref_df = pd.DataFrame([newindex, [ i for i in range(61+1)]]).T
    ref_df.columns = ['Day','1']
    ref_df = ref_df.reset_index().set_index(['Day'])

    
    
    
    
    
    df =ocapSum.reset_index().set_index(['Day'])
    OOC = df[df['OOC_OR_OOS']=='OOC']
    OOS = df[df['OOC_OR_OOS']=='OOS']
    for layer in ['CT', 'METAL', 'NCL POST POLY', 'NCL PRE POLY', 'POLY', 'SDG', 'TM', 'VIA']:

        
        
        
        
        tmp = OOC[OOC['Group']==layer][-61:]
        tmp = pd.concat([tmp, ref_df], axis=1, join_axes=[ref_df.index]) 
        tmp = tmp.fillna(0)['QTY']
        
        fig = plt.figure(figsize =(12,10))
        ax = fig.add_subplot(2,1,1)
        ax = tmp.plot(kind='bar')
        ax.set_xticklabels( tmp.index,rotation=90)
        ax.set_title ('Daily OOC OCAP QTY: ' + layer)
        ax.legend()
        ax.xaxis.grid(True)
        ax.yaxis.grid(True)

               
   
        tmp = OOS[OOS['Group']==layer][-61:]
        tmp = pd.concat([tmp, ref_df], axis=1, join_axes=[ref_df.index]) 
        tmp = tmp.fillna(0)['QTY']
        
        ax1 = fig.add_subplot(2,1,2)
        ax1 = tmp.plot(kind='bar')
        ax1.set_xticklabels( tmp.index,rotation=90)
        ax1.set_title ('Daily OOS OCAP QTY: ' + layer)
        ax1.legend()
        ax1.xaxis.grid(True)
        ax1.yaxis.grid(True)
        fig.subplots_adjust(hspace=0.5)
        #sht.pictures.add(fig, name=('Daily OCAP ' + layer), update=True,
        #             left=sht.range('A2').left, top=sht.range('A2').top)
        plt.savefig('z:\\_DailyCheck\\OptOvl_Others\\DailyOcap\\Daily_' + layer + '.jpg' ,dpi=100, bbox_inches='tight')
         
 
        #plt.show() 
       
        plt.clf() # 清图。
        plt.cla() # 清坐标轴。
        plt.close() # 关窗口
        gc.collect()        


##########################################################################################################

##QC
        
    #Monthly
    tmp = ocapQcSum['QTY'].groupby([ocapQcSum['Month'],ocapSum['OOC_OR_OOS']]).sum()
    tmp = tmp.unstack()
    tmp1=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
    tmp.index = [tmp1[i] for i in range(tmp.shape[0])]
    
    
    fig = plt.figure(figsize =(12,4))        
    ax1 = fig.add_subplot(1,2,1) 
    ax1 = tmp['OOC'].plot(kind='bar')
    ax1.set_xticklabels(tmp.index,rotation=90)
    ax1.set_title ('Monthly QC OOC COUNT')
    ax1.set_ylabel("Count")
    ax1.legend()
    ax1.xaxis.grid(True)
    ax1.yaxis.grid(True)
    
    ax2 = fig.add_subplot(1,2,2) 
    ax2 = tmp['OOS'].plot(kind='bar')
    ax2.set_xticklabels(tmp.index,rotation=90)
    ax2.set_title ('Monthly QC OOS COUNT')
    ax2.set_ylabel("Count")
    ax2.legend()
    ax2.xaxis.grid(True)
    ax2.yaxis.grid(True)
   
    #sht.pictures.add(fig, name='Monthly QC OCAP', update=True,
    #                 left=sht.range('A2').left, top=sht.range('A2').top)
    plt.savefig('z:\\_DailyCheck\\OptOvl_Others\\DailyOcap\\MonthlyQC.jpg' ,dpi=100, bbox_inches='tight')
         

    #plt.show()
  
    plt.clf() # 清图。
    plt.cla() # 清坐标轴。
    plt.close() # 关窗口
    gc.collect()         


    #Weekly
    tmp = ocapQcSum['QTY'].groupby([ocapSum['Week'],ocapQcSum['OOC_OR_OOS']]).sum()
    tmp = tmp.unstack()
    tmp.index = ["WW" + str(int(i)) for i in tmp.index]
    
    
    fig = plt.figure(figsize =(12,4))        
    ax1 = fig.add_subplot(1,2,1) 
    ax1 = tmp['OOC'].plot(kind='bar')
    ax1.set_xticklabels(tmp.index,rotation=90)
    ax1.set_title ('Weekly QC OOC COUNT')
    ax1.set_ylabel("Count")
    ax1.legend()
    ax1.xaxis.grid(True)
    ax1.yaxis.grid(True)
    
    ax2 = fig.add_subplot(1,2,2) 
    ax2 = tmp['OOS'].plot(kind='bar')
    ax2.set_xticklabels(tmp.index,rotation=90)
    ax2.set_title ('Weekly QC OOS COUNT')
    ax2.set_ylabel("Count")
    ax2.legend()
    ax2.xaxis.grid(True)
    ax2.yaxis.grid(True)
   
    #sht.pictures.add(fig, name='Weekly QC OCAP', update=True,
    #                 left=sht.range('A2').left, top=sht.range('A2').top)
    plt.savefig('z:\\_DailyCheck\\OptOvl_Others\\DailyOcap\\WeeklyQC.jpg' ,dpi=100, bbox_inches='tight')
         


    #plt.show()
   
    plt.clf() # 清图。
    plt.cla() # 清坐标轴。
    plt.close() # 关窗口
    gc.collect() 


    #wb.save()
    #wb.close()
    






def  query_plot_errc():
    key,category,comment,dic_stage_layer,dic_layer_stage,dic_layer_type,dic_group_section, group,delta,databasepath,rawRwkMoveOcap,rawErrc = dict_list()
    
    wb = xw.Book(r'p:\RoutineWork\ScriptSaving.xlsx')    
    sht = wb.sheets["ERRC"]     
    
 
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)        


    rs = win32com.client.Dispatch(r'ADODB.Recordset') 
    sql  = " SELECT ERRC.Month, ERRC.Week, ERRC.Day, ERRC.Category, COUNT ( ERRC.Category ) as QTY  \
             FROM ERRC GROUP BY  ERRC.Month, ERRC.Week, ERRC.Day, ERRC.Category, ERRC.Category "

    rs.Open(sql, conn, 1, 3)    
    errcSum=[]    
    rs.MoveFirst()
    while True:
        if rs.EOF:
            break
        else:
            tmp = [rs.Fields(0).value,rs.Fields(1).value,rs.Fields(2).value,rs.Fields(3).value,rs.Fields(4).value]
            errcSum.append(tmp)
        rs.MoveNext()
    errcSum = pd.DataFrame(errcSum,columns=['Month','Week','Day','Category','QTY'])
    rs.close
    errcSum['Day'] =[ str(i.date()) for i in errcSum['Day'] ]

    conn.close

    
    
 



    #Monthly
    tmp = errcSum['QTY'].groupby([errcSum['Month']]).sum()
    tmp1=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
    tmp.index = [tmp1[i] for i in range(tmp.shape[0])]
    
    
    fig = plt.figure(figsize =(12,4))        
    ax1 = fig.add_subplot(1,1,1) 
    ax1 = tmp.plot(kind='bar')
    ax1.set_xticklabels(tmp.index,rotation=90)
    ax1.set_title ('Monthly ERRC COUNT')
    ax1.set_ylabel("Count")
    ax1.legend()
    ax1.xaxis.grid(False)
    ax1.yaxis.grid(True)
       
    sht.pictures.add(fig, name='Monthly ERRC', update=True,
                     left=sht.range('A2').left, top=sht.range('A2').top)

    #plt.show()
   
    plt.clf() # 清图。
    plt.cla() # 清坐标轴。
    plt.close() # 关窗口
    gc.collect() 

    #Weekly
    tmp = errcSum['QTY'].groupby([errcSum['Week']]).sum()
    tmp.index = ["WW" + str(int(i)) for i in tmp.index]
    
    
    fig = plt.figure(figsize =(12,4))        
    ax1 = fig.add_subplot(1,1,1) 
    ax1 = tmp.plot(kind='bar')
    ax1.set_xticklabels(tmp.index,rotation=90)
    ax1.set_title ('Weekly ERRC COUNT')
    ax1.set_ylabel("Count")
    ax1.legend()
    ax1.xaxis.grid(True)
    ax1.yaxis.grid(True)
    

   
    sht.pictures.add(fig, name='Weekly ERRC', update=True,
                     left=sht.range('A2').left, top=sht.range('A2').top)


    #plt.show()
    
    plt.clf() # 清图。
    plt.cla() # 清坐标轴。
    plt.close() # 关窗口
    gc.collect() 



 

    enddate = datetime.datetime.now()
    startdate = enddate - datetime.timedelta(days=61)
    newindex=[datetime.datetime.strftime(x,'%Y-%m-%d') for x in list(pd.date_range(start=startdate, end=enddate))]
    ref_df = pd.DataFrame([newindex, [ i for i in range(61+1)]]).T
    ref_df.columns = ['Day','1']
    ref_df = ref_df.reset_index().set_index(['Day'])


   
   
    for category in ['Alignment', 'AUTOFUNC', 'Dynamic', 'EAP', 'MA_Z', 'Offline Nikon','Scanner', 'Track', 'WfrQtyMismatch', 'Dose Error', 'Track Recipe', 'MFG', 'pending']:

        
        
        tmp = errcSum[ errcSum['Category']==category ] [-61:].reset_index().set_index(['Day'])
        tmp = pd.concat([tmp, ref_df], axis=1, join_axes=[ref_df.index])
        tmp = tmp.fillna(0)
        tmp = tmp['QTY']
        fig = plt.figure(figsize =(12,4))
        ax = fig.add_subplot(1,1,1)
        ax = tmp.plot(kind='bar')
        ax.set_xticklabels( tmp.index,rotation=90)
        ax.set_title ('Daily ERRC QTY: ' + category)
        #ax.legend()
        ax.xaxis.grid(True)
        ax.yaxis.grid(True)
    
        sht.pictures.add(fig, name=('Daily ERRC ' + category), update=True,
                         left=sht.range('A2').left, top=sht.range('A2').top)
     
        #plt.show()
        
        plt.clf() # 清图。
        plt.cla() # 清坐标轴。
        plt.close() # 关窗口
        gc.collect()         


##########################################################################################################



    wb.save()
    wb.close()
    



def run_xls_macro():
    key,category,comment,dic_stage_layer,dic_layer_stage,dic_layer_type,dic_group_section, group,delta,databasepath,rawRwkMoveOcap,rawErrc = dict_list()
    

    filename = r'Y:\ERRC_RWK_MOVE\RwkMoveOcapRaw.xlsm'

    xlApp = win32com.client.Dispatch('Excel.Application')

    xlApp.visible = 1 # 此行设置打开的Excel表格为可见状态；忽略则Excel表格默认不可见

    xlBook = xlApp.Workbooks.Open(filename)

    #strPara = xlBook.Name + '!main()'
    #xlApp.ExecuteExcel4Macro(strPara)
    
    xlApp.ExecuteExcel4Macro(xlBook.Name + "!ocap_rawdata()")
    xlApp.ExecuteExcel4Macro(xlBook.Name + "!rwk_rawdata()")

    xlApp.ExecuteExcel4Macro(xlBook.Name + "!move_rawdata()")

    
    
    xlBook.save
    xlBook.close

    #xlBook.Close(SaveChanges=True) # 关闭Excel，并保存更改 


















if __name__ == "__main__":

    #run_xls_macro()
    try:
           
        MOVEdate, RWKdate = get_db_latest_date1()
        
        rwk_new, move_new = get_latest_chart_data1(MOVEdate, RWKdate)
        
        update_db(rwk_new, move_new) 
        
        
        #ocap_new, rwk_new, move_new, errc_new = None,None,None,None
        
        #rwkStat=query_rwk() # return tuple -->#rwkMonthSum,rwkWeekSum,rwkMonthBreakdown,rwkWeekBreakdown,rwkDayBreakdown
        
        #moveStat= query_move() #moveMonthSum,moveWeekSum,moveMonthBreakdown,moveWeekBreakdown,moveDayBreakdown
        
        
        #plot_rwk(rwkStat,moveStat) #plot rwk data
        #rwkStat,moveStat = None,None
        #query_plot_ocap()
        #query_plot_errc()
        tmp = open(r'D:\HuangWeiScript\PyTaskCode\pythonlog.txt','a')
        tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___014-RwkMoveOcap Done\n")
        tmp.close()
    except:
        tmp = open(r'D:\HuangWeiScript\PyTaskCode\pythonlog.txt','a')
        tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___014-RwkMoveOcap Failed\n")
        tmp.close()        

