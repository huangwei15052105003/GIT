# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'GUI_ExposureRecipe.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!





from PyQt5.QtGui  import *
from PyQt5.Qt import *
from PyQt5.QtCore import *








import sys,os
from PyQt5 import QtCore, QtWidgets, QtGui
from PyQt5.QtWidgets import *
from PyQt5.QtCore import QStringListModel,QAbstractListModel,QModelIndex,QSize,Qt

import pandas as pd


class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(840, 480)
        self.tabWidget = QtWidgets.QTabWidget(Form)
        self.tabWidget.setGeometry(QtCore.QRect(10, 10, 820, 460))
        self.tabWidget.setMinimumSize(QtCore.QSize(80, 0))
        self.tabWidget.setTabPosition(QtWidgets.QTabWidget.South)
        self.tabWidget.setObjectName("tabWidget")
        self.tab = QtWidgets.QWidget()
        self.tab.setObjectName("tab")
        self.tabWidget.addTab(self.tab, "")
        self.tab_2 = QtWidgets.QWidget()
        self.tab_2.setObjectName("tab_2")
        self.label = QtWidgets.QLabel(self.tab_2)
        self.label.setGeometry(QtCore.QRect(20, 10, 80, 20))
        self.label.setMinimumSize(QtCore.QSize(80, 20))
        self.label.setObjectName("label")
        self.lineEdit = QtWidgets.QLineEdit(self.tab_2)
        self.lineEdit.setGeometry(QtCore.QRect(120, 10, 120, 20))
        self.lineEdit.setMinimumSize(QtCore.QSize(120, 20))
        self.lineEdit.setObjectName("lineEdit")
        self.lineEdit.setPlaceholderText("请输入产品名")
        self.label_2 = QtWidgets.QLabel(self.tab_2)
        self.label_2.setGeometry(QtCore.QRect(20, 40, 80, 20))
        self.label_2.setMinimumSize(QtCore.QSize(80, 20))
        self.label_2.setObjectName("label_2")
        self.radioButton = QtWidgets.QRadioButton(self.tab_2)
        self.radioButton.setGeometry(QtCore.QRect(120, 40, 120, 20))
        self.radioButton.setMinimumSize(QtCore.QSize(120, 20))
        self.radioButton.setObjectName("radioButton")
        self.radioButton_2 = QtWidgets.QRadioButton(self.tab_2)
        self.radioButton_2.setGeometry(QtCore.QRect(260, 40, 120, 20))
        self.radioButton_2.setMinimumSize(QtCore.QSize(120, 20))
        self.radioButton_2.setObjectName("radioButton_2")
        self.pushButton = QtWidgets.QPushButton(self.tab_2)
        self.pushButton.setGeometry(QtCore.QRect(70, 70, 180, 23))
        self.pushButton.setMinimumSize(QtCore.QSize(80, 20))
        self.pushButton.setObjectName("pushButton")
        self.tableWidget = QtWidgets.QTableWidget(self.tab_2)
        self.tableWidget.setGeometry(QtCore.QRect(30, 110, 760, 280))
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(0)
        self.tableWidget.setRowCount(0)
        self.pushButton_2 = QtWidgets.QPushButton(self.tab_2)
        self.pushButton_2.setGeometry(QtCore.QRect(700, 400, 81, 23))
        self.pushButton_2.setMinimumSize(QtCore.QSize(80, 20))
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_3 = QtWidgets.QPushButton(self.tab_2)
        self.pushButton_3.setGeometry(QtCore.QRect(330, 70, 180, 23))
        self.pushButton_3.setMinimumSize(QtCore.QSize(180, 20))
        self.pushButton_3.setObjectName("pushButton_3")
        self.tabWidget.addTab(self.tab_2, "")

        self.retranslateUi(Form)
        self.tabWidget.setCurrentIndex(1)

    # ==========================================
    #     self.radioButton.setChecked(True)
        self.pushButton_2.clicked.connect(Form.close)
        QtCore.QMetaObject.connectSlotsByName(Form)
        self.pushButton.clicked.connect(self.recipeCheck)
        self.pushButton_3.clicked.connect(self.saveResult)

    #==============================================

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), _translate("Form", "编辑"))
        self.label.setText(_translate("Form", "产品名称"))
        self.label_2.setText(_translate("Form", "程序类型"))
        self.radioButton.setText(_translate("Form", "新产品"))
        self.radioButton_2.setText(_translate("Form", "旧产品"))
        self.pushButton.setText(_translate("Form", "预对位及NA/Sigam比对"))
        self.pushButton_2.setText(_translate("Form", "退出"))
        self.pushButton_3.setText(_translate("Form", "保存比对结果"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), _translate("Form", "检查"))

    def recipeCheck(self):

        #确认文件是否存在fileExisting
        self.tableWidget.clearContents() #清空表格内容
        pathRecipe = 'p:/recipe/recipe/'
        pathXls = 'P:/_NewBiasTable/'
        part = (self.lineEdit.text()).strip()
        if len(part) == 0:
            self.box = QMessageBox(QMessageBox.Warning, '注意', '请在产品名称栏未输入产品名')
            self.box.showNormal()
            return
        flag1 = self.radioButton.isChecked() #True-->New File, False-->Old file
        flag2 = self.radioButton_2.isChecked() #True-->New File, False-->Old file
        if flag1 ^ flag2 == False:
            self.box = QMessageBox(QMessageBox.Warning, '注意', '请选择程序类型')
            self.box.showNormal()
            return

        if os.path.exists(pathRecipe + part)==False:
            self.box = QMessageBox(QMessageBox.Warning, '注意', '请保存ASML文本程序')
            self.box.showNormal()
            return
        # print(os.path.exists(pathXls + part + '_New.xls'))
        # print(os.path.exists(pathXls + part + '_Old.xls'))
        if flag1==True:
            name = pathXls + part + '_New.xls'
        else:
            name = pathXls + part + '_Old.xls'
        print(name)

        if os.path.exists(name) == False:
            self.box = QMessageBox(QMessageBox.Warning, '注意', '请确认_NewBiasTable目录中文件是否存在')
            self.box.showNormal()
            return
        #开始比较

        f = open(pathRecipe + part)
        df = [i.strip() for i in f if i.strip() != '']
        illumination = []
        mask = []
        f1 = False
        f2 = False
        #get pre-alin mode
        for index, i in enumerate(df):
            if 'Prealignment Method' in i:
                preAlign = i.split(':')[1].strip()
                # print('\npreAlign', preAlign, '\n')
            if '+=================+=================+=========+========+========+' in i:
                # print(index)
                f1 = True
                no = index
            if f1 == True and index > no and '+-----------------+-----------------+---------+--------+--------+' not in i:
                # print(i)
                illumination.append([i.split('|')[1].strip(), i.split('|')[3].strip(), i.split('|')[4].strip(),
                                     i.split('|')[5].strip()])

            if '+-----------------+-----------------+---------+--------+--------+' in i:
                f1 = False
                illumination = pd.DataFrame(illumination).drop_duplicates()
                illumination = illumination[illumination[0].str.len() > 1]  # ('illumination\n',illumination)

            if '+=================+=================+==========================+==============+' in i:
                f2 = True
            if f2 == True and 'SPM' not in i and '|' in i:
                # print(i)
                mask.append([i.split('|')[1].strip(), i.split('|')[3].strip()])
                reticle = pd.DataFrame(mask)
            if '+-----------------+-----------------+--------------------------+--------------+' in i:
                f2 = False


        bt = pd.read_excel(name, sheet_name='Sheet1', header=1, skiprows=0)


        bt1 = bt[['PP\nID', 'Inn', 'Out', 'LSA\nFIA']]
        bt1.columns = ['PPID', 'NA', 'INNER', 'OUTER']
        try:
            bt1 = bt1[bt1['NA'] != 'ID4'].fillna(0)  # all asml layers
        except:
            pass



        if name[-2:].upper() == '-L' and preAlign != 'METHOD_1':
            print('PreAlignment method is not "METHOD_1",please revise')

        bt1.columns = [0, 1, 2, 3]
        bt1[[1, 2, 3]] = bt1[[1, 2, 3]].astype(float)
        illumination[[1, 2, 3]] = illumination[[1, 2, 3]].astype(float)

        bt1[0] = [i.strip() for i in bt1[0]]

        data = pd.merge(illumination, bt1, how='left', on=0)

        f4 = []
        f1 = data['1_x'] == data['1_y']
        f2 = data['2_x'] == data['2_y']
        f3 = data['3_x'] == data['3_y']
        for i in range(len(f1)):
            f4.append(f1[i] and f2[i] and f3[i])
        data['Flag'] = f4
        #print('This is RECIPE Data\n',data)

        bt2 = bt[['PP\nID', 'Mask']]
        bt2.columns = [0, 1]
        bt2[0] = [i.strip() for i in bt2[0]]
        data1 = pd.merge(bt2, reticle, how='left', on=0)
        data1 = data1.dropna()

        data1['1_x'] = [i.strip() for i in data1['1_x']]

        data1['MaskFlag'] = data1['1_x'] == data1['1_y']
        data1.columns = [0, 'recipe', 'biasTable', 'MaskFlag']
        data1['NewPart'] = name[-7:-4]

        df = pd.merge(data, data1, on=0)






        df['PreAlign'] = preAlign
        df.columns = ['Layer', 'NA', 'Inner', 'Outer', 'BT_NA', 'BT_I', 'BT_O', 'Flag', 'recipe', 'biasTable',
                      'MaskFlag', 'NewPart', 'Pre_Align']
        # df.to_csv('P:/Recipe/NA_SIGMA/' + name + '.csv')

        # https: // www.cnblogs.com / ygzhaof / p / 9732703.html

        tmp = df.copy()

        tmp[['NA', 'Inner', 'Outer', 'BT_NA', 'BT_I', 'BT_O']] =\
            tmp[['NA', 'Inner', 'Outer', 'BT_NA', 'BT_I', 'BT_O']].astype('object')
        tmp1,tmp2=[],[]

        for i in range(tmp.shape[0]):

            tmp1.append(str(tmp.iloc[i, 1]) + '/' + str(tmp.iloc[i, 2]) + '/' + str(tmp.iloc[i, 3]))
            tmp2.append(str(tmp.iloc[i, 4]) + '/' + str(tmp.iloc[i, 5]) + '/' + str(tmp.iloc[i, 6]))


        tmp['Recipe'] = tmp1
        tmp['Ref']=tmp2
        print(tmp)
        # tmp = tmp[['Layer', 'Recipe' 'Ref', 'Flag', 'recipe', 'biasTable', 'MaskFlag',  'Pre_Align']]
        tmp = tmp.drop(columns=['NA','Inner','Outer','BT_NA','BT_I','BT_O'])
        print(tmp.columns)
        tmp = tmp [['Layer','Recipe', 'Ref', 'Flag', 'recipe', 'biasTable', 'MaskFlag','Pre_Align']]




        self.tableWidget.setColumnCount(8)
        self.tableWidget.setRowCount(df.shape[0])
        self.tableWidget.setHorizontalHeaderLabels(['Layer','Recipe','Ref','Flag','Mask','Ref1','Flag1','Pre_Align'])
        self.tableWidget.horizontalHeader().setStyleSheet("background-color: yellow");
        # self.table.setEditTriggers(QTableWidget.NoEditTriggers)#单元格不可编辑
        # self.table.setSelectionBehavior(QTableWidget.SelectRows)  #选中列还是行，这里设置选中行
        # self.table.setSelectionMode(QTableWidget.SingleSelection) #只能选中一行或者一列
        # self.table.horizontalHeader().setStretchLastSection(True)  #列宽度占满表格(最后一个列拉伸处理沾满表格)
        self.tableWidget.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch);#所有列自适应表格宽度
        self.tableWidget.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)


        for i in range(df.shape[0]):
            for j in range(8):
                newItem = QTableWidgetItem(str(tmp.iloc[i,j]))
                newItem.setTextAlignment(Qt.AlignCenter)
                if i%2 == 1:
                    newItem.setBackground(QColor('Lime'))


                self.tableWidget.setItem(i,j,newItem)


        # self.tableWidget.resizeColumnsToContents()
        # self.tableWidget.resizeRowsToContents()
        self.tableWidget.setColumnWidth(0, 40)  # 设置j列的宽度
        self.tableWidget.setColumnWidth(3, 50)  # 设置j列的宽度
        self.tableWidget.setColumnWidth(6, 50)  # 设置j列的宽度
        # self.tableWidget.setRowHeight(0, 30)  # 设置i行的高度
        # self.tableWidget.setStyleSheet('alternate-background-color:)

        return df,part

    #
    #
    def saveResult(self):

        df,part = self.recipeCheck()
        self.tableWidget.clearContents()
        print(part)
        df.to_csv('P:/Recipe/NA_SIGMA/' + part + '.csv')
        #df.to_csv('c:/temp/000.csv')
        self.box = QMessageBox(QMessageBox.Warning, ' ', '结果已保存')
        self.box.showNormal()
















if __name__ == "__main__":
     app = QApplication(sys.argv)
     form = QWidget()
     w = Ui_Form()
     w.setupUi(form)
     form.show()
     sys.exit(app.exec_())