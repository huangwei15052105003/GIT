# -*- coding: utf-8 -*-
"""
# encoding = 'GB2312' ,encoding='GBK' 
Created on Tue Apr 10 13:06:05 2018

@author: HUANGWEI45
"""
def dic_set_1():
    dic_stage_layer={'BAS-PH': 'BA','BN-PH': 'BN','BRN-PH': 'BN','BRP-PH': 'BP',  'CELL-PH': 'CI','CGT-PH': 'GC','CLD-PH': 'CL','CSD-PH': 'CS','CT-PH': 'W1',  'CTN-PH': 'NP','CTP-PH': 'PP','CVT-PH': 'VC','CWL-PH': 'CC','DG-PH': 'HV',  'DNW-PH': 'DN','DPE-PH': 'PE','DPW-PH': 'DP','DVTN-PH': 'ND','DVTP-PH': 'PD',  'ESD-PH': 'SE','FPB-PH': 'FB','FPT-PH': 'FT','FU-PH': 'FU','HBP-PH': 'XP',  'HNL-PH': 'HA','HPL-PH': 'HB','HR-PH': 'HR','HVEB-PH': 'WE','HVNW-PH': 'NX',  'HVP-PH': 'HP',  'HVPW-PH': 'PX',  'HVT-PH': 'HN',  'IMM-PH': 'IM',  'IRS-PH': 'IR',  'JFP-PH': 'JP',  'LLD-PH': 'LD',  'LNL-PH': 'LA',  'LNS-PH': 'NS',  'LPL-PH': 'LB',
      'LPS-PH': 'PS',  'LTC-PH': 'TC',  'LTN-PH': 'WN',  'LTP-PH': 'WP',  'LVNW-PH': 'NV',  'LVPW-PH': 'PV',  'LVT-PH': 'LV',  'LVTN-PH': 'LN',  'LVTP-PH': 'LP',  'M1-PH': 'A1',  'M2-PH': 'A2',  'M3-PH': 'A3',  'M4-PH': 'A4',  'M5-PH': 'A5',  'M6-PH': 'A6',  'M7-PH': 'A7',  'MAL-PH': 'MA',  'MCW-PH': 'MC',  'MGE-PH': 'GE',  'MGF-PH': 'GF',  'MI2-PH': 'MT',  'MIM-PH': 'CT',  'MP1-PH': 'T1',  'MVA-PH': 'MV',  'MVTN-PH': 'MN',  'MVTP-PH': 'MP',  'NB-PH': 'NB',  'NCA-PH': 'CA',
      'NCL-PH': 'RA',  'NED-PH': 'EN',  'NFI-PH': 'NF',  'NGD-PH': 'NG',  'NGP-PH': 'GN',  'NLDD-PH': 'NL',  'NLJ-PH': 'LJ',  'NRO-PH': 'RO',  'NSD-PH': 'SN',  'NSF-PH': 'NM',  'NSK-PH': 'NK',  'NW-PH': 'TB',  'OE-PH': 'OE',  'ONO-PH': 'ON',  'OV-PH': 'OV',  'PAD-PH': 'CP',  'PAF-PH': 'CF',  'PAJ-PH': 'PJ',  'PAN-PH': 'PN',  'PARC-PH': 'P2',  'PBD-PH': 'PB',  'PCL-PH': 'RB',  'PED-PH': 'EP',  'PFI-PH': 'PF',  'PGD-PH': 'PG',  'PI-PH': 'PI',  'PLDD-PH': 'PL',  'PLK-PH': 'LK',  'PO0-PH': 'P0',  'PO1-PH': 'GT',  'PO2-PH': 'PC',  'PPW-PH': 'PW',
      'PRO-PH': 'PR',  'PRS-PH': 'RS',  'PSD-PH': 'SP',  'PSF-PH': 'PM',  'PSK-PH': 'PK',  'PVT-PH': 'VT',  'PW-PH': 'PT',  'RN-PH': 'RN',  'RTR-PH': 'RT',  'SAB-PH': 'SI',  'SAS-PH': 'SS',  'SCW-PH': 'SW',  'SDG-PH': 'TO2',  'TG-PH': 'TG',  'TM-PH': 'TT',  'TOR-PH': 'RE',  'TRE-PH': 'TR',  'TTR-PH': 'TR',  'TUN-PH': 'TU',  'UHN-PH': 'UA',  'UHP-PH': 'UB',  'UNW-PH': 'UN',  'UPW-PH': 'UP',  'UPZ-PH': 'UZ',  'VIA1-PH': 'W2',  'VIA2-PH': 'W3',  'VIA3-PH': 'W4',  'VIA4-PH': 'W5',  'VIA5-PH': 'W6',  'VIA6-PH': 'W7',  'VIAT-PH': 'WT',  'VSD-PH': 'SD',
      'VTB-PH': 'BC',  'VTHN-PH': 'NH',  'VTHP-PH': 'PH',  'VTLP-PH': 'PA',  'VTN-PH': 'VN',  'ZEN-PH': 'ZP',  'ZERO-PH': 'ZO'}
    
    dic_layer_stage={'A1': 'M1-PH',  'A2': 'M2-PH',
      'A3': 'M3-PH',  'A4': 'M4-PH',  'A5': 'M5-PH',  'A6': 'M6-PH',  'A7': 'M7-PH',  'AT': 'TM-PH',  'BA': 'BAS-PH',  'BC': 'VTB-PH',
      'BN': 'BRN-PH',  'BP': 'BRP-PH',  'CA': 'NCA-PH',  'CC': 'CWL-PH',  'CF': 'PAF-PH',  'CI': 'CELL-PH',  'CL': 'CLD-PH',  'CP': 'PAD-PH',  'CS': 'CSD-PH',  'CT': 'MIM-PH',  'DN': 'DNW-PH',  'DP': 'DPW-PH',  'EN': 'NED-PH',  'EP': 'PED-PH',  'FB': 'FPB-PH',  'FT': 'FPT-PH',  'FU': 'FU-PH',  'GC': 'CGT-PH',  'GE': 'MGE-PH',  'GF': 'MGF-PH',  'GN': 'NGP-PH',  'GT': 'PO1-PH',  'HA': 'HNL-PH',  'HB': 'HPL-PH',  'HN': 'HVT-PH',  'HP': 'HVP-PH',  'HR': 'HR-PH',  'HV': 'DG-PH',  'IM': 'IMM-PH',  'IR': 'IRS-PH',  'JP': 'JFP-PH',  'LA': 'LNL-PH',
      'LB': 'LPL-PH',  'LD': 'LLD-PH',  'LJ': 'NLJ-PH',  'LK': 'PLK-PH',  'LN': 'LVTN-PH',  'LP': 'LVTP-PH',  'LV': 'LVT-PH',  'MA': 'MAL-PH',  'MC': 'MCW-PH',  'MN': 'MVTN-PH',  'MP': 'MVTP-PH',  'MT': 'MI2-PH',  'MV': 'MVA-PH',  'NB': 'NB-PH',  'ND': 'DVTN-PH',  'NF': 'NFI-PH',  'NG': 'NGD-PH',  'NH': 'VTHN-PH',  'NK': 'NSK-PH',  'NL': 'NLDD-PH',  'NM': 'NSF-PH',  'NP': 'CTN-PH',  'NS': 'LNS-PH',  'NV': 'LVNW-PH',  'NX': 'HVNW-PH',  'OE': 'OE-PH',  'ON': 'ONO-PH',  'OV': 'OV-PH',  'P0': 'PO0-PH',  'P2': 'PARC-PH',  'PA': 'VTLP-PH',  'PB': 'PBD-PH',
      'PC': 'PO2-PH',  'PD': 'DVTP-PH',  'PE': 'DPE-PH',  'PF': 'PFI-PH',  'PG': 'PGD-PH',  'PH': 'VTHP-PH',  'PI': 'PI-PH',  'PJ': 'PAJ-PH',  'PK': 'PSK-PH',  'PL': 'PLDD-PH',  'PM': 'PSF-PH',  'PN': 'PAN-PH',  'PP': 'CTP-PH',  'PR': 'PRO-PH',  'PS': 'LPS-PH',  'PT': 'PW-PH',  'PV': 'LVPW-PH',  'PW': 'PPW-PH',  'PX': 'HVPW-PH',  'RA': 'NCL-PH',  'RB': 'PCL-PH',  'RE': 'TOR-PH',  'RN': 'RN-PH',  'RO': 'NRO-PH',  'RS': 'PRS-PH',  'RT': 'RTR-PH',  'SD': 'VSD-PH',  'SE': 'ESD-PH',  'SI': 'SAB-PH',  'SN': 'NSD-PH',  'SP': 'PSD-PH',  'SS': 'SAS-PH',
      'SW': 'SCW-PH',  'T1': 'MP1-PH',  'TB': 'NW-PH',  'TC': 'LTC-PH',  'TG': 'TG-PH',  'TO': 'SDG-PH',  'TO2': 'SDG-PH',  'TR': 'TTR-PH',  'TT': 'TM-PH',  'TU': 'TUN-PH',  'UA': 'UHN-PH',  'UB': 'UHP-PH',  'UN': 'UNW-PH',  'UP': 'UPW-PH',  'UZ': 'UPZ-PH',  'VC': 'CVT-PH',  'VN': 'VTN-PH',  'VT': 'PVT-PH',  'W1': 'CT-PH',  'W2': 'VIA1-PH',  'W3': 'VIA2-PH',  'W4': 'VIA3-PH',  'W5': 'VIA4-PH',  'W6': 'VIA5-PH',
      'W7': 'VIA6-PH',  'WE': 'HVEB-PH',  'WN': 'LTN-PH',  'WP': 'LTP-PH',  'WT': 'VIAT-PH',  'XP': 'HBP-PH',  'ZO': 'ZERO-PH',  'ZP': 'ZEN-PH'}
    
    dic_layer_type ={'A1': 'METAL',  'A2': 'METAL',  'A3': 'METAL',  'A4': 'METAL',
      'A5': 'METAL',  'A6': 'METAL',  'A7': 'METAL',  'AT': 'TM',  'BA': 'NCL PRE POLY',  'BC': 'NCL PRE POLY',  'BN': 'NCL PRE POLY',  'BP': 'NCL PRE POLY',
      'CA': 'NCL PRE POLY',  'CC': 'NCL POST POLY',  'CF': 'PAD',  'CI': 'NCL POST POLY',  'CL': 'NCL POST POLY',  'CP': 'PAD',  'CS': 'NCL POST POLY',  'CT': 'NCL POST POLY',  'DN': 'NCL PRE POLY',  'DP': 'NCL PRE POLY',  'EN': 'NCL POST POLY',  'EP': 'NCL POST POLY',  'FB': 'NCL PRE POLY',  'FT': 'NCL PRE POLY',  'FU': 'PAD',  'GC': 'POLY',
      'GE': 'NCL PRE POLY',  'GF': 'NCL PRE POLY',  'GN': 'NCL PRE POLY',  'GT': 'POLY',  'HA': 'NCL POST POLY',  'HB': 'NCL POST POLY',  'HN': 'NCL PRE POLY',  'HP': 'NCL PRE POLY',  'HR': 'NCL POST POLY',  'HV': 'NCL PRE POLY',  'IM': 'NCL POST POLY',  'IR': 'NCL PRE POLY',  'JP': 'NCL PRE POLY',  'LA': 'NCL POST POLY',  'LB': 'NCL POST POLY',  'LD': 'NCL POST POLY',
      'LJ': 'NCL PRE POLY',  'LK': 'NCL PRE POLY',  'LN': 'NCL PRE POLY',  'LP': 'NCL PRE POLY',  'LV': 'NCL PRE POLY',  'MA': 'NCL PRE POLY',  'MC': 'NCL PRE POLY',  'MN': 'NCL PRE POLY',  'MP': 'NCL PRE POLY',  'MT': 'NCL PRE POLY',  'MV': 'NCL PRE POLY',  'NB': 'NCL PRE POLY',  'ND': 'NCL PRE POLY',  'NF': 'NCL PRE POLY',  'NG': 'NCL PRE POLY',  'NH': 'NCL PRE POLY',
      'NK': 'NCL PRE POLY',  'NL': 'NCL POST POLY',  'NM': 'NCL PRE POLY',  'NP': 'NCL PRE POLY',  'NS': 'NCL PRE POLY',  'NV': 'NCL PRE POLY',  'NX': 'NCL PRE POLY',  'OE': 'NCL POST POLY',  'ON': 'NCL PRE POLY',  'OV': 'NCL POST POLY',  'P0': 'POLY',  'P2': 'PAD',  'PA': 'NCL PRE POLY',  'PB': 'NCL PRE POLY',  'PC': 'POLY',  'PD': 'NCL PRE POLY',
      'PE': 'NCL POST POLY',  'PF': 'NCL PRE POLY',  'PG': 'NCL PRE POLY',  'PH': 'NCL PRE POLY',  'PI': 'PAD',  'PJ': 'NCL PRE POLY',  'PK': 'NCL PRE POLY',  'PL': 'NCL POST POLY',  'PM': 'NCL PRE POLY',  'PN': 'NCL PRE POLY',  'PP': 'NCL POST POLY',  'PR': 'NCL POST POLY',  'PS': 'NCL PRE POLY',  'PT': 'NCL PRE POLY',  'PV': 'NCL PRE POLY',  'PW': 'NCL PRE POLY',  'PX': 'NCL PRE POLY',
      'RA': 'NCL PRE POLY',  'RB': 'NCL PRE POLY',  'RE': 'NCL PRE POLY',  'RN': 'NCL PRE POLY',  'RO': 'NCL POST POLY',  'RS': 'NCL PRE POLY',  'RT': 'NCL PRE POLY',  'SD': 'NCL PRE POLY',  'SE': 'NCL PRE POLY',  'SI': 'NCL POST POLY',  'SN': 'NCL POST POLY',  'SP': 'NCL POST POLY',  'SS': 'NCL POST POLY',  'SW': 'NCL PRE POLY',  'T1': 'NCL PRE POLY',  'TB': 'NCL PRE POLY',  'TC': 'NCL PRE POLY',
      'TG': 'NCL PRE POLY',  'TO': 'SDG',  'TO2': 'SDG',  'TR': 'NCL PRE POLY',  'TT': 'TM',  'TU': 'NCL PRE POLY',  'UA': 'NCL POST POLY',  'UB': 'NCL POST POLY',  'UN': 'NCL PRE POLY',  'UP': 'NCL PRE POLY',  'UZ': 'NCL PRE POLY',  'VC': 'NCL PRE POLY',  'VN': 'NCL PRE POLY',  'VT': 'NCL PRE POLY',  'W1': 'CT',  'W2': 'VIA',  'W3': 'VIA',
      'W4': 'VIA',  'W5': 'VIA',  'W6': 'VIA',  'W7': 'VIA',  'WE': 'NCL PRE POLY',  'WN': 'NCL PRE POLY',  'WP': 'NCL PRE POLY',  'WT': 'VIA',
      'XP': 'NCL POST POLY',  'ZO': 'NCL PRE POLY',  'ZP': 'NCL POST POLY'}
    
    category = ('TM', 'POLY', 'CT', 'VIA', 'NCL POST POLY', 'NCL PRE POLY', 'METAL','SDG')
    return dic_stage_layer, dic_layer_stage,dic_layer_type,category





import matplotlib.pyplot as plt
import pandas as pd
import os




import win32com.client
import pytz
import datetime
import gc











#import html5lib




def get_path(FileDir):
    dic_stage_layer, dic_layer_stage, dic_layer_type,category = dic_set_1()
#list batchreport filename in specified directory    
    filenamelist=[]
    for root, dirs, files in os.walk(FileDir, False):  #root:所有目录名-->字符串 #dirs: root下的子目录名-->列表 #files：root下的文件名-->列表 # name.endswith(ext)-->文件名筛选 
        for names in files:
            if '.TXT' in names:
                filenamelist.append( root  + '\\' + names) 
    filenamelist.sort(reverse = False)
    return (filenamelist)



def html_update_single(filename):
    dic_stage_layer, dic_layer_stage, dic_layer_type,category = dic_set_1()
    print('Updating Single File===============\n')
    new =pd.read_html(filename,encoding='GBK',header = 0)
    new = pd.DataFrame(new[0])
    comment = list(new['Comment'] )
    for i,value in enumerate(comment):
        if len(value) >12:
            comment[i] = "OptValueOOS"
        else:
            comment[i] = "FeedbackFailure"
    new['Comment'] = comment
    #new = new.fillna('')
    new.columns = ['Tech', 'Part', 'Layer', 'Tool', 'PreTool', 'Time', 'Comment']
    
    
    databasepath = r'Y:\New_Flow\NewFlow.mdb'    
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)  
    rs = win32com.client.Dispatch(r'ADODB.Recordset')

   
    sql = " SELECT FeedbackFailure.TimeIndex FROM FeedbackFailure ORDER BY FeedbackFailure.TimeIndex DESC;"
    rs.Open(sql, conn, 1, 3)    
    rs.MoveFirst()  #光标移到首条记录
    old = str ( rs.Fields.Item(0).Value )[0:-6]
    old = datetime.datetime.strptime( old , '%Y-%m-%d %H:%M:%S')
    rs.close
    
    new= new.fillna(0)
    new['Time']= pd.to_datetime(new['Time'])

    new = new [ new['Time'] > old]    
    
    
    
    tz = pytz.timezone("GMT")
    rs.Open("FeedbackFailure", conn, 1, 3)
    print(filename, '-----', new.shape[0])

    for i in range(new.shape[0]):
        rs.AddNew()        
        tmp = new.iloc[i,5]
        rs.Fields.Item(7).value = str(tmp.date())
        tmp = datetime.datetime(tmp.year, tmp.month, tmp.day, tmp.hour, tmp.minute, tmp.second, tzinfo=tz)
        rs.Fields.Item(0).value = tmp
        rs.Fields.Item(1).value = new.iloc[i,0]            
        rs.Fields.Item(2).value = new.iloc[i,1]         
        rs.Fields.Item(3).value = new.iloc[i,2] 
        rs.Fields.Item(4).value = new.iloc[i,3]            
        rs.Fields.Item(5).value = new.iloc[i,4]
        rs.Fields.Item(6).value = new.iloc[i,6]    
        rs.Fields.Item(8).value = dic_layer_type [ new.iloc[i,2][0:2] ]
        rs.Update()
    conn.close


def html_update_all(FileDir = r'Z:\_DailyCheck\outlook\FeedbackFailure'):  
    dic_stage_layer, dic_layer_stage, dic_layer_type,category = dic_set_1()
    filenamelist = get_path(FileDir)
    for filename in filenamelist:
        html_update_single(filename)












    
def ready_data():
    dic_stage_layer, dic_layer_stage, dic_layer_type,category = dic_set_1()
    
    databasepath = r'Y:\New_Flow\NewFlow.mdb'    
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)  
    rs = win32com.client.Dispatch(r'ADODB.Recordset')

   
    sql =  "SELECT Date_, Type, Count(Type) AS QTY FROM FeedbackFailure  WHERE (Comment ='FeedbackFailure')  GROUP BY Date_, Type;"
    rs.Open(sql, conn, 1, 3)    
    rs.MoveFirst()  #光标移到首条记录
    
    
    tmp1=[]
    tmp2 =[]
    tmp3 = []
    rs.MoveFirst()
    while True:
        if rs.EOF:
            break
        else:
            
            tmp1.append ( rs.Fields[0].Value)
            tmp2.append ( rs.Fields[1].Value )
            tmp3.append (  rs.Fields[2].Value )
                 
            rs.MoveNext()
    rs.close
    conn.close
    
    df = pd.DataFrame([tmp1,tmp2,tmp3]).T
    df = df.fillna(0)
    

    return df

def plot_data():
    dic_stage_layer, dic_layer_stage, dic_layer_type,category = dic_set_1()
    table = ready_data()
    table[0] = [datetime.datetime.strftime(x,'%Y-%m-%d') for x in list(table[0])]
    table.columns = ['Day','Layer','QTY']
    table = table.reset_index().set_index(['Day'])

    #wb = xw.Book(r'P:\RoutineWork\ScriptSaving.xlsx')
    #sht = wb.sheets['FeedbackFailure']
    #sht.cells.clear_contents()
    #sht.range('A1').value = table



    enddate = datetime.datetime.now()
    startdate =datetime.datetime.strptime('2018-4-21 00:00:00', '%Y-%m-%d %H:%M:%S')
    newindex=[datetime.datetime.strftime(x,'%Y-%m-%d') for x in list(pd.date_range(start=startdate, end=enddate))]
    ref_df = pd.DataFrame([newindex, [ i for i in range(len(newindex))]]).T
    ref_df.columns = ['Day','Dummy']
    ref_df = ref_df.reset_index().set_index(['Day'])
   

       
   
    for layer in ['NCL POST POLY', 'NCL PRE POLY', 'POLY', 'SDG', 'TM', 'VIA', 'CT', 'METAL']:

        
        
        tmp = table[ table["Layer"] == layer ] .reset_index().set_index(['Day'])['QTY']
        tmp = pd.concat([tmp, ref_df], axis=1, join_axes=[ref_df.index])
        tmp = tmp.fillna(0)
        tmp = tmp['QTY']
        fig = plt.figure(figsize =(12,4))
        ax = fig.add_subplot(1,1,1)
        ax = tmp.plot(kind='bar')
        ax.set_xticklabels( tmp.index,rotation=90)
        ax.set_title ('Daily Feedback Failure: ' + layer)
        #ax.legend()
        ax.xaxis.grid(True)
        ax.yaxis.grid(True)
        plt.savefig('Z:\\_DailyCheck\\OptOvl_Others\\FeedbackFailure\\' + layer + '.jpg'  ,dpi=100, bbox_inches='tight')    
    #plt.show() 
        #sht.pictures.add(fig, name='Daily FeedbackFailure:' + layer, update=True,
        #             left=sht.range('B5').left, top=sht.range('d5').top)
     
        plt.clf() # 清图。
        plt.cla() # 清坐标轴。
        plt.close() # 关窗口
        gc.collect()         





    #wb.save()
    #wb.close()






#############################################################
# disopose mail of  #产品流程新建激活通知#

def newflow():
    dic_stage_layer, dic_layer_stage, dic_layer_type,category = dic_set_1()
    
    filenamelist = get_path( FileDir = r'Z:\_DailyCheck\outlook\NewFlow')
    result = []
    for file in filenamelist:
        
        new =pd.read_html(file,encoding='GBK',header = 0)
        new = pd.DataFrame(new[0])
        result.append (  [ new.iloc[1,0],new.iloc[1,1],new.iloc[2,1]] )
    new = pd.DataFrame(result,columns = ['Part','Tech','Owner'])
    
    
    print("new product count__" +  str(new.shape[0]))
    
    
    databasepath = r'Y:\New_Flow\NewFlow.mdb'    
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)  
    rs = win32com.client.Dispatch(r'ADODB.Recordset')

    sql = " SELECT Part FROM  NewFlowActivated  "
    rs.Open(sql, conn, 1, 3)
    
    rs.MoveFirst()  #光标移到首条记录
    old = []
    
    while True:
        if rs.EOF:
            break
        else:
            old.append(rs.Fields(0).Value)
            rs.MoveNext()
    rs.close
        
    print('\n Total Part Number: ' + str(len(old)) + '\n')    
        
    rs.Open("NewFlowActivated", conn, 1, 3)
    
    for i in range(new.shape[0]):
        
        if  ( new.iloc[i,0] not in old ):
            
            print (new.iloc[i,0],new.iloc[i,1],new.iloc[i,2],'\n===Inserted===\n')
            rs.AddNew()
            rs.Fields.Item(0).Value =  new.iloc[i,0]
            rs.Fields.Item(1).Value =  new.iloc[i,1]            
            rs.Fields.Item(2).Value =  new.iloc[i,2]        
            rs.Update()  #更新    
    
    rs.close 
   
    conn.Close()
    
    print('\n New Activeted Part Are Updated \n')
    
    
    
def newflow_from_mfg():
    
    dic_stage_layer, dic_layer_stage, dic_layer_type,category = dic_set_1()
    

    new =pd.read_excel(r'D:\HuangWeiScript\PyTaskCode\R2R_New_Part.xlsm',sheet_name = 'LiYanTable')        
    
    new.columns = ['Tech','Part','Block_X','Block_Y']
    
    
    print("LiYanTable DataBase Product Count__" +  str(new.shape[0]))
    
    new =list( new['Part'] )
   
    
    ##########################################################################
    
    
    
    mfg =pd.read_excel(r'D:\HuangWeiScript\PyTaskCode\R2R_New_Part.xlsm',sheet_name = 'PPID',header=None)        
    
    mfg = mfg[9].str.split('_',expand = True).dropna()[1].str.split('.',expand=True)[0]
    mfg = list(mfg)
    mfg = [i for i in mfg if (len(i)>7 and i[2]  in ['0','1','2','3','4','5','6','7','8','9']  ) ]
  
    #################################################################################3
    
    databasepath = r'Y:\New_Flow\NewFlow.mdb'    
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)  
    rs = win32com.client.Dispatch(r'ADODB.Recordset')

    sql = " SELECT distinct Part FROM  NewFlowActivated  "
    rs.Open(sql, conn, 1, 3)
    
    rs.MoveFirst()  #光标移到首条记录
    old = []
    
    while True:
        if rs.EOF:
            break
        else:
            old.append(rs.Fields(0).Value)
            rs.MoveNext()
    rs.close
        
    print('\n Total Part Number: ' + str(len(old)) + '\n')  
    
    old = [i.split('.')[0] for i in old if i is not None ]
    
   ############################################################################## 
    
    tmp =list(set(mfg)-set(old))
    tmp= [ i for i in tmp if not (i[0:2] =='F2' or i[8:10] =='-T' or i[8:11]=='-RD')   ]
    
    
    
    
    
    
    if len(tmp) > 0:
        
        rs.Open("NewFlowActivated", conn, 1, 3)
        
        for i in tmp :
            
            rs.AddNew()
            rs.Fields.Item(0).Value =  i
                   
            rs.Update()  #更新    
        
        rs.close 
   
    conn.Close()
    
   
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
  
    
def get_flow(part_name):
    print(part_name)
    dic_stage_layer, dic_layer_stage, dic_layer_type,category = dic_set_1()
    
    filename = r'Y:\New_Flow\FlowExtract.xlsm'

    xlApp = win32com.client.Dispatch('Excel.Application')
    xlApp.visible = 1 # 此行设置打开的Excel表格为可见状态；忽略则Excel表格默认不可见
    xlBook = xlApp.Workbooks.Open(filename)  
    xlBook.sheets("Flow").Range("A1").value = part_name
    strPara = xlBook.Name + '!Flow()'
    xlApp.ExecuteExcel4Macro(strPara)
    
    flow = []
    for i in range(1, xlBook.sheets('Flow').usedrange.rows.count+1,1):
        flow.append( [xlBook.sheets('Flow').cells(i,j).value for j in range( 1,8,1)])
    xlBook.Close(SaveChanges = False) 
    return flow 
     





        
     
 





def flowlayer():
    dic_stage_layer, dic_layer_stage, dic_layer_type,category = dic_set_1()
    databasepath = r'Y:\New_Flow\NewFlow.mdb'    
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)  
    res = win32com.client.Dispatch(r'ADODB.Recordset')

    sql = " SELECT Part FROM  NewFlowActivated  where FlowFlag = False "
    #sql = " SELECT Part FROM  NewFlowActivated   "    
    
    res.Open(sql, conn, 1, 3)
    
    res.MoveFirst()  #光标移到首条记录
    partlist = []
    
    while True:
        if res.EOF:
            break
        else:
            partlist.append(res.Fields(0).Value)
            res.MoveNext()
    res.close
        
    sql = " SELECT  distinct Part FROM FlowStage "
    res.Open(sql, conn, 1, 3)
    res.movefirst
    old = []
    while True:
        if res.EOF:
            break
        else:
            old.append(res.Fields(0).Value)
            res.movenext
    res.close
    

    res.Open( 'FlowStage',conn,1,3)
    
    
    partlist = (set(partlist)-set(old))
        
    
    count = len(partlist)
    
    for part_name in partlist:
        
        count = count - 1
        print(count)
        flow =  get_flow(part_name)
        
        if len(flow) > 0:

            for tmp in flow:
                print(tmp)
                
                res.AddNew()
                res.fields.item(1).value = part_name
                for i in range(0,7,1):
                    if tmp[i] != None:
                        res.fields.item(i+2).value = tmp[i]
           
                res.update
                #res.fields.item(2).value = tmp[0]
                #res.fields.item(3).value = tmp[1]
                #res.fields.item(4).value = tmp[2]
                #res.fields.item(5).value = tmp[3]            
                #res.fields.item(6).value = tmp[4]            
                #res.fields.item(7).value = tmp[5] 
                #res.fields.item(8).value = tmp[6]
       
                #res.update
                


    res.close
    conn.close




def delete_empty_part():


    databasepath = r'Y:\New_Flow\NewFlow.mdb'    
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)  
    res = win32com.client.Dispatch(r'ADODB.Recordset')

    sql =  "  SELECT Part FROM FlowStage WHERE PartVer ='' or PartVer is NULL "
    
    res.Open(sql, conn, 1, 3)
    emptypart = []
    try:
        res.MoveFirst()  #光标移到首条记录
        
        
        while True:
            if res.EOF:
                break
            else:
                emptypart.append(res.Fields(0).Value)
                res.MoveNext()
    except:
        pass
    #res.close
    
    if len(emptypart) > 0:
        for part in emptypart:
            sql = "Delete * from FlowStage where Part = '" + part + "'"
            print(sql)
            conn.execute(sql)
    
    conn.close
    





























       
if __name__ == "__main__": 
    
    try:
        html_update_all(FileDir = r'Z:\_DailyCheck\outlook\FeedbackFailure')    
        plot_data()
        delete_empty_part()
        newflow()
        newflow_from_mfg()
        flowlayer()
        tmp = open(r'D:\HuangWeiScript\PyTaskCode\pythonlog.txt','a')
        tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___016-Flow Done\n")
        tmp.close()
    except:
        tmp = open(r'D:\HuangWeiScript\PyTaskCode\pythonlog.txt','a')
        tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___016-Flow Failed\n")
        tmp.close()        
    
    #part_name = 'XI4256PA.01'    

   