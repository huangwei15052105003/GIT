# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""




import pandas as pd
import win32com.client
from sklearn.linear_model import LinearRegression
import numpy as np
import os
import shutil
import datetime






def single_ega_file():
    
    databasepath = 'Y:/NikonEgaLog/NikonEgaLog.mdb'
    rs_name = 'NikonEga'    
    conn, rs = connect_db(databasepath,rs_name )

    filenamelist = get_path(FileDir='P:\\EgaLog\\')
    
    for k,path in enumerate(filenamelist[0:]):
        flag = True
        print(k,len(filenamelist),path,flag)
        
       
  
  
    
    
    
        tmp = []
        
        f= open(path)    
        for i in f:
            tmp.append(i.strip().split(':='))
        f.close()
        
        try:
            df = pd.DataFrame(tmp)
       
            Measure = df[ df[0].str.contains( "MEAS_DATA" )]
     
            Measure = Measure[1].apply(lambda x: pd.Series([eval(i) for i in x.split(",")]))
            df = df.reset_index().set_index(0).drop(columns = 'index', axis = 1)
        except:
            flag = False #no content in egam file
            print('\n\n=====',k,len(filenamelist),path,flag,'\n\n====')
        
        if  flag==True and eval ( df.loc[['MESP_NUM'],:].iloc[0,0] ) > 1 : 
            try:
        
        
                StepX = eval ( df.loc[['STEP_PITCH'],:].iloc[0,0].split(',')[0] )
                StepY = eval ( df.loc[['STEP_PITCH'],:].iloc[0,0].split(',')[1] )    
                OffsetX = eval ( df.loc[['MAP_OFFSET'],:].iloc[0,0].split(',')[0] )
                OffsetY = eval ( df.loc[['MAP_OFFSET'],:].iloc[0,0].split(',')[1] )    
                
                
                '''
                no_x = Kongx( StepX, OffsetX)
                no_y = Kongy( StepY, OffsetY) 
                
                
                
                no_x = int((100000-0.5*StepX + OffsetX)/StepX) + 2 + no_x
                no_y = int((100000-0.5*StepY + OffsetY)/StepY) + 2 + no_y
                
                
                
                no_x = ((((100000 + OffsetX) / (StepX / 2)) -1) % 2) * (StepX/2)
                no_y = ((((100000 + OffsetY) / (StepY / 2)) -1) % 2) * (StepY/2)
                
                if no_x > StepX / 2:
                    nox1 = 1
                else:
                    nox1 = 0
                    
                if no_y > StepY/2:
                    noy1 = 1
                else:
                    noy1 = 0
                '''
                
                
                
                WfrNo = eval ( df.loc[['WAFER_NUM'],:].iloc[0,0] )
                AlignNo = eval ( df.loc[['SHOT_NUM'],:].iloc[0,0] )    
                AlignPosition = []
                for i in range(AlignNo):
                    tmp = 'SHOT(' + str(i+1) + ')'
                    tmp = eval ( df.loc[[tmp],:].iloc[0,0] )
                    #AlignPosition.append((i+1,((tmp[1] -no_x) * StepX+100000)-StepX/2,((tmp[2]-no_y) * StepY+100000)-StepY/2))
                    #AlignPosition.append((i+1,  (tmp[1]-nox1) *StepX + no_x - StepX ,    (tmp[2]-noy1) *StepY + no_y - StepY ))            
                    #AlignPosition.append((i+1,  (tmp[1]-no_x) *StepX +  OffsetX -StepX/2,   ((tmp[2]-no_y) *StepY + OffsetY - StepY/2 )) )
                    AlignPosition.append((i+1,  (tmp[1]-1) *StepX +  OffsetX -StepX/2,   ((tmp[2]-1) *StepY + OffsetY - StepY/2 )) )  
                    
                #Y = Measure [Measure[1].str.contains('1')][4]
                Y = Measure [Measure[1]==1.0][4]
                Y =  pd.DataFrame(Y.values.reshape(WfrNo,AlignNo)).T
                Y.columns = [ i + 1 for i in range(Y.shape[1])]
                
                #X = Measure [Measure[1].str.contains('2')][3]
                X = Measure [Measure[1]==2.0][3]
                X  =  pd.DataFrame(X.values.reshape(WfrNo,AlignNo)).T
                X.columns = [ i + 1 for i in range(X.shape[1])]
                AlignPosition = pd.DataFrame(AlignPosition).drop(columns  = 0, axis = 1)
                
                
                tmpx=[]
                tmpy=[]
                
                magrotortx=[]
                magrotorty=[]
                
                linreg = LinearRegression()
                
                ref = pd.DataFrame([0 for i in range(AlignNo)])
                
                for i in range(X.shape[1]):
                
                    i = i + 1
                    
                    input_y = X[X[i]!=0][i]
                    input_x = AlignPosition.iloc[input_y.index,:]                    
                    model=linreg.fit(input_x, input_y)
                    residual = pd.DataFrame(linreg.intercept_ + linreg.coef_[0] * input_x[1] + linreg.coef_[1] * input_x[2] - input_y)
                    tmpx.append (((residual + ref).fillna(0))[0])
                    #tmpx.append( linreg.intercept_ + linreg.coef_[0] * AlignPosition[1] + linreg.coef_[1] * AlignPosition[2] - X[i] )
                    magrotortx.append([linreg.coef_[0]*1000000,linreg.coef_[1]*1000000])    
            
                    
                   
                    input_y = Y[Y[i]!=0][i]
                    input_x = AlignPosition.iloc[input_y.index,:]                                                            
                    model=linreg.fit(input_x, input_y)
                    residual = pd.DataFrame(linreg.intercept_ + linreg.coef_[0] * input_x[1] + linreg.coef_[1] * input_x[2] - input_y)
                    tmpy.append (((residual + ref).fillna(0))[0])
                    #tmpy.append( linreg.intercept_ + linreg.coef_[0] * AlignPosition[1] + linreg.coef_[1] * AlignPosition[2] - Y[i]  )
                    magrotorty.append([linreg.coef_[1]*1000000,linreg.coef_[0]*1000000])
            
                    
                magrotortx = pd.DataFrame(magrotortx)        
                magrotorty = pd.DataFrame(magrotorty)        
                    
                tmpx = pd.DataFrame(tmpx).T
                tmpx.columns = [ i + 1 for i in range(tmpx.shape[1])]
                tmpy = pd.DataFrame(tmpy).T
                tmpy.columns = [ i + 1 for i in range(tmpy.shape[1])]
            
                rs.AddNew()
                
                rs.Fields.Item("FILE_NAME").Value = df.loc[['FILE_NAME'],:].iloc[0,0].strip()[1:-1]
                rs.Fields.Item("MEAS_SENS").Value = df.loc[['MEAS_SENS'],:].iloc[0,0].strip()[1:-1]
                rs.Fields.Item('EXPS_MACHINE').Value = df.loc[['EXPS_MACHINE'],:].iloc[0,0].strip()[1:-1]
                rs.Fields.Item('MEAS_DATE').Value =  df.loc[['MEAS_DATE'],:].iloc[0,0].strip()[1:-1]
                rs.Fields.Item('MEAS_PDF').Value = df.loc[['MEAS_PDF'],:].iloc[0,0].strip()[1:-1]
                rs.Fields.Item('StepX').Value = StepX
                rs.Fields.Item('StepY').Value = StepY
                rs.Fields.Item('OffsetX').Value = OffsetX
                rs.Fields.Item('OffsetY').Value = OffsetY  
                rs.Fields.Item('LSA_REQ_SHOT').Value = eval ( df.loc[['LSA_REQ_SHOT'],:].iloc[0,0] )
                rs.Fields.Item('FIA_REQ_SHOT').Value = eval ( df.loc[['FIA_REQ_SHOT'],:].iloc[0,0] )
                rs.Fields.Item('FM_ROTATION').Value = eval ( df.loc[['FM_ROTATION'],:].iloc[0,0] )
                rs.Fields.Item('CORR_W_OFF').Value = ( df.loc[['CORR_W_OFF'],:].iloc[0,0] )
                rs.Fields.Item('CORR_W_SCL').Value = ( df.loc[['CORR_W_SCL'],:].iloc[0,0] )
                rs.Fields.Item('CORR_W_ORT').Value =  ( df.loc[['CORR_W_ORT'],:].iloc[0,0] )
                rs.Fields.Item('CORR_W_ROT').Value =  ( df.loc[['CORR_W_ROT'],:].iloc[0,0] )
                rs.Fields.Item('CORR_C_SCL').Value =  ( df.loc[['CORR_C_SCL'],:].iloc[0,0] )
                rs.Fields.Item('CORR_C_ROT').Value =   ( df.loc[['CORR_C_ROT'],:].iloc[0,0] )
                rs.Fields.Item('WAFER_NUM').Value =  WfrNo
                rs.Fields.Item('SHOT_NUM').Value = AlignNo
                
                tmpstr = dataframe_to_string(dataframe = AlignPosition ,shape0 =  eval ( df.loc[['SHOT_NUM'],:].iloc[0,0] ) ,shape1 = 2)
                rs.Fields.Item('ALIGN_SHOT').Value = tmpstr  #'测试坐标位置，排列顺序为 1-x/y,2-x/y,3-x/y,,,,,,,,依次类推
                
                rs.Fields.Item('SEARCH').Value = df.loc[['SENSOR(1)'],:].iloc[0,0].split(',')[1].strip()[1:-1]
                rs.Fields.Item('EGA').Value =  df.loc[['SENSOR(2)'],:].iloc[0,0].split(',')[1].strip()[1:-1] 
                rs.Fields.Item('UPPER_LIMIT').Value =  eval( df.loc[['UPPER_LIMIT'],:].iloc[0,0])
                rs.Fields.Item('LOWER_LIMIT').Value = eval ( df.loc[['LOWER_LIMIT'],:].iloc[0,0] )
                rs.Fields.Item('RETICLE_ROTATION').Value = eval ( df.loc[['CORR_C_ROT'],:].iloc[0,0] )
                
                tmpstr = dataframe_to_string(dataframe = X ,shape0 =  eval ( df.loc[['SHOT_NUM'],:].iloc[0,0] ) ,shape1 = eval ( df.loc[['WAFER_NUM'],:].iloc[0,0] ))
                rs.Fields.Item('EGA_X').Value  = tmpstr
                
                tmpstr = dataframe_to_string(dataframe = tmpx ,shape0 =  eval ( df.loc[['SHOT_NUM'],:].iloc[0,0] ) ,shape1 = eval ( df.loc[['WAFER_NUM'],:].iloc[0,0] ))
                rs.Fields.Item('RESIDUAL_X').Value =tmpstr
                
                tmpstr = dataframe_to_string(dataframe = Y ,shape0 =  eval ( df.loc[['SHOT_NUM'],:].iloc[0,0] ) ,shape1 = eval ( df.loc[['WAFER_NUM'],:].iloc[0,0] ))
                rs.Fields.Item('EGA_Y').Value = tmpstr
                
                tmpstr = dataframe_to_string(dataframe = tmpy ,shape0 =  eval ( df.loc[['SHOT_NUM'],:].iloc[0,0] ) ,shape1 = eval ( df.loc[['WAFER_NUM'],:].iloc[0,0] ))
                rs.Fields.Item('RESIDUAL_Y').Value = tmpstr
                
                tmpstr = dataframe_to_string(dataframe = magrotortx ,shape1 =  2 ,shape0 = eval ( df.loc[['WAFER_NUM'],:].iloc[0,0] ))
                rs.Fields.Item('MODEL_X').Value = tmpstr
                tmpstr = dataframe_to_string(dataframe = magrotorty ,shape1 =  2 ,shape0 = eval ( df.loc[['WAFER_NUM'],:].iloc[0,0] ))
                rs.Fields.Item('MODEL_Y').Value =tmpstr
                rs.Update()  
            except:
                pass
        newpath = "Y:\\NikonEgaLog\\" + path[10:]
        shutil.move(path,newpath)

    #rs.close
    conn.close


def Kongx(  StepX,  OffsetX):
    yita =float ( ( ((int((100000 - StepX/2) / StepX) + 1.5) * StepX -100000) - OffsetX)/StepX )
    
    if yita > 0.5:
        if yita <= 1:
            Kongx = 0
        else:
            Kongx = 1
    else:
        if yita >0:
            Kongx = 1
        else:
            Kongx = 0
    return Kongx



def Kongy(  StepY, OffsetY):
    yita =float ( ( ((int((100000 - StepY/2) / StepY) + 1.5) * StepY -100000) + OffsetY)/StepY )
    
    if yita > 0.5:
        if yita <= 1:
            Kongy = 0
        else:
            Kongy = 1
    else:
        if yita >0:
            Kongy = 1
        else:
            Kongy = 0
    return Kongy





def connect_db(databasepath,rs_name ):                 
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)    
    rs = win32com.client.Dispatch(r'ADODB.Recordset')
    rs.Open(  rs_name , conn, 1, 3)      
    return conn, rs


def dataframe_to_string(dataframe,shape0,shape1):
    tmp = list (  (np.array(dataframe)).reshape(shape0 * shape1 ) )
    tmpstr =''
    for i in tmp:
        #tmpstr = tmpstr + str(i) + ',' 
        tmpstr = tmpstr + str("%.3f" % i) + ',' 
    return tmpstr


    
def get_path(FileDir='f:\\temp\\ALII01'):
#list batchreport filename in specified directory    
    filenamelist=[]
    for root, dirs, files in os.walk(FileDir, False):  #root:所有目录名-->字符串 #dirs: root下的子目录名-->列表 #files：root下的文件名-->列表 # name.endswith(ext)-->文件名筛选 
        for names in files:
            if '.egam' in names:
                filenamelist.append( root  + '\\' + names) 
    filenamelist.sort(reverse = False)
    return (filenamelist)

if __name__ == "__main__":
    single_ega_file()
    tmp = open(r'D:\HuangWeiScript\PyTaskCode\pythonlog.txt','a')
    tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___008-NikonVector.SYSparam  Done\n")
    tmp.close()



