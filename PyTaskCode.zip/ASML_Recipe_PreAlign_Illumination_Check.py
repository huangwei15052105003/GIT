# -*- coding: utf-8 -*-

#check whether part is new or old
#mask comparison



"""
Created on Fri Dec 21 07:56:04 2018

@author: huangwei45
"""

import pandas as pd


F = input('New Part?/Old Part? "New" or "Old":')

name = input('please input part name:')
#name = 'UH5146AJ-L'






f = open('p:/recipe/recipe/' + name )

df = [ i.strip() for i in f if i.strip() != '']
illumination = []
mask = []
f1=False
f2=False

for index, i in enumerate(df):

    if 'Prealignment Method' in i:
        preAlign =  i.split(':')[1].strip()
        print('\npreAlign', preAlign, '\n')
    if  '+=================+=================+=========+========+========+' in i:
        #print(index)
        f1 = True
        no = index
    if f1 == True and index > no and  '+-----------------+-----------------+---------+--------+--------+' not in i:
        #print(i)
        illumination.append( [i.split('|')[1].strip(),i.split('|')[3].strip(),i.split('|')[4].strip(),i.split('|')[5].strip()])
    
    if  '+-----------------+-----------------+---------+--------+--------+'  in i:
        f1 = False
        illumination = pd.DataFrame(illumination).drop_duplicates()
        illumination=illumination[illumination[0].str.len()>1]
        #('illumination\n',illumination)
        
        
        
    if '+=================+=================+==========================+==============+' in i:
        f2=True
    if f2==True and 'SPM' not in i and '|' in i:
        #print(i)
        mask.append([i.split('|')[1].strip(),i.split('|')[3].strip()])
        reticle = pd.DataFrame(mask)
    if '+-----------------+-----------------+--------------------------+--------------+' in i:
        f2=False
        

if "N" in F.upper():
    bt = pd.read_excel('P:/_NewBiasTable/' + name + '_new.xls',sheet_name = 'Sheet1',header =1,skiprows=0)
else:
    bt = pd.read_excel('P:/_NewBiasTable/' + name + '_old.xls',sheet_name = 'Sheet1',header =1,skiprows=0)

bt1 =bt [['PP\nID','Inn','Out','LSA\nFIA']]
bt1.columns=['PPID','NA','INNER','OUTER']
try:
    bt1 = bt1[bt1['NA'] != 'ID4'].fillna(0) #all asml layers
except:
    pass


if name[-2:].upper() == '-L' and preAlign != 'METHOD_1':
    print( 'PreAlignment method is not "METHOD_1",please revise')
    
bt1.columns = [0,1,2,3]
bt1[[1,2,3]] = bt1[[1,2,3]].astype(float)
illumination[[1,2,3]] = illumination[[1,2,3]].astype(float)

bt1[0] = [i.strip() for i in bt1[0]]

data = pd.merge(illumination,bt1,how = 'left',on = 0)

f4 = []
f1 = data['1_x'] == data['1_y'] 
f2 = data['2_x'] == data['2_y']
f3 = data['3_x'] == data['3_y'] 
for i in range(len(f1)):    
    f4.append( f1[i] and f2[i] and f3[i])
data['Flag']=f4
#print(data) 


bt2  = bt [['PP\nID','Mask']]
bt2.columns = [0,1]
bt2[0] = [i.strip() for i in bt2[0]]
data1 = pd.merge(bt2,reticle,how = 'left',on = 0)
data1 = data1.dropna()

data1['1_x']= [ i.strip() for i in data1['1_x']]

data1['MaskFlag']= data1['1_x'] == data1['1_y'] 
data1.columns=[0,'recipe','biasTable','MaskFlag']
data1['NewPart']=F.upper()
#print('\n',data1)

df=pd.merge(data,data1,on = 0)







  
df['PreAlign']=preAlign
df.columns = ['Layer','NA','Inner','Outer','BT_NA','BT_I','BT_O','Flag','recipe','biasTable','MaskFlag','NewPart','Pre_Align']
#df.to_csv('P:/Recipe/NA_SIGMA/' + name + '.csv')
print('\n\n====================Illumination====================\n\n',df [['Layer','NA','Inner','Outer','BT_NA','BT_I','BT_O','Flag','NewPart']])

print('\n\n====================Mask & Pre-Align====================\n\n',df [['Layer','recipe','biasTable','MaskFlag','Pre_Align']])

input('press any key and return to exit ')




