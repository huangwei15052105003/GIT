# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 14:50:23 2018

@author: HUANGWEI45
"""

import win32com.client
import os
import sys
import numpy as np
import pandas as pd
import datetime
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import gc
import re
import matplotlib.ticker as ticker

def Pre_Align():  #plot pre-align data of ASML

    
    filelist = ('Y:\\ASML_BATCH_REPORT\\08_batchreport.csv',
                'Y:\\ASML_BATCH_REPORT\\7D_batchreport.csv',
                'Y:\\ASML_BATCH_REPORT\\82_batchreport.csv',
                'Y:\\ASML_BATCH_REPORT\\83_batchreport.csv',
                'Y:\\ASML_BATCH_REPORT\\85_batchreport.csv',
                'Y:\\ASML_BATCH_REPORT\\86_batchreport.csv',
                'Y:\\ASML_BATCH_REPORT\\87_batchreport.csv',
                'Y:\\ASML_BATCH_REPORT\\89_batchreport.csv',
                'Y:\\ASML_BATCH_REPORT\\8A_batchreport.csv',
                'Y:\\ASML_BATCH_REPORT\\8B_batchreport.csv',
                'Y:\\ASML_BATCH_REPORT\\8C_batchreport.csv')
    
    
    
    for file in filelist:
            print(file)
    
            df = pd.read_csv(file,usecols=['Date','Time','JobName','Layer','Tran_X_Ave','Tran_Y_Ave'])
            df['Tool']=file[21:23]
            df['Index'] = df['Date'] + ' ' + df['Time']
            df['Index'] = pd.to_datetime(df['Index'])
            df = df.sort_values(by='Index')
            df = df.reset_index().set_index(['Index'])
            df = df[['Tool','JobName','Layer','Tran_X_Ave','Tran_Y_Ave']]            
            flag = False           
            df=df.dropna()
            df = df.iloc[-1000:]
            
            tmp = df[ df['JobName'].str.contains('-L')]
            print(tmp.shape[0])
            
            if tmp.shape[0]>0:
                tmp['No']= [ i[7:11] for i in list(tmp['JobName'])]
                tmp = tmp[tmp['No']!= '3559']
                tmp = tmp[tmp['No']!= '1956']
                print(tmp.shape[0])
     
        
            
            if tmp.shape[0] > 0:
                flag=True
                fig = plt.figure(figsize=(12,9))
                
                plt.subplot(221)
                tmp['Tran_X_Ave'].plot()
                plt.title(file[21:23] +'  Large Field Tran_X_Ave')
                plt.ylim(-35,35)
                
                plt.subplot(222)
                tmp['Tran_Y_Ave'].plot()
                plt.title(file[21:23] +'   Large Field Tran_Y_Ave')
                plt.ylim(-35,35)
            
            
            
            
            tmp = df.drop(tmp.index) # newdata = df-tmp -->without -L
            
            if tmp.shape[0] > 0:
                
                if flag ==True:
                    #fig = plt.figure(figsize=(8,6))  
                    
                    plt.subplot(223)  
                    tmp['Tran_X_Ave'].plot()                      
                    plt.title(file[21:23] + '   Standard Field Tran_X_Ave')
                    plt.ylim(-35,35)
                    
                    
                    plt.subplot(224)
                    tmp['Tran_Y_Ave'].plot()
                    plt.title(file[21:23] + '   Standard Field Tran_Y_Ave')
                    plt.ylim(-35,35)
                    fig.subplots_adjust(hspace=0.4)
                else:
                    fig = plt.figure(figsize=(12,5))
                    plt.subplot(121)                
                    tmp['Tran_X_Ave'].plot()                      
                    plt.title(file[21:23] + '   Standard Field Tran_X_Ave')
                    plt.ylim(-35,35)
                    
                    
                    plt.subplot(122)
                    tmp['Tran_Y_Ave'].plot()
                    plt.title(file[21:23] + '   Standard Field Tran_Y_Ave')
                    plt.ylim(-35,35)                
                
                    
                    
            plt.savefig('Z:\\_DailyCheck\\PreAlign\\' + file[21:23],dpi=100, bbox_inches='tight')    
            plt.close()
              
    
        

            
    '''
            plt.savefig('P:\\temp\\OptValueTrend\\' + tool,dpi=100, bbox_inches='tight')
            df.to_csv('P:\\temp\\OptValueTrend\\' + tool + '.csv')
            #plt.show()
            plt.close()
    '''
































def NA_SIGMA():   #get NA/Sigma from Batch Report

    
    filelist = (    'Y:\\ASML_BATCH_REPORT\\OLD_08.csv',
                    'Y:\\ASML_BATCH_REPORT\\OLD_7D.csv',
                    'Y:\\ASML_BATCH_REPORT\\OLD_82.csv',
                    'Y:\\ASML_BATCH_REPORT\\OLD_83.csv',
                    'Y:\\ASML_BATCH_REPORT\\OLD_85.csv',
                    'Y:\\ASML_BATCH_REPORT\\OLD_87.csv',
                    'Y:\\ASML_BATCH_REPORT\\OLD_89.csv',
                    'Y:\\ASML_BATCH_REPORT\\OLD_8A.csv',
                    'Y:\\ASML_BATCH_REPORT\\OLD_8B.csv',
                    'Y:\\ASML_BATCH_REPORT\\OLD_8C.csv',
                    
                    'Y:\\ASML_BATCH_REPORT\\08_batchreport.csv',
                    'Y:\\ASML_BATCH_REPORT\\7D_batchreport.csv',
                    'Y:\\ASML_BATCH_REPORT\\82_batchreport.csv',
                    'Y:\\ASML_BATCH_REPORT\\83_batchreport.csv',
                    'Y:\\ASML_BATCH_REPORT\\85_batchreport.csv',
                    'Y:\\ASML_BATCH_REPORT\\87_batchreport.csv',
                    'Y:\\ASML_BATCH_REPORT\\89_batchreport.csv',
                    'Y:\\ASML_BATCH_REPORT\\8A_batchreport.csv',
                    'Y:\\ASML_BATCH_REPORT\\8B_batchreport.csv',
                    'Y:\\ASML_BATCH_REPORT\\8C_batchreport.csv')
    
    
    
    for file in filelist:
        print(file)
        if file == 'Y:\\ASML_BATCH_REPORT\\OLD_08.csv':
            tmp = pd.read_csv(file,usecols=[4,6,15,16,18,20])
            df = tmp.copy()
            df=df.drop_duplicates()
        else:
            tmp = pd.read_csv(file,usecols=[4,6,15,16,18,20])
            df=pd.concat([df,tmp],axis = 0)
            df=df.drop_duplicates()
 





























def tool_trend(n=10,tool='ALDI03',part_no=10):#所有设备CDU——QC数据
    #n = 10 #define time period for data extraction
    databasepath = r'Z:\_DailyCheck\Database\data.mdb'  
    
    
    enddate = datetime.datetime.now().date()
    startdate = enddate - datetime.timedelta(days=n)
    
        
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)  
    rs = win32com.client.Dispatch(r'ADODB.Recordset')
    
    

    toollist = ('ALII01', 'ALII02', 'ALII03',
       'ALII04', 'ALII05', 'ALII10', 'ALII11', 'ALII12', 'ALII13',
       'ALII14', 'ALII15', 'ALII16', 'ALII17', 'ALII18', 'ALSIB6',
       'ALSIB7', 'ALSIB8', 'ALSIB9', 'ALSIBJ', 'BLSIBK', 'BLSIBL', 
       'BLSIE1','ALDI02', 'ALDI03', 'ALDI05', 'ALDI06', 'ALDI07', 
       'ALDI09','ALDI10', 'ALDI11', 'ALDI12','BLDI08', 'BLDI13')
    

    #tool = "ALDI03"
    
    sql = " Select OL_ASML.PartID,LotID, OL_ASML.Layer, OL_ASML.Proc_EqID, OL_ASML.Ji_Time, OL_ASML.TranX_Optimum, OL_ASML.TranX_Met_Value, OL_ASML.TranX_OX_min, OL_ASML.TranX_OX_max, OL_ASML.TranY_Optimum, OL_ASML.TranY_Met_value, OL_ASML.TranY_OY_Min, OL_ASML.TranY_OY_Max, OL_ASML.ScalX_Optimum, OL_ASML.ScalY_Optimum, OL_ASML.ORT_Optimum, OL_ASML.Wrot_Optimum, OL_ASML.Mag_Optimum, OL_ASML.Rot_Optimum, OL_ASML.ARMag_Optimum, OL_ASML.ARRot_Optimum  \
          FROM OL_ASML  WHERE ((Dcoll_Time>#" + str(startdate) + "#)  \
          AND (Proc_EqID = '" + tool + "')) ORDER BY Ji_Time"         

    rs.Open(sql, conn, 1, 3)

    ovl = []
    rs.MoveFirst()
    
    while True:
        if rs.EOF:
            break
        else:                
            ovl.append ([rs.Fields.Item(i).Value for i in range( rs.Fields.Count)] )
            rs.MoveNext()
    
    
    ovl = pd.DataFrame(ovl)
    ovl.columns =[rs.Fields[i].Name for i in range( rs.Fields.Count)]
    rs.close

    partlayer = ovl.groupby(['PartID','Layer'])['Ji_Time'].count()
    partlayer = pd.DataFrame(partlayer)
    partlayer = partlayer.sort_values(by ='Ji_Time',ascending=False )
    
    #part_no=1
    
    for i in range(0,part_no,1):
        
        part = partlayer.index[i][0]
        layer = partlayer.index[i][1]
        df = ovl[(ovl['PartID'].str.contains(part))  &  (ovl['Layer'].str.contains(layer))]
        
        #ovl_chart(tool,part,layer,i,df=product)
    
    

    
        print(tool,'   ',part,'    ',layer,'    ',df.shape[0])
       
        x1 = list(df['LotID']) 
    
        x  = [i+1 for i in range(len(x1))]
         
        
        
        ##########################################################
        fig = plt.figure(figsize =(24,15))
        gs = GridSpec(5, 1)
        #plt.legend(loc='lower center',ncol=4,bbox_to_anchor=(0., 1.02, 1., .102),mode="expand", borderaxespad=0.)
        ##########################################################
        ax1 = plt.subplot(gs[0:1, 0])
        plt.xticks(x, x1,rotation=90,color='white')
        plt.violinplot(np.array( df[['TranX_OX_max','TranX_OX_min', 'TranX_Met_Value']].T), showmeans=False,  showmedians=True)      
        ax1.grid(color="grey")
        ax1.set_title( tool + '   ' + part + '   ' + layer + '   TranX_Max-Min-Met')
        plt.ylim(-0.06,0.06)
        plt.hlines(0,1,len(x),linewidth=1,color='red', linestyle='-')
        
        ax2 = plt.subplot(gs[1:2, 0])
        plt.xticks(x, x1,rotation=90,color='white')
        plt.violinplot(np.array( df[['TranY_OY_Max','TranY_OY_Min', 'TranY_Met_value']].T), showmeans=False,  showmedians=True)      
        ax2.grid(color="grey")
        ax2.set_title( tool + '   ' + part + '   ' + layer + '   TranY_Max-Min-Met')
        plt.ylim(-0.06,0.06)
        plt.hlines(0,1,len(x),linewidth=1,color='red', linestyle='-')   
     
        ax3 = plt.subplot(gs[2:3, 0]) 
        plt.xticks(x, x1,rotation=90,color='white')
    
        plt.plot(x,list(df['TranX_Optimum']),linewidth = '1', label = 'TranX_Opt', color='red', linestyle='-', marker='v')
        plt.plot(x,list(df['TranY_Optimum']),linewidth = '1', label = 'TranY-Opt', color='blue', linestyle='-', marker='v')
        ax3.set_title(  'Translation Optimum ')    
        ax3.legend(loc='upper center', fancybox=True, framealpha=0.1,ncol=2)
        ax3.grid(color="grey")
        plt.hlines(0,1,len(x),linewidth=1,color='green', linestyle='-')
        
        ax4 = plt.subplot(gs[3:4, 0]) 
        plt.xticks(x, x1,rotation=90,color='white')
        plt.plot(x,list(df['ScalX_Optimum']),linewidth = '1', label = 'Exp-X-Opt', color='red', linestyle='-', marker='v')
        plt.plot(x,list(df['ScalY_Optimum']),linewidth = '1', label = 'Exp-Y-Opt', color='blue', linestyle='-', marker='v')
        ax4.set_title(  'InterField Scaling  ')    
        ax4.legend(loc='upper center', fancybox=True, framealpha=0.1,ncol=2)
        ax4.grid(color="grey")   
        plt.hlines(0,1,len(x),linewidth=1,color='green', linestyle='-')
        
        ax5 = plt.subplot(gs[4:5, 0]) 
        plt.xticks(x, x1,rotation=90)
        plt.plot(x,list(df['ORT_Optimum']),linewidth = '1', label = 'Ort-Opt', color='red', linestyle='-', marker='v')
        plt.plot(x,list(df['Wrot_Optimum']),linewidth = '1', label = 'Wrot-Opt', color='blue', linestyle='-', marker='v')
        ax5.set_title(  'InterField ORT & Wrot  ')    
        ax5.legend(loc='upper center', fancybox=True, framealpha=0.1,ncol=2)
        ax5.grid(color="grey")     
        plt.hlines(0,1,len(x),linewidth=1,color='green', linestyle='-')
        
        #plt.show()
        
        
    
    
        
        #fig.subplots_adjust(hspace=1) 
        plt.savefig('c:\\TEMP\\' + tool + '-' +str( i+1) +'-' + part + '-'+ layer,dpi=100, bbox_inches='tight')  
        plt.clf() # 清图。
        plt.cla() # 清坐标轴。
        plt.close() # 关窗口
        gc.collect()
            

















    
#tool_trend(n=60,tool='ALDI07',part_no=20)#所有设备CDU——QC数据    
#NA_SIGMA()   #get NA/Sigma from Batch Report        
Pre_Align()  #plot pre-align data of ASML

tmp = open(r'C:\anaconda3\log.txt','a')
tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___012-ASML_PRE_ALIGNMENT Done\n")
tmp.close()



#df = pd.read_excel('c:/temp/001.xlsx')
#tmp =df['PPID'].str.split('.',expand=True)
