# -*- coding: utf-8 -*-
"""
Created on Wed Nov  1 09:53:12 2017

@author: huangwei45
"""
#%%
import pandas as pd
import os
import numpy as np
import win32com.client
#import time
from dateutil import parser
#import sys
#import shutil
import gc
import datetime
#%%

def get_batch_report_path(dir_batch_report):
#list batchreport filename in specified directory    
    filenamelist=[]
    for root, dirs, files in os.walk(dir_batch_report, False):  #root:所有目录名-->字符串 #dirs: root下的子目录名-->列表 #files：root下的文件名-->列表 # name.endswith(ext)-->文件名筛选 
        for names in files:
            filenamelist.append( root  + '\\' + names) 
    filenamelist.sort(reverse = False)
    return (filenamelist)

#%%

def connect_db(db_path,rs_name):
    # 建立数据库连接
    conn = win32com.client.Dispatch(r'ADODB.Connection')
    DSN = 'PROVIDER=Microsoft.Jet.OLEDB.4.0;DATA SOURCE=' + db_path +';'
    conn.Open(DSN)    
    # 打开代码记录集
    rs = win32com.client.Dispatch(r'ADODB.Recordset')  
    rs.Open('[' + rs_name + ']', conn, 1, 3)
    
    return rs
#%%
#计算两个字符串之间的时间差，秒数
def sec_delta(start,end):
    s = parser.parse(start)
    e = parser.parse(end)
    sec = (e-s).seconds
    return sec

#替换list指定字符
def replace_list(tmp,new):
    for index,value in enumerate(tmp):
        if len(value.strip()) == 0:
            tmp[index]=new
    return tmp    
    


#%%










       

#%%


#初始化


def singlefile(path):
    Flag1,Flag2,Flag3,Flag4,Flag5= False,False,False,False,False
    Flag6,Flag7,Flag8,Flag9,Flag10 = False,False,False,False,False
    Flag11,Flag12,Flag13,Flag14,Flag15 = False,False,False,False,False
    Flag16,Flag17,Flag18,Flag19,Flag20 = False,False,False,False,False
    Flag21,Flag22 = False,False
    
    
    end_count = 0


    throughput=[]
    data = ['888' for i in range(218)]    
    align=[]
    mark_residual=[]
    new = '888'
    err_arr=[]    
    
    try:
        input = open (path)
    except:
        pass
        #sys.exit(0)


    
    try:
        for line in input:
            

            #Q above P
            if 'INLINE Q ABOVE P CALIBRATION RESULTS' in line:
                Flag21 = True
            if (Flag21 == True ) &  ('Q above P Offset Ave [nm]' in line):
                data[212] = line.split(':')[1].strip()
            if (Flag21 == True ) &  ('Q above P Offset Sdv [nm]:' in line):
                data[213] = line.split(':')[1].strip()                
                Flag21 = False            


            if 'REPORT GENERATED AFTER ABNORMAL TERMINATION OF BATCH' in line:
                end_count = 0                            
            
            
            
                
            if 'Operator:' in line:
                end_count +=1
                if  end_count > 1:   # appended data will not be analyzed
                    input.close
                    break
                tmp = line.split()
                
                try:
                    data[0] = ( tool [  tmp[1].split(':')[1]  ]  )
                except:
                    pass
                try:
                    data[1] = (         tmp[3].split(':')[1]     )
                except:
                    pass
                try:
                    data[2] = (         tmp[4][5:]               )
                except:
                    pass
                
                
             
               
                    
                
            if 'Batch ID' in line:
                data[3] = (  line.split(':')[1].strip('\n').strip()  )
            if 'Job Name' in line:
                data[4] = (  line.split(':')[1].strip('\n').strip()  )
            if 'Job Modified' in line:
                data[5] = (  line[31:].strip()  )
            if 'Layer ID' in line:
                data[6] = (  line[31:46].strip()  )
                
            if 'Alignment Strategy ID' in line:
                data[21] = (  line.split(':')[1].strip('\n').strip()  )
                
            if 'Number of Marks n Required' in line:
                data[22] = (  line.split(':')[1].strip('\n').strip()  )        
                
            if 'SPM Mark Scan' in line:
                data[23] = (  line.split(':')[1].strip('\n').strip()  ) 
                
            if 'Maximum Error Count Dynamic Performance' in line:
                data[24] = (  line.split(':')[1].strip('\n').strip()  ) 
        
            if 'Maximum Error Count Dose' in line:
                data[25] = (  line.split(':')[1].strip('\n').strip()  )
        
            if 'Batch started at' in line:
                data[30] = (  line[28:].strip('\n').strip() )                    
         
            if 'Batch finished at' in line:
                data[31] = (  line[28:].strip('\n').strip() ) 
                
            if 'No. of Wafers out Batch' in line:
                data[32] = (  line[28:].strip('\n').strip() )  
                
            if 'No. of Wafers Accepted' in line:
                data[33] = (  line[28:].strip('\n').strip() )              
            if 'No. of Wafers Rejected' in line:
                data[34] = (  line[28:].strip('\n').strip() )   
               
                
                
                
                
                
                
                
                
                
                
                
                
                
            
            
          
            
                
            #reading dose/focus data
            if '+=================+==========+==========+========+========+' in line: 
                Flag1 = True       
            if (Flag1 == True) & (len( line.split('|') ) == 7) :
                data[7] = (  line.split('|')[2].strip()   )
                data[8] = (  line.split('|')[3].strip()   )
                data[9] = (  line.split('|')[4].strip()   )
                data[10] = (  line.split('|')[5].strip()   )
                Flag1 = False
        
        
        
            #read focus tilt
            if '+=================+========+========+========+========+' in line:
                Flag2 = True
            if (Flag2 == True) & (len( line.split('|') ) == 7) :
                data[11] = (  line.split('|')[2].strip()   )
                data[12] = (  line.split('|')[3].strip()   )
                data[13] = (  line.split('|')[4].strip()   )
                data[14] = (  line.split('|')[5].strip()   )
                Flag2 = False
        
            #read illumination NA
            if '+=================+=================+=========+===================+' in line:
                Flag3 = True
            if (Flag3 == True) & (  ('conventional' in line) | ('annular' in line)  ):
                data[15] = (  line.split('|')[3].strip()   )
                data[16] = (  line.split('|')[4].strip()   )
                Flag3 = False
                
            #read illumination sigma
            if '+=================+=======+=======+=======+=======+' in line:
                Flag4 = True
            if (Flag4 == True)   & (len( line.split('|') ) == 7):
                data[17] = (  line.split('|')[2].strip()   )
                data[18] = (  line.split('|')[3].strip()   )
                data[19] = (  line.split('|')[4].strip()   )
                data[20] = (  line.split('|')[5].strip()   )
                Flag4 = False
                
            #Read Delta Shift Offset
            if '8.0 to 8.8 Shift Corrections' in line:
                 Flag5 = True
            if (Flag5 == True)   &   ('Red [um]' in line)   :
                 data[26] = (  line.split()[4].strip()   )
                 data[27] = (  line.split()[7].strip()   )         
            if (Flag5 == True)   &  ( 'Green [um]' in line)   :
                 data[28] = (  line.split()[4].strip()   )
                 data[29] = (  line.split()[7].strip()   )         
                 Flag5 == False                 
                     
            
            #read throughput data    
            if '+=======+=========+==========+=========+==========+==========+==========+' in line:
                Flag6 = True
            if (Flag6 == True)  &  ('Accept  | Complete'  in line):
                start = line.split('|')[6]
                end = line.split('|')[7]
                throughput.append ( sec_delta(start,end) ) #process time of each wafer
            if '+-------+---------+----------+---------+----------+----------+----------+' in line:
                Flag6 = False
                if len(throughput) > 1:
                    tmp = np.array(throughput[1:])
                    data[35] = (   throughput[0]        )
                    data[36] = ( tmp.max()    )
                    data[37] = ( tmp.min()    )
            
            if '+=================+============================================+=============+' == line.strip():
                Flag8=True
            if ( Flag8 == True ) and ('|' in line):
                data[38] = line.split('|')[2]
                data[217]=line.split('|')[1]
                Flag8 = False
                            
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
         
                    
            

                
                
                
            if line.strip() == 'ALIGNMENT STATISTICS I': #Alignment Statistics I
                Flag9 = True
              
            if (Flag9 == True) & ('| AVE.  |' in line ):                
                tmp = line.split('|')[2:8]
                tmp = replace_list(tmp,new)                                                        
                data[39:45] = (  list(np.array(tmp).astype('float16')))
            if (Flag9 == True) & ('| S.D.  |' in line ):
                tmp = line.split('|')[2:8]
                tmp = replace_list(tmp,new)
                
                
                data[45:51] = (  list(np.array( tmp ).astype('float16')))
                Flag9 = False
                     
                    
            #Alignment Statistics II
            if line.strip() == 'ALIGNMENT STATISTICS II':
                Flag10 = True
            if (Flag10 == True) & ('| AVE. |' in line):                                              
                tmp = line.split('|')[2:8]                    
                tmp = replace_list(tmp,new)       
                data[51:57] = (  list(np.array(tmp).astype('float16')))                        
            if (Flag10 == True) & ('| S.D. | ' in line):
                tmp = line.split('|')[2:8]                        
                tmp = replace_list(tmp,new)
                data[57:63] =(  list(np.array(tmp).astype('float16')))           
                Flag10 = False
                
            #LEVEL STATISTICS I
            if line.strip() == 'LEVEL STATISTICS I':
                Flag11 = True
            if (Flag11 == True ) & ('| MIN. |' in line):
                tmp = line.split('|')[2:7]
                tmp = replace_list(tmp,new) 
                data[215] = eval( tmp[3] )      
        
            if (Flag11 == True ) & ('| MAX. |' in line):
                tmp = line.split('|')[2:7]
                tmp = replace_list(tmp,new)                             
                data[214] = eval (tmp[3])         
                data[216] = data[214]-data[215]                
               
            if (Flag11 == True ) & ('| AVE. |' in line):
                tmp = line.split('|')[2:7]
                tmp = replace_list(tmp,new)
                
                
                data[63:68] = (  list(np.array(tmp).astype('float16')))
            if (Flag11 == True ) & ('| S.D. |' in line):
                tmp = line.split('|')[2:7]                        
                tmp = replace_list(tmp,new)                                                
                data[68:73] = (  list(np.array(tmp).astype('float16')))
                Flag11 = False
  








              
            #LEVEL STATISTICS II
            if line.strip() == 'LEVEL STATISTICS II':
                Flag12 = True
            if (Flag12 == True ) & ('| AVE. |' in line):
                tmp = line.split('|')[2:8]                        
                tmp = replace_list(tmp,new)
                              
                data[73:79] = (  list(np.array(tmp).astype('float16')))
            if (Flag12 == True ) & ('| S.D. |' in line):
                tmp = line.split('|')[2:8]                        
                tmp = replace_list(tmp,new)                                                
                data[79:85] = (  list(np.array(tmp).astype('float16')))
                Flag12 = False
           
                
                
            #LEVEL STATISTICS III
            if line.strip() == 'LEVEL STATISTICS III':
                Flag13 = True
            if (Flag13 == True ) & ('| AVE. |' in line):
                tmp = line.split('|')[2:8]                        
                tmp = replace_list(tmp,new)            
                
                
                data[85:91] = (  list(np.array(tmp).astype('float16')))
            if (Flag13 == True ) & ('| S.D. |' in line):
                tmp = line.split('|')[2:8]                        
                tmp = replace_list(tmp,new)            
                
                
                
                
                data[91:97] = (  list(np.array(tmp).astype('float16')))
                Flag13 = False        
                
            #ALIGNMENT RESULTS V
            if '+=======+=================+=======+====+===+========+====+===+====+====+' in line:
                Flag14 = True
            if (Flag14 == True) & ('|' in line):
                align.append ( line.split('|')[1:11]   )
            if '+-------+-----------------+-------+----+---+--------+----+---+----+----+' in line:
                
                Flag14 = False
            
            if '+=======+=================+=======+=================+=======+=================+' in line:
                Flag15 = True
            if ( Flag15 == True ) & ('|' in line ):
                mark_residual.append ( line.split('|')[1:7])
            if '+-------+-----------------+-------+-----------------+-------+-----------------+' in line:
                
                Flag15 = False
        
            #DYNAMIC PERFORMANCE STATISTICS
            if line.strip()=='DYNAMIC PERFORMANCE STATISTICS':
                Flag16 = True
            if ( Flag16==True) & ( '| MIN. |' in line):
                data[97:105] =  ( line.split('|')[2:10]     )
            if ( Flag16==True) & ( '| MAX. | ' in line):
                data[105:113] =  ( line.split('|')[2:10]     )        
            if ( Flag16==True) & ( '| AVE. |  ' in line):
                data[113:121] =  ( line.split('|')[2:10]     )        
            if ( Flag16==True) & ( '| S.D. |' in line):
                data[121:129] =  ( line.split('|')[2:10]     ) 
                Flag16 = False
                
               
            #LEVEL STATISTICS IV
            if line.strip() == 'LEVEL STATISTICS IV':
                Flag17 = True        
            if (Flag17==True) & ('AVE.' in line):
                data[129:137] = ( line.split('|')[2:10]     )        
            if (Flag17==True) & ('S.D.' in line):
                data[137:145] = ( line.split('|')[2:10]     )
                Flag17 = False
            
            #LEVEL STATISTICS V
            if line.strip() == 'LEVEL STATISTICS V':
                Flag18 = True
            if (Flag18==True) & ('AVE.' in line):
                data[145:151] =  ( line.split('|')[2:8]     )        
            if (Flag18==True) & ('S.D.' in line):
                data[151:157] =  ( line.split('|')[2:8]     )
                Flag18 = False    
               
            #DOSE MONITORING DATA
            if line.strip()=='DOSE MONITORING DATA':
                Flag19 = True
                i = 0
            if Flag19 == True:
                i += 1
                if (i == 3) &  (line.strip() == 'NO ERRORS'):
                    Flag19 = False
                    data[157] = ('False')
                    
            #Reticle Inspection
            if line.strip() == 'Reticle Inspection':
                Flag20 = True
            if (Flag20 == True) & ('Reticle ID' in line):
                data[158] = (  line[20:].strip() )
            if (Flag20 == True) & ( 'Inside Analysis Area' in line):
                data[159:162] = (  line.split('|')[2:5]  )
            if (Flag20 == True) & ( 'Outside Analysis Area' in line):
                data[162:165] = (  line.split('|')[2:5]  )       
            if (Flag20 == True) & ( '| FULL ' in line):
                data[165:168] = (  line.split('|')[2:5]  ) 
                Flag20 = False
                
                
                
                
            #confirm Focus/Dyn/Dose error
            #|       |  Alignment   |Focus | Dyn  | Dose |Chuck |                 |
            #|       |  Alignment   |Focus | Dyn  | Dose | BQ   |Chuck |                 |
            #it depends on different tool, not identical


            if '| Wafer | Pre  |Global |' in line:
                 err_arr = []
                 Flag7 = True
            if (Flag7 == True) & ('|' in line):                
                 if len( line ) > 71:
                     err_arr.append(  line.split('|')[4:9]    ) 
                 else:
                     err_arr.append(  line.split('|')[4:8]    )
                 
            if line.strip() == 'ALIGNMENT RESULTS I':
                
                 err_arr.remove( err_arr[0] ) 
                 err_df = pd.DataFrame( err_arr).astype('int32')
                 err_df.loc['sum'] = err_df.apply(lambda x: x.sum(),axis = 0)              
                 for index, err_count in enumerate( err_df.loc['sum']  ):
                     index = index + 168                     
                     data[index] = err_count

                 Flag7 = False    
            
            if 'Batch Type' in line:
                #data[211] = data.append( line.split(':')[1]   )
                data[211]  = line[31:].strip()
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
    except:
        pass            

        
       
        
        
    input.close
    return data,align,mark_residual
            
            
        
   
  
#%%

    


def aligndata(data,align):
    df = pd.DataFrame(align)
    ####Color used
    #X mark
    i=0
    for x in df[8]:
        if x.strip() == 'RG' :
            i +=1
    data[173] = i

    i=0
    for x in df[8]:
        if x.strip() == 'R' :
            i +=1
    data[174] = i
            
    i=0
    for x in df[8]:
        if x.strip() == 'G' :
            i +=1
    data[175] = i
        
    # y Mark
    i=0
    for x in df[9]:
        if x.strip() == 'RG' :
            i +=1
    data[176] = i
        

    i=0
    for x in df[9]:
        if x.strip() == 'R' :
            i +=1
    data[177] = i
            
    i=0
    for x in df[9]:
        if x.strip() == 'G' :
            i +=1
    data[178] = i    
    
    
    
    if  'XPA' in list( df[1] )[0] :
        # red largest order deviation
            
        data[179] = (df [ df[4].str.contains('R') ][2].astype('int16').max())        
        data[180] = (df [ df[4].str.contains('R') ][2].astype('int16').min())

        
        # Green largest order deviation
        
        data[181] =  (df [ df[4].str.contains('G') ][2].astype('int16').max())
        data[182] =  (df [ df[4].str.contains('G') ][2].astype('int16').min())
  
    
        # red worst quality
        data[183] =  (df [ df[7].str.contains('R') ][5].astype('float64').max())
        data[184] =  (df [ df[7].str.contains('R') ][5].astype('float64').min())

    
        # Green worst quality
        data[185] =  (df [ df[7].str.contains('G') ][5].astype('float64').max())
        data[186] =  (df [ df[7].str.contains('G') ][5].astype('float64').min())
    else:
        
        #X red largest order deviation
        data[187] = (df[ df[1].str.contains('-X')  ][ df[4].str.contains('R') ][2].astype('int16').max())        
        data[188] = (df[ df[1].str.contains('-X')  ][ df[4].str.contains('R') ][2].astype('int16').min())
       
        #X Green largest order deviation
        
        data[189] =  (df[ df[1].str.contains('-X') ][ df[4].str.contains('G') ][2].astype('int16').max())
        data[190] =  (df[ df[1].str.contains('-X') ][ df[4].str.contains('G') ][2].astype('int16').min())
  
    
        #X red worst quality
        data[191] =  (df[ df[1].str.contains('-X') ][ df[7].str.contains('R') ][5].astype('float64').max())
        data[192] =  (df[ df[1].str.contains('-X') ][ df[7].str.contains('R') ][5].astype('float64').min())

    
        #X Green worst quality
        data[193] =  (df[ df[1].str.contains('-X') ][ df[7].str.contains('G') ][5].astype('float64').max())
        data[194] =  (df[ df[1].str.contains('-X') ][ df[7].str.contains('G') ][5].astype('float64').min())        
        
        
        
        #Y red largest order deviation
        data[195] = (df[ df[1].str.contains('-Y')  ][ df[4].str.contains('R') ][2].astype('int16').max())        
        data[196] = (df[ df[1].str.contains('-Y')  ][ df[4].str.contains('R') ][2].astype('int16').min())
       
        #Y Green largest order deviation
        
        data[197] =  (df[ df[1].str.contains('-Y') ][ df[4].str.contains('G') ][2].astype('int16').max())
        data[198] =  (df[ df[1].str.contains('-Y') ][ df[4].str.contains('G') ][2].astype('int16').min())
  
    
        #Y red worst quality
        data[199] =  (df[ df[1].str.contains('-Y') ][ df[7].str.contains('R') ][5].astype('float64').max())
        data[200] =  (df[ df[1].str.contains('-Y') ][ df[7].str.contains('R') ][5].astype('float64').min())

    
        #Y Green worst quality
        data[201] =  (df[ df[1].str.contains('-Y') ][ df[7].str.contains('G') ][5].astype('float64').max())
        data[202] =  (df[ df[1].str.contains('-Y') ][ df[7].str.contains('G') ][5].astype('float64').min())         
        
        
        
def residualdata(mark_residual,data):
    df = pd.DataFrame(mark_residual)   
    data[203] = df [df[1].str.contains('-X')][2].astype('int32').max()
    data[204] = df [df[1].str.contains('-X')][2].astype('int32').min()
    data[205] = df [df[1].str.contains('-X')][2].astype('int32').mean()
    data[206] = df [df[1].str.contains('-X')][2].astype('int32').std()
      
  
    data[207] = df [df[1].str.contains('-Y')][4].astype('int32').max()
    data[208] = df [df[1].str.contains('-Y')][4].astype('int32').min()
    data[209] = df [df[1].str.contains('-Y')][4].astype('int32').mean()
    data[210] = df [df[1].str.contains('-Y')][4].astype('int32').std()        
        
        
        

#%%





        
 ##############################################################################3  


#batchreport路径
def AsmlBatchReport():
    path_list= [r'Z:\ASMLbatch\8B',r'Z:\ASMLbatch\8C',r'Z:\ASMLbatch\8A',r'Z:\ASMLbatch\89',r'Z:\ASMLbatch\7D',
                r'Z:\ASMLbatch\08',r'Z:\ASMLbatch\82',
                r'Z:\ASMLbatch\83',r'Z:\ASMLbatch\85',r'Z:\ASMLbatch\86', 
                r'Z:\ASMLbatch\87'     ]
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    #字典，序列号对应设备名称        
    tool = {'4666': 'ALSD82', '4730': 'ALSD83', '6450': 'ALSD85',
            '8144': 'ALSD86', '4142': 'ALSD87', '6158': 'ALSD89',
            '5688': 'ALSD8A', '4955': 'ALSD8B', '9726': 'ALSD8C',
            '8111': 'BLSD7D', '3527': 'BLSD08'}
    
    
    
        
    for dir_batch_report in path_list:
    #    update_single_tool(dir_batch_report)
    
        
    
    #def update_single_tool(dir_batch_report):    
        newset = None
        filename = None
        oldset = None
        newset = None
        df = None
        activeset = None
        data = None
        align = None
        mark_resiudal = None
        gc.collect()
    
        #列出已完成的batch report文件名
    
        df = pd.read_csv('Y:/ASML_BATCH_REPORT/' + dir_batch_report[13:] + '_batchreport.csv', low_memory=False)  
        oldset = set (df['Path'])
          
                
                
                
        #指定batch report路径，列出其中文件名到 filename         
        filename = get_batch_report_path(dir_batch_report)        
        newset = set (filename)
        
              
        
        
        #待完成的文件名
        activeset = newset-oldset
        print (dir_batch_report, "    ", str(len(activeset)), " files-->to be updated")
        
        if len ( activeset ) > 0:
            
            for filepath in (activeset):
                
                print(filepath)
                if os.path.getsize(filepath) < 8888 | ('rar' in filepath)    |  ('xls' in filepath) :
                    os.system('del "' + filepath + '"')
                else:
                    data,align,mark_residual = singlefile(filepath)
                    if len(align) > 0 :
                        aligndata(data,align) #process array of largest order deviation and worst wafer quality
                    if len (mark_residual) >0 :
                        residualdata(mark_residual,data) # process array of mark residual
                    for index,value in enumerate(data):
                        if (value == '888') | (value == 888) | (  value == 'Actual') | ( value == 'Job' ): #(  value == 'Actual') | ( value == 'Job' )FEM wafer, dose/focus with step,wrong extraction
                            data[index] = ''
                    data.append(filepath)
                    df = pd.DataFrame(data).T
                    df.to_csv('Y:/ASML_BATCH_REPORT/' + dir_batch_report[13:] + '_batchreport.csv',columns=None, header=False, index=False, mode='a',encoding='utf-8')
        #            df.to_csv('p:/huangwei/89_batchreport.csv',columns=None, header=False, index=False, mode='a',encoding='utf-8')
                    
                
if __name__ == "__main__":
    AsmlBatchReport()  
    tmp = open(r'C:\anaconda3\log.txt','a')
    tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___010-AsmlBatchReport  Done\n")
    tmp.close()     
