# -*- coding: utf-8 -*-
"""
Created on Tue Feb 19 07:40:24 2019

@author: HUANGWEI45
"""
import wx 
''' 
class Frame1(wx.Frame):
    
    def __init__(self, parent, title):
        wx.Frame.__init__(self, parent, title = title)
        panel = wx.Panel(self)
        sizer = wx.BoxSizer(wx.VERTICAL)
        self.text1 = wx.TextCtrl(panel, value = "Hello, World!",
	                    size = (200,180), style = wx.TE_MULTILINE)
        sizer.Add(self.text1, 0, wx.ALIGN_TOP | wx.EXPAND)
        button = wx.Button(panel, label = "Click Me")
        sizer.Add(button)
        panel.SetSizerAndFit(sizer)        
        panel.Layout()
        self.Bind(wx.EVT_BUTTON,self.OnClick,button)
        self.Show(True)
        
    def OnClick(self, text):
        self.text1.AppendText("\nHello, World!")
	         
if __name__ == '__main__':
    app = wx.App()
    frame = Frame1(None, "Hello World in wxPython")
    app.MainLoop()




import wx  

class MyFrame(wx.Frame):  
    def __init__(self, parent, title):  
  
        wx.Frame.__init__(self, parent, -1, title, pos=(10, 10), size=(1024, 768))  
  
        menuBar = wx.MenuBar()  
        self.SetMenuBar(menuBar)  
        menu = wx.Menu()  
        menu.Append(wx.ID_EXIT, "E&xit", "Exit this application")  
        self.Bind(wx.EVT_MENU, self.OnTimeToClose, id=wx.ID_EXIT)  
        menuBar.Append(menu, "&File")  
  
        panel = wx.Panel(self)  
        text = wx.StaticText(panel, -1, "Hello wxPython!")  
        text.SetFont(wx.Font(12, wx.SWISS, wx.NORMAL, wx.BOLD))  
        text.SetSize(text.GetBestSize())  
        panel.Layout()  
  
    def OnTimeToClose(self, evt):  
        self.Close()  
  
class MyApp(wx.App):  
    def OnInit(self):  
        frame = MyFrame(None, "Hello wxPython!")  
        self.SetTopWindow(frame)  
        frame.Show(True)  
        return True  
          
app = MyApp()  
app.MainLoop()  
del app

'''  



import wx
import numpy as np
import matplotlib

# matplotlib采用WXAgg为后台,将matplotlib嵌入wxPython中
matplotlib.use("WXAgg")

from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg as FigureCanvas
from matplotlib.backends.backend_wxagg import NavigationToolbar2WxAgg as NavigationToolbar
from matplotlib.ticker import MultipleLocator, FuncFormatter

import pylab
from matplotlib import pyplot


class MPL_Panel_base(wx.Panel):
    ''''' #MPL_Panel_base面板,可以继承或者创建实例'''

    def __init__(self, parent):
        wx.Panel.__init__(self, parent=parent, id=-1)

        self.Figure = matplotlib.figure.Figure(figsize=(4, 3))
        self.axes = self.Figure.add_axes([0.1, 0.1, 0.8, 0.8])
        self.FigureCanvas = FigureCanvas(self, -1, self.Figure)

        self.NavigationToolbar = NavigationToolbar(self.FigureCanvas)

        self.StaticText = wx.StaticText(self, -1, label='Show Help String')

        self.SubBoxSizer = wx.BoxSizer(wx.HORIZONTAL)
        self.SubBoxSizer.Add(self.NavigationToolbar, proportion=0, border=2, flag=wx.ALL | wx.EXPAND)
        self.SubBoxSizer.Add(self.StaticText, proportion=-1, border=2, flag=wx.ALL | wx.EXPAND)

        self.TopBoxSizer = wx.BoxSizer(wx.VERTICAL)
        self.TopBoxSizer.Add(self.SubBoxSizer, proportion=-1, border=2, flag=wx.ALL | wx.EXPAND)
        self.TopBoxSizer.Add(self.FigureCanvas, proportion=-10, border=2, flag=wx.ALL | wx.EXPAND)

        self.SetSizer(self.TopBoxSizer)

        ###方便调用
        self.pylab = pylab
        self.pl = pylab
        self.pyplot = pyplot
        self.numpy = np
        self.np = np
        self.plt = pyplot

    def UpdatePlot(self):
        '''''#修改图形的任何属性后都必须使用self.UpdatePlot()更新GUI界面 '''
        self.FigureCanvas.draw()

    def plot(self, *args, **kwargs):
        '''''#最常用的绘图命令plot '''
        self.axes.plot(*args, **kwargs)
        self.UpdatePlot()

    def semilogx(self, *args, **kwargs):
        ''''' #对数坐标绘图命令 '''
        self.axes.semilogx(*args, **kwargs)
        self.UpdatePlot()

    def semilogy(self, *args, **kwargs):
        ''''' #对数坐标绘图命令 '''
        self.axes.semilogy(*args, **kwargs)
        self.UpdatePlot()

    def loglog(self, *args, **kwargs):
        ''''' #对数坐标绘图命令 '''
        self.axes.loglog(*args, **kwargs)
        self.UpdatePlot()

    def grid(self, flag=True):
        ''''' ##显示网格  '''
        if flag:
            self.axes.grid()
        else:
            self.axes.grid(False)

    def title_MPL(self, TitleString="wxMatPlotLib Example In wxPython"):
        ''''' # 给图像添加一个标题   '''
        self.axes.set_title(TitleString)

    def xlabel(self, XabelString="X"):
        ''''' # Add xlabel to the plotting    '''
        self.axes.set_xlabel(XabelString)

    def ylabel(self, YabelString="Y"):
        ''''' # Add ylabel to the plotting '''
        self.axes.set_ylabel(YabelString)

    def xticker(self, major_ticker=1.0, minor_ticker=0.1):
        ''''' # 设置X轴的刻度大小 '''
        self.axes.xaxis.set_major_locator(MultipleLocator(major_ticker))
        self.axes.xaxis.set_minor_locator(MultipleLocator(minor_ticker))

    def yticker(self, major_ticker=1.0, minor_ticker=0.1):
        ''''' # 设置Y轴的刻度大小 '''
        self.axes.yaxis.set_major_locator(MultipleLocator(major_ticker))
        self.axes.yaxis.set_minor_locator(MultipleLocator(minor_ticker))

    def legend(self, *args, **kwargs):
        ''''' #图例legend for the plotting  '''
        self.axes.legend(*args, **kwargs)

    def xlim(self, x_min, x_max):
        ''' # 设置x轴的显示范围  '''
        self.axes.set_xlim(x_min, x_max)

    def ylim(self, y_min, y_max):
        ''' # 设置y轴的显示范围   '''
        self.axes.set_ylim(y_min, y_max)

    def savefig(self, *args, **kwargs):
        ''' #保存图形到文件 '''
        self.Figure.savefig(*args, **kwargs)

    def cla(self):
        ''' # 再次画图前,必须调用该命令清空原来的图形  '''
        self.axes.clear()
        self.Figure.set_canvas(self.FigureCanvas)
        self.UpdatePlot()

    def ShowHelpString(self, HelpString="Show Help String"):
        ''''' #可以用它来显示一些帮助信息,如鼠标位置等 '''
        self.StaticText.SetLabel(HelpString)

        ################################################################


class MPL_Panel(MPL_Panel_base):
    ''''' #MPL_Panel重要面板,可以继承或者创建实例 '''

    def __init__(self, parent):
        MPL_Panel_base.__init__(self, parent=parent)

        # 测试一下
        self.FirstPlot()


        # 仅仅用于测试和初始化,意义不大

    def FirstPlot(self):
        # self.rc('lines',lw=5,c='r')
        self.cla()
        x = np.arange(-5, 5, 0.25)
        y = np.sin(x)
        self.yticker(0.5, 0.1)
        self.xticker(1.0, 0.2)
        self.xlabel('X')
        self.ylabel('Y')
        self.title_MPL("图像")
        self.grid()
        self.plot(x, y, '--^g')





# MPL_Frame添加了MPL_Panel的1个实例
###############################################################################
class MPL_Frame(wx.Frame):
    """MPL_Frame可以继承,并可修改,或者直接使用"""

    def __init__(self, title="MPL_Frame Example In wxPython", size=(1280, 800)):
        wx.Frame.__init__(self, parent=None, title=title, size=size)

        self.MPL = MPL_Panel_base(self)

        # 创建FlexGridSizer
        self.FlexGridSizer = wx.FlexGridSizer(rows=9, cols=1, vgap=5, hgap=5)
        self.FlexGridSizer.SetFlexibleDirection(wx.BOTH)

        self.RightPanel = wx.Panel(self, -1)

        # 测试按钮1
        self.Button1 = wx.Button(self.RightPanel, -1, "刷新", size=(100, 40), pos=(10, 10))
        self.Button1.Bind(wx.EVT_BUTTON, self.Button1Event)

        # 测试按钮2
        self.Button2 = wx.Button(self.RightPanel, -1, "关于", size=(100, 40), pos=(10, 10))
        self.Button2.Bind(wx.EVT_BUTTON, self.Button2Event)

        # 加入Sizer中
        self.FlexGridSizer.Add(self.Button1, proportion=0, border=5, flag=wx.ALL | wx.EXPAND)
        self.FlexGridSizer.Add(self.Button2, proportion=0, border=5, flag=wx.ALL | wx.EXPAND)

        self.RightPanel.SetSizer(self.FlexGridSizer)

        self.BoxSizer = wx.BoxSizer(wx.HORIZONTAL)
        self.BoxSizer.Add(self.MPL, proportion=-10, border=2, flag=wx.ALL | wx.EXPAND)
        self.BoxSizer.Add(self.RightPanel, proportion=0, border=2, flag=wx.ALL | wx.EXPAND)

        self.SetSizer(self.BoxSizer)

        # 状态栏
        self.StatusBar()

        # MPL_Frame界面居中显示
        self.Centre(wx.BOTH)



        # 按钮事件,用于测试

    def Button1Event(self, event):
        self.MPL.cla()  # 必须清理图形,才能显示下一幅图
        x = np.arange(-10, 10, 0.25)
        y = np.cos(x)
        self.MPL.plot(x, y, '--*g')
        self.MPL.xticker(2.0, 0.5)
        self.MPL.yticker(0.5, 0.1)
        self.MPL.title_MPL("MPL1")
        self.MPL.ShowHelpString("You Can Show MPL Helpful String Here !")
        self.MPL.grid()
        self.MPL.UpdatePlot()  # 必须刷新才能显示

    def Button2Event(self, event):
        self.AboutDialog()


        # 打开文件,用于测试

        def DoOpenFile(self):
            wildcard = r"Data files (*.dat)|*.dat|Text files (*.txt)|*.txt|ALL Files (*.*)|*.*"
            open_dlg = wx.FileDialog(self, message='Choose a file', wildcard=wildcard, style='')
            if open_dlg.ShowModal() == wx.ID_OK:
                path = open_dlg.GetPath()
                try:
                    file = open(path, 'r')
                    text = file.read()
                    file.close()
                except:
                    dlg = wx.MessageDialog(self, 'Error opening file\n')
                    dlg.ShowModal()

            open_dlg.Destroy()



        # 自动创建状态栏

    def StatusBar(self):
        self.statusbar = self.CreateStatusBar()
        self.statusbar.SetFieldsCount(3)
        self.statusbar.SetStatusWidths([-2, -2, -1])


        # About对话框

    def AboutDialog(self):
        dlg = wx.MessageDialog(self,
                               '\twxMatPlotLib\t\nMPL_Panel_base,MPL_Panel,MPL_Frame and MPL2_Frame \n Created by Wu Xuping\n Version 1.0.0 \n 2012-02-01',
                               'About MPL_Frame and MPL_Panel', wx.OK | wx.ICON_INFORMATION)
        dlg.ShowModal()
        dlg.Destroy()

        ###############################################################################


###  MPL2_Frame添加了MPL_Panel的两个实例
###############################################################################
class MPL2_Frame(wx.Frame):
    """MPL2_Frame可以继承,并可修改,或者直接使用"""

    def __init__(self, title="MPL2_Frame Example In wxPython", size=(1280, 800)):
        wx.Frame.__init__(self, parent=None, title=title, size=size)

        self.BoxSizer = wx.BoxSizer(wx.HORIZONTAL)

        self.MPL1 = MPL_Panel_base(self)
        self.BoxSizer.Add(self.MPL1, proportion=-1, border=2, flag=wx.ALL | wx.EXPAND)

        self.MPL2 = MPL_Panel_base(self)
        self.BoxSizer.Add(self.MPL2, proportion=-1, border=2, flag=wx.ALL | wx.EXPAND)

        self.RightPanel = wx.Panel(self, -1)
        self.BoxSizer.Add(self.RightPanel, proportion=0, border=2, flag=wx.ALL | wx.EXPAND)

        self.SetSizer(self.BoxSizer)

        # 创建FlexGridSizer
        self.FlexGridSizer = wx.FlexGridSizer(rows=9, cols=1, vgap=5, hgap=5)
        self.FlexGridSizer.SetFlexibleDirection(wx.BOTH)

        # 测试按钮1
        self.Button1 = wx.Button(self.RightPanel, -1, "TestButton", size=(100, 40), pos=(10, 10))
        self.Button1.Bind(wx.EVT_BUTTON, self.Button1Event)

        # 测试按钮2
        self.Button2 = wx.Button(self.RightPanel, -1, "AboutButton", size=(100, 40), pos=(10, 10))
        self.Button2.Bind(wx.EVT_BUTTON, self.Button2Event)

        # 加入Sizer中
        self.FlexGridSizer.Add(self.Button1, proportion=0, border=5, flag=wx.ALL | wx.EXPAND)
        self.FlexGridSizer.Add(self.Button2, proportion=0, border=5, flag=wx.ALL | wx.EXPAND)

        self.RightPanel.SetSizer(self.FlexGridSizer)

        # 状态栏
        self.StatusBar()

        # MPL2_Frame界面居中显示
        self.Centre(wx.BOTH)



        # 按钮事件,用于测试

    def Button1Event(self, event):
        self.MPL1.cla()  # 必须清理图形,才能显示下一幅图
        x = np.arange(-5, 5, 0.2)
        y = np.cos(x)
        self.MPL1.plot(x, y, '--*g')
        self.MPL1.xticker(2.0, 1.0)
        self.MPL1.yticker(0.5, 0.1)
        self.MPL1.title_MPL("MPL1")
        self.MPL1.ShowHelpString("You Can Show MPL1 Helpful String Here !")
        self.MPL1.grid()
        self.MPL1.UpdatePlot()  # 必须刷新才能显示

        self.MPL2.cla()
        self.MPL2.plot(x, np.sin(x), ':^b')
        self.MPL2.xticker(1.0, 0.5)
        self.MPL2.yticker(0.2, 0.1)
        self.MPL2.title_MPL("MPL2")
        self.MPL2.grid()
        self.MPL2.UpdatePlot()

    def Button2Event(self, event):
        self.AboutDialog()



        # 自动创建状态栏

    def StatusBar(self):
        self.statusbar = self.CreateStatusBar()
        self.statusbar.SetFieldsCount(3)
        self.statusbar.SetStatusWidths([-2, -2, -1])


        # About对话框

    def AboutDialog(self):
        dlg = wx.MessageDialog(self,
                               '\twxMatPlotLib\t\nMPL_Panel_base,MPL_Panel,MPL_Frame and MPL2_Frame \n Created by Wu Xuping\n Version 1.0.0 \n 2012-02-01',
                               'About MPL_Frame and MPL_Panel', wx.OK | wx.ICON_INFORMATION)
        dlg.ShowModal()
        dlg.Destroy()




        ########################################################################


# 主程序测试
if __name__ == '__main__':
    try:
        del app
    except:
        pass
    app = wx.App()
    frame = MPL2_Frame()
    #frame = MPL_Frame()
    frame.Center()
    frame.Show()
    app.MainLoop()


#原文：https://blog.csdn.net/xyisv/article/details/78576948 
#https://stackoverflow.com/questions/10737459/embedding-a-matplotlib-figure-inside-a-wxpython-panel
    
    


'''    
# =============================================================================
# https://angeloce.iteye.com/blog/425180    
# =============================================================================
import wx     
from matplotlib.backends import backend_wxagg     
from matplotlib.figure import Figure     
    
class TestFrame(wx.Frame):     
    def __init__(self):     
        wx.Frame.__init__(self, None)     
             
        self.panel = backend_wxagg.FigureCanvasWxAgg(self, -1, Figure())     
        axes = self.panel.figure.gca()     
        axes.cla()     
        axes.plot([1,2,3],[1,2,3])     
             
        self.panel.draw()  
             
    
    
app = wx.App()     
f= TestFrame()     
f.Show(True)     
app.MainLoop()
'''    
    
    



  












#Function: Show Image using wxpython,as well as matplotlib

#http://www.pythontip.com/blog/post/6854/
#http://www.tuicool.com/articles/Jriqyu 



# =============================================================================
# StaticTxt
# =============================================================================
  
try:
    del app
except:
    pass    
    
import wx 
 
class Mywin(wx.Frame): 
   def __init__(self, parent, title): 
      super(Mywin, self).__init__(parent, title = title,size = (1200,800))
      panel = wx.Panel(self) 
      txt1 = "Python GUI development" 
      txt2 = "using wxPython" 
      txt3 = " Python port of wxWidget " 
      txt = txt1+"\n"+txt2+"\n"+txt3       
      
      
      
      box = wx.BoxSizer(wx.VERTICAL) 
      
      
      
      
      lbl = wx.StaticText(panel,-1,style = wx.ALIGN_CENTER) 		
      font = wx.Font(30, wx.ROMAN, wx.ITALIC, wx.NORMAL) 
      lbl.SetFont(font) 
      lbl.SetLabel(txt) 
      box.Add(lbl,0,wx.ALIGN_CENTER) 

      lblwrap = wx.StaticText(panel,-1,style = wx.ALIGN_RIGHT) 
      txt = txt1+txt2+txt3 		
      lblwrap.SetLabel(txt) 
      lblwrap.Wrap(20) 
      box.Add(lblwrap,0,wx.ALIGN_LEFT) 
		
      lbl1 = wx.StaticText(panel,-1, style = wx.ALIGN_LEFT | wx.ST_ELLIPSIZE_MIDDLE) 
      font = wx.Font(30, wx.ROMAN, wx.ITALIC, wx.NORMAL) 
      lbl.SetFont(font)       
      
      lbl1.SetLabel(txt) 
      lbl1.SetForegroundColour((255,0,0)) 
      lbl1.SetBackgroundColour((0,0,0)) 
		
#      font = self.GetFont()      
#      font.SetTutorialsSize(20) 
#      lbl1.SetFont(font) 
   
      
      
      
		
      box.Add(lbl1,0,wx.ALIGN_LEFT) 
      panel.SetSizer(box) 
      self.Centre() 
      self.Show() 
		
app = wx.App() 
Mywin(None,  'StaticText demo') 
app.MainLoop()    
 
    
# =============================================================================
# TextCtrl    
# =============================================================================
try:
    del app
except:
    pass
    
import wx
  
class Mywin(wx.Frame): 
   def __init__(self, parent, title): 
      super(Mywin, self).__init__(parent, title = title,size = (350,250))
		
      panel = wx.Panel(self) 
      vbox = wx.BoxSizer(wx.VERTICAL) 
         
      hbox1 = wx.BoxSizer(wx.HORIZONTAL) 
      l1 = wx.StaticText(panel, -1, "文本域") 
		
      hbox1.Add(l1, 1, wx.EXPAND|wx.ALIGN_LEFT|wx.ALL,5) 
      self.t1 = wx.TextCtrl(panel) 
		
      hbox1.Add(self.t1,1,wx.EXPAND|wx.ALIGN_LEFT|wx.ALL,5) 
      self.t1.Bind(wx.EVT_TEXT,self.OnKeyTyped) 
      vbox.Add(hbox1) 
		
      hbox2 = wx.BoxSizer(wx.HORIZONTAL)
      l2 = wx.StaticText(panel, -1, "密码文本") 
		
      hbox2.Add(l2, 1, wx.ALIGN_LEFT|wx.ALL,5) 
      self.t2 = wx.TextCtrl(panel,style = wx.TE_PASSWORD) 
      self.t2.SetMaxLength(5) 
		
      hbox2.Add(self.t2,1,wx.EXPAND|wx.ALIGN_LEFT|wx.ALL,5) 
      vbox.Add(hbox2) 
      self.t2.Bind(wx.EVT_TEXT_MAXLEN,self.OnMaxLen)
		
      hbox3 = wx.BoxSizer(wx.HORIZONTAL) 
      l3 = wx.StaticText(panel, -1, "多行文本") 
		
      hbox3.Add(l3,1, wx.EXPAND|wx.ALIGN_LEFT|wx.ALL,5) 
      self.t3 = wx.TextCtrl(panel,size = (200,100),style = wx.TE_MULTILINE) 
		
      hbox3.Add(self.t3,1,wx.EXPAND|wx.ALIGN_LEFT|wx.ALL,5) 
      vbox.Add(hbox3) 
      self.t3.Bind(wx.EVT_TEXT_ENTER,self.OnEnterPressed)  
		
      hbox4 = wx.BoxSizer(wx.HORIZONTAL) 
      l4 = wx.StaticText(panel, -1, "只读取文本") 
		
      hbox4.Add(l4, 1, wx.EXPAND|wx.ALIGN_LEFT|wx.ALL,5) 
      self.t4 = wx.TextCtrl(panel, value = "只读文本",style = wx.TE_READONLY|wx.TE_CENTER) 
			
      hbox4.Add(self.t4,1,wx.EXPAND|wx.ALIGN_LEFT|wx.ALL,5) 
      vbox.Add(hbox4) 
      panel.SetSizer(vbox) 
        
      self.Centre() 
      self.Show() 
      self.Fit()  
		
   def OnKeyTyped(self, event): 
      print (event.GetString()) 
		
   def OnEnterPressed(self,event): 
      print ("Enter pressed" )
		
   def OnMaxLen(self,event): 
      print ("Maximum length reached") 
		
app = wx.App() 
Mywin(None,  'TextCtrl实例-www.yiibai.com')
app.MainLoop()  
  
    








# =============================================================================
# https://www.yiibai.com/wxpython/wxpython_multiple_document_interface.html
#一个典型的GUI应用程序可以有多个窗口。标签和堆叠部件一次允许激活一个这样的窗口。然而，很多时候这种方法可能不是有用，因为其他窗口可能是隐藏的。 
#同时显示多个窗口的一种方法是创建它们作为独立的窗口。这被称为SDI(单文档界面)。这需要更多的存储器资源，每个窗口可以具有其自己的菜单系统，工具栏等等 
#在wxPython中的MDI框架提供了wx.MDIParentFrame类。其对象充当容器为多个子窗口，每个对象是wx.MDIChildFrame类。 
#子窗口位于父框架的MDIClientWindow区域。当一个孩子帧添加，父框架的菜单栏将显示包含子窗口按钮排放在级联或平铺方式在菜单
# =============================================================================



try:
    del app
except:
    pass


import wx 
 
class MDIFrame(wx.MDIParentFrame): 
   def __init__(self): 
      wx.MDIParentFrame.__init__(self, None, -1, "MDI Parent - www.yiibai.com", size = (1280,800)) 
      menu = wx.Menu() 
      menu.Append(5000, "&New Window") 
      menu.Append(5001, "&Exit") 
      menubar = wx.MenuBar() 
      menubar.Append(menu, "&File") 
		
      self.SetMenuBar(menubar) 
      self.Bind(wx.EVT_MENU, self.OnNewWindow, id = 5000) 
      self.Bind(wx.EVT_MENU, self.OnExit, id = 5001) 
		
   def OnExit(self, evt): 
      self.Close(True)  
		
   def OnNewWindow(self, evt): 
      win = wx.MDIChildFrame(self, -1, "Child Window")
      win.Show(True) 
		
app = wx.App() 
frame = MDIFrame() 
frame.Show() 
app.MainLoop()
  
# =============================================================================
# 原文：https://blog.csdn.net/aslongasyoulike/article/details/78359802 
# =============================================================================

try:
    del app
except:
    pass
import wx
from PIL import Image
class Myframe(wx.Frame):
    def __init__(self,filename):
        wx.Frame.__init__(self, None, -1, u'图片显示', size=(500, 640))
        self.filename='c:/temp/001.bmp'
        self.Bind(wx.EVT_SIZE, self.change)
        self.p=wx.Panel(self,-1)
        self.SetBackgroundColour('white')
    def start(self):
        self.p.DestroyChildren()#抹掉原先显示的图片
        self.width, self.height = self.GetSize()
        image = Image.open(self.filename)
        self.x, self.y = image.size
        self.x = self.width / 2 - self.x / 2
        self.y = self.height / 2 - self.y / 2
        self.pic = wx.Image(self.filename, wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        # 通过计算获得图片的存放位置
        self.button = wx.BitmapButton(self.p, -1, self.pic, pos=(self.x, self.y))
        self.p.Fit()
    def change(self, size):#如果检测到框架大小的变化，及时改变图片的位置
        if self.filename != "":
            self.start()
        else:
            pass
app=wx.PySimpleApp()
frame=Myframe('pig.jpg')
frame.start()
frame.Center()
frame.Show()
app.MainLoop()








# =============================================================================
# 
# =============================================================================













import wx
import os
import sys
import string

#你有H盘吗？没有的话在这个初始化函数里修改加载的初始路径
class PBDirFrame(wx.Frame):
     def __init__(self, app):
         wx.Frame.__init__(self, None, -1, "选择文件夹", size=(250,500))
         self.app = app
         #设置字体
         font = wx.Font(12, wx.DEFAULT, wx.NORMAL, wx.NORMAL, False, 'Courier New')
         self.SetFont(font)
         
         #文件夹listbox
         self.list = wx.ListBox(self, -1, (0,0), (200,600), '', wx.LB_SINGLE)
         self.list.Bind(wx.EVT_LISTBOX_DCLICK, self.OnDClick)
         
         #加载当前文件夹
        #curdir = os.getcwd()#在这里修改初始路径，这个是当前工作路径
         curdir = 'C:\\temp'
         os.chdir(curdir)
         self.LoadDir(curdir)
         
         #绑定事件
         self.Bind(wx.EVT_CLOSE, self.OnClose)


         
         #显示窗口
         self.Show()
     
     def OnClose(self, event):
         self.Destroy()
         self.app.Close()
     
     #listbox双击事件
     def OnDClick(self, event):
         if self.list.GetSelection()==0:#判断是否选择了返回上一层文件夹
            path = os.getcwd()
            pathinfo = os.path.split(path)
            dir = pathinfo[0]
         else:#获得需要进入的下一层文件夹
            dir = self.list.GetStringSelection()
         
         if os.path.isdir(dir):#进入文件夹
            self.LoadDir(dir)
         elif os.path.splitext(dir)[-1]=='.jpg':#显示图片
            self.app.ShowImage(dir)

    #加载文件夹，如果你想定义自己的排序，那么修改这个方法吧~
     def LoadDir(self, dir):
         #不是目录则不进行操作
        if not os.path.isdir(dir):
             return
         
        self.list.Clear()#清空
        self.list.Append('...')#添加返回上一层文件夹标志

        dirs = []
        jpgs = []
        nnjpgs = []
        for _dir in os.listdir(dir):
             if os.path.isdir(dir+os.path.sep+_dir):
                 dirs.append(_dir)
             else:
                 info = os.path.splitext(_dir)
                 if info[-1]=='.jpg':
                     if info[0].isdigit():
                         jpgs.append(string.atoi(info[0]))#转化为数字
                     else:
                         nnjpgs.append(_dir)
        jpgs.sort()
        for _jpgs in jpgs:
             self.list.Append(str(_jpgs)+'.jpg')
        for _nnjpgs in nnjpgs:
             self.list.Append(_nnjpgs)
        for _dirs in dirs:
             self.list.Append(_dirs)

        os.chdir(dir)#设置工作路径

    #获得下一张要显示的图片
     def GetNextImage(self):
         index = self.list.GetSelection()
         i = index
         while i+1<self.list.GetCount():
             i += 1
             if os.path.splitext(self.list.GetString(i))[-1]=='.jpg':
                 break
         if i<self.list.GetCount():
             index = i
         self.list.SetSelection(index)
         return self.list.GetStringSelection()

    #获得上一张图片
     def GetPreImage(self):
         index = self.list.GetSelection()
         i = index
         while i-1>0:
             i -= 1
             if os.path.splitext(self.list.GetString(i))[-1]=='.jpg':
                 break
         if i>0:
             index = i
         
         self.list.SetSelection(index)
         return self.list.GetStringSelection()


class PBPicFrame(wx.Frame):

    max_width = 400
    max_height = 600

    def __init__(self, app):
         wx.Frame.__init__(self, None, -1, "显示图片", size=(400,400))#, style=wx.SIMPLE_BORDER)

        #是否要移动图片的标志
         self.bmoved = False
         
         self.app = app

        #staticbitmap
         self.bmp = wx.StaticBitmap(self, 0, wx.NullBitmap, (0,0), (400,400))


         self.Bind(wx.EVT_MOUSEWHEEL, self.OnChangeImage)
         self.bmp.Bind(wx.EVT_LEFT_DOWN, self.OnLeftDown)
         self.bmp.Bind(wx.EVT_LEFT_UP, self.OnLeftUp)
         self.bmp.Bind(wx.EVT_MOTION, self.OnMotion)
         self.Bind(wx.EVT_KEY_DOWN, self.OnKeyDown)
         
         self.ShowFullScreen(True, style=wx.FULLSCREEN_ALL)
         self.Hide()


    def ShowImage(self, path):
         if os.path.splitext(path)[-1]!='.jpg':
             return
         self.bmppath = path
         image = wx.Image(path, wx.BITMAP_TYPE_JPEG)
         bmp = image.ConvertToBitmap()
         size = self.GetSize(bmp)
         bmp = image.Scale(size[0], size[1]).ConvertToBitmap()
         self.bmp.SetSize(size)
         self.bmp.SetBitmap(bmp)
         self.Show()

    def GetSize(self, bmp):
         width = bmp.GetWidth()
         height = bmp.GetHeight()
         if width>self.max_width:
             height = height*self.max_width/width
             width = self.max_width
         if height>self.max_height:
             width = width*self.max_height/height
             height = self.max_height
         size = width, height
         return size
        

    def OnChangeImage(self, event):
         rotation = event.GetWheelRotation()
         if rotation<0:
             self.app.ShowNextImage()
         else:
             self.app.ShowPreImage()
     
    def OnLeftDown(self, event):
         self.pos = event.GetX(), event.GetY()
         self.bmoved = True

    def OnLeftUp(self, event):
         self.bmoved = False

    def OnMotion(self, event):
         if not self.bmoved:
             return
         pos = event.GetX(), event.GetY()
         dx = pos[0]-self.pos[0]
         dy = pos[1]-self.pos[1]
         pos = self.bmp.GetPosition()
         pos = pos[0]+dx, pos[1]+dy
         self.bmp.SetPosition(pos)

    def OnKeyDown(self, event):
         keycode = event.GetKeyCode()
         if keycode == 49:#数字1放大
            self.SizeUp()
         elif keycode == 50:#数字2缩小
            self.SizeDown()
         event.Skip()#这个貌似很重要，要同时触发app上的快捷键

    def SizeUp(self):
         self.max_width += 50
         self.max_height += 75
         self.ShowImage(self.bmppath)
    def SizeDown(self):
         self.max_width -= 50
         self.max_height -= 75
         self.ShowImage(self.bmppath)

class PBApp(wx.App):
     
     #redirect=False将信息输出到dos界面
    def __init__(self, redirect=False):
         wx.App.__init__(self, redirect)
     
    def OnInit(self):
         
         #显示文件夹列表界面
        self.dirframe = PBDirFrame(self)
         
         #显示图片界面
        self.picframe = PBPicFrame(self)
         
         #绑定事件
        self.Bind(wx.EVT_KEY_DOWN, self.OnKeyDown)
        return True

    def ShowImage(self, path):
         #print 'showing app img', path
         self.picframe.ShowImage(path)
         self.picframe.SetFocus()
     
    def ShowNextImage(self):
         path = self.dirframe.GetNextImage()
         self.ShowImage(path)

    def ShowPreImage(self):
         path = self.dirframe.GetPreImage()
         self.ShowImage(path)

    def OnKeyDown(self, event):
         keycode = event.GetKeyCode()
         #print keycode
         if keycode == 27:# ESC键
            #切换图片窗体的显示和隐藏
            if self.picframe.IsShown():
                 self.picframe.Hide()
            else:
                 self.picframe.Show()
     
    def Close(self):
         self.picframe.Close()
     
         
def main():
     app = PBApp()
     app.MainLoop()

if __name__=='__main__':
     main()
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
# =============================================================================
# https://blog.csdn.net/aslongasyoulike/article/details/78359802
# https://blog.csdn.net/znhhxx123/article/details/53690309    
#      
# =============================================================================
try:
    del app
except:
    pass
import wx
from PIL import Image
class Myframe(wx.Frame):
    def __init__(self,filename):
        wx.Frame.__init__(self, None, -1, u'图片显示', size=(640, 640))
        self.filename='c:/temp/001.PNG'
        self.Bind(wx.EVT_SIZE, self.change)
        self.p=wx.Panel(self,-1)
        self.SetBackgroundColour('white')
    def start(self):
        self.p.DestroyChildren()#抹掉原先显示的图片
        self.width, self.height = self.GetSize()
        image = Image.open(self.filename)
        self.x, self.y = image.size
        self.x = self.width / 2 - self.x / 2
        self.y = self.height / 2 - self.y / 2
        self.pic = wx.Image(self.filename, wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        # 通过计算获得图片的存放位置
        self.button = wx.BitmapButton(self.p, -1, self.pic, pos=(self.x, self.y))
        self.p.Fit()
    def change(self, size):#如果检测到框架大小的变化，及时改变图片的位置
        if self.filename != "":
            self.start()
        else:
            pass
app=wx.PySimpleApp()
frame=Myframe('pig.jpg')
frame.start()
frame.Center()
frame.Show()
app.MainLoop()

   
     
     
     
     
     
     
     
     
     
     
     
     