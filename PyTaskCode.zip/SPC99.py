# -*- coding: utf-8 -*-
"""
Created on Thu Dec 27 10:00:30 2018

@author: HUANGWEI45
"""


import pandas as pd
import matplotlib.pyplot as plt

import matplotlib.dates as mdates

import matplotlib.lines as mlines





def plot_chart(tmp,name,title,lsl,usl,lwl,uwl,fz,fzcl):
      
    tools =  tmp['ToolID'].unique()
    if  len(tools) % 2 != 0:
        n = len(tools) // 2 + 1
    else:
        n = len(tools) // 2
        
    fig = plt.figure(figsize = (16,n*4))   
        
    for i, tool in enumerate(tools):      
        df = tmp[tmp['ToolID']==tool]
        ax = plt.subplot(n,2,i+1)
        x = df['Date']
        y = df['Data']
        y1 = df['Sigma']
        
        if name == 'K99TXRWS02' and 'AMXR01 WSI X' in title:  #specila chart ,sigma is the actual value
            y = df['Sigma']
            
        if name == 'C99CXR0101' and 'AMXR01 P' in title:  #specila chart ,sigma is the actual value
            y = df['Sigma']  
            
            
        #ax.bar(x,y,color='g',alpha = 1,width = 0.1)
        ax.plot(x,y,color = 'r',linestyle='',marker = "*")
        
        if fz == 'Y':
            ax1 = ax.twinx()
            ax1.plot(x,y1,color='b',linestyle=':',marker = '+',linewidth=1)
            ax1.set_ylim(0, fzcl)
            #ax1.set_yticks([0,2,4,6,8,10])
        
        plt.title(tool + "_" + title)
        ax.set_ylim(lwl ,uwl )
   

        #if uwl == '':
        #    ax.set_ylim(lwl ,uwl )
        #else:
        #    if lwl=='':
        #        ax.set_ylim(0,uwl)
        #    else:
        #        ax.set_ylim(lwl,uwl)
       
        ax.grid(True, linestyle='-')
        
        ax.set_xticklabels(x,rotation=45)
       
        
   
        #line = mlines.Line2D(x,[2 for i in range(len(X))],lw=3.,ls='-',alpha=1,color='red')
        x= list(x)
        if lwl != 0:
            y = [ lsl for i in range(len(x))]
            line = mlines.Line2D(x,y,lw=2.,ls='--',alpha=1,color='g')
            ax.add_line(line)
        
        
        y = [ usl for i in range(len(x))]
        line = mlines.Line2D(x,y,lw=2.,ls='--',alpha=1,color='g')
        ax.add_line(line)
        
        
        
        #ax.set_xticks(pd.date_range(x[0],x[-1],freq='W'))
        
        plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%m/%d/%Y'))
        #plt.gca().xaxis.set_major_locator(mdates.DayLocator())
        #plt.gcf().autofmt_xdate()  # 自动旋转日期标记
    fig.subplots_adjust(hspace=0.5)
    title = title.replace(' ','_')
    plt.savefig('z:\\_DailyCheck\\SPC99\\' + name + "_" + title,dpi=200, bbox_inches='tight')  
    
    #plt.show()


    
        
        
 
        






















































def main():

    path = 'y:/spc99/spc99.xlsm'
    
    raw = pd.read_excel(path,sheet_name = 'Summary',header = 0)
    
    raw = raw.sort_values(by = 'Date')
    
    config = pd.read_excel(path,sheet_name = 'Config',header = 0)
    config =  config[['Chart', 'Title', 'LSL', 'Target', 'USL', 'LWL', 'UWL', 'Ax2', 'Ax2CL']]
    config = config.fillna('')
    
    for i  in range(config.shape[0]):
    #for i  in range(10):        
        name = config.iloc[i][0]
        title = config.iloc[i][1]
        lsl = config.iloc[i][2]
        usl = config.iloc[i][4]
        lwl = config.iloc[i][5]
        uwl = config.iloc[i][6]
        fz = config.iloc[i][7]
        fzcl = config.iloc[i][8]
        
        
        
        
        tmp = raw[raw['ChartID']==name]
        
        if tmp.shape[0]>0:
            print(name,title,lsl,usl,lwl,uwl,fz,fzcl)
            try:
                plot_chart(tmp,name,title,lsl,usl,lwl,uwl,fz,fzcl)
            except:
                print('ERROR_' + name)
    
    
    
    
if __name__=="__main__":
    main()
    
    
    
    
    
    
    
    
    
    
    
    
    
'''    
 Vfrom datetime import datetime

import matplotlib.dates as mdates
import matplotlib.pyplot as plt

# 生成横纵坐标信息
dates = ['01/02/1991', '01/03/1991', '01/04/1991']
xs = [datetime.strptime(d, '%m/%d/%Y').date() for d in dates]
ys = range(len(xs))
# 配置横坐标
plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%m/%d/%Y'))
plt.gca().xaxis.set_major_locator(mdates.DayLocator())
# Plot
plt.plot(xs, ys)
plt.gcf().autofmt_xdate()  # 自动旋转日期标记
plt.show()
--------------------- 
作者：BrownWong 
来源：CSDN 
原文：https://blog.csdn.net/qq_16912257/article/details/63312174 
版权声明：本文为博主原创文章，转载请附上博文链接！   



























def dummy():
        
        gs = GridSpec(4, 1)
       
        ##########################################################
        ax1 = plt.subplot(gs[0:1, 0])
        plt.xticks(x, x1,rotation=90)
        plt.violinplot(np.array( df[['TranX_Ovl-X-Max_1','TranX_Ovl-X-Min_1','TranX_Met Value_1']].T),showmeans=False,showmedians=True)             
        ax1.yaxis.grid(True)
        ax1.set_title( 'Tran-X' +'    '+ part.upper() + '   ' + layer1.upper() + '  Y2 Axis=bias: ('+layer1.upper()+ ' Opt Value - '+layer2.upper()+' Met Value)')
        ax11  = ax1.twinx()
        plt.plot(ax1.get_xticks(), list(df['TranX_Optimum_1']-df['TranX_Met Value_2']),linewidth = '1', label = 'Opt1-Met_Value2', color='blue', linestyle=':', marker='*') 
        ##########################################################
        
        
        ax2 = plt.subplot(gs[1:2, 0])
        plt.xticks(x, list( df['Proc EqID_1']),rotation=90)
        plt.violinplot(np.array( df[['TranY_Ovl-Y-Max_1','TranY_Ovl-Y-Min_1','TranY_Met Value_1']].T),showmeans=False,showmedians=True)             
        ax2.yaxis.grid(True)
        ax2.set_title( 'Tran-Y' +'    '+ part.upper() + '   ' + layer1.upper() + '  Y2 Axis=bias: ('+layer1.upper()+ ' Opt Value - '+layer2.upper()+' Met Value)   '
                      'X-Axis: ' + layer1.upper() + ' Tool')
        ax21  = ax2.twinx()
        plt.plot(ax2.get_xticks(), list(df['TranY_Optimum_1']-df['TranY_Met Value_2']),linewidth = '1', label = 'Opt1-Met_Value2', color='blue', linestyle=':', marker='*') 
    from pylab import *
    from matplotlib.ticker import MultipleLocator, FormatStrFormatter 
    xmajorLocator  = MultipleLocator(20) #将x主刻度标签设置为20的倍数 
    xmajorFormatter = FormatStrFormatter('%1.1f') #设置x轴标签文本的格式 
    xminorLocator  = MultipleLocator(5) #将x轴次刻度标签设置为5的倍数 
    ymajorLocator  = MultipleLocator(0.5) #将y轴主刻度标签设置为0.5的倍数 
    ymajorFormatter = FormatStrFormatter('%1.1f') #设置y轴标签文本的格式 
    yminorLocator  = MultipleLocator(0.1) #将此y轴次刻度标签设置为0.1的倍数 
    t = arange(0.0, 100.0, 1) 
    s = sin(0.1*pi*t)*exp(-t*0.01) 
    ax = subplot(111) #注意:一般都在ax中设置,不再plot中设置 
    plot(t,s,'--b*') 
    #设置主刻度标签的位置,标签文本的格式 
    ax.xaxis.set_major_locator(xmajorLocator) 
    ax.xaxis.set_major_formatter(xmajorFormatter) 
    ax.yaxis.set_major_locator(ymajorLocator) 
    ax.yaxis.set_major_formatter(ymajorFormatter) 
    #显示次刻度标签的位置,没有标签文本 
    ax.xaxis.set_minor_locator(xminorLocator) 
    ax.yaxis.set_minor_locator(yminorLocator) 
    ax.xaxis.grid(True, which='major') #x坐标轴的网格使用主刻度 
    ax.yaxis.grid(True, which='minor') #y坐标轴的网格使用次刻度 
            #ymajorFormatter = FormatStrFormatter('%1i') #设置y轴标签文本的格式
        #ax.yaxis.set_major_formatter(ymajorFormatter) 
        #ymajorLocator  = MultipleLocator(1) #将y轴主刻度标签设置为1的倍数
        #ax.yaxis.set_major_locator(ymajorLocator) 
        #yminorFormatter = FormatStrFormatter('%1i') #设置y轴标签文本的格式
        #ax.yaxis.set_minor_formatter(yminorFormatter) 
        
        
        chart = ['L99P000101','L99P000103','L99P000701','L99P000703','L99P00A101','L99P00A201','L99P00W101','L99PPDT301','L99P000501','L99DTR0601','L99DTR0501','M99PYE0101','M99DTRQ801']

chart = ['L99P000701','L99P000703','M99DTRQ801']
#chart =['M99DTRQ801']

ChartTitle = { 'L99P000701':'Particle:0-20>0.2um',
              'L99P000703':'Particle:0-10>1.0um',
              'M99DTRQ801':'Particle:0-10>0.2um'}
'''    