# -*- coding: utf-8 -*-
"""
Created on Fri Aug  3 10:57:57 2018

@author: HUANGWEI45
"""

# -*- coding: utf-8 -*-
"""
Created on Thu May  3 11:54:31 2018

@author: HUANGWEI45
"""

# NIKON RECIPE CHECK
# Only datetime only
#  P:\_DailyCheck\NikonRecipe

import os
import pandas as pd
import time
import datetime
import numpy as np
import xlwings as xw
import win32com.client


def get_path(FileDir =r'P:\SEQLOG\macconst' ):
#list batchreport filename in specified directory    
    filenamelist=[]
    for root, dirs, files in os.walk(FileDir, False):  #root:所有目录名-->字符串 #dirs: root下的子目录名-->列表 #files：root下的文件名-->列表 # name.endswith(ext)-->文件名筛选 
        for names in files:
            
            
            filenamelist.append( FileDir + '\\' + names)

    filenamelist.sort(reverse = False)
    
    
    return (filenamelist)
    




def MacAdjust():
    filelist = get_path(FileDir =r'P:\SEQLOG\macadjust' )
    data11=[]
    data14=[]
    for file in filelist:
        print(file)
        
        try: 
            input = open(file)            
            tmp   = [eval(line.split('=')[1].strip())   \
                    for line in input  \
                    if "=" in line and "sas_name" not in line  ]                                                                        
            tmp.append(file.split('.')[1])
            tmp.append(str(datetime.date.today()))
            if file[31:34]=='230':
                data11.append(tmp)
            else:
                data14.append(tmp)
           

        except:
            pass    
        
 
    
    pd.DataFrame(data11).to_csv('Y:/NikonPara/Adjust11.csv', \
            index=False,header=False,mode = 'a')
    pd.DataFrame(data14).to_csv('Y:/NikonPara/Adjust14.csv', \
            index=False,header=False,mode = 'a')



def MacConst():
    filelist = get_path(FileDir =r'P:\SEQLOG\macconst' )
    data11=[]
    data14=[]
    
    for file in filelist:
        print(file)
        
        try: 
            input = open(file)            
            tmp   = [(line.split('=')[1].strip())  for line in input  \
                     if "=" in line and '!' not in line ]
                                                                                 
            tmp.append(file.split('.')[1])
            tmp.append(str(datetime.date.today()))
            if file[29:32]=='241':
                data11.append(tmp)
            else:
                data14.append(tmp)
            
           

        except:
            pass    
    pd.DataFrame(data11).to_csv('Y:/NikonPara/Const11.csv', \
            index=False,header=False,mode = 'a')
    pd.DataFrame(data14).to_csv('Y:/NikonPara/Const14.csv', \
            index=False,header=False,mode = 'a')    
 
    
    
    
def SYSparam():
    filelist = get_path(FileDir =r'P:\SEQLOG\SYSparam' )
    data11=[]
    data11B=[]
    data14=[]
    for file in filelist:
        print(file)
        try: 
            input = open(file)            
            tmp   = [(line.split('=')[1].strip())  for line in input  \
                     if "=" in line and '!' not in line ]
                                                                                 
            tmp.append(file.split('.')[1])
            tmp.append(str(datetime.date.today()))

            if file[29:33]=='242.':
                data11.append(tmp)
            elif file[29:33]=='242B':
                data11B.append(tmp)
            else:
                data14.append(tmp)
       
           

        except:
            pass    
    pd.DataFrame(data11).to_csv('Y:/NikonPara/SysParam11.csv', \
            index=False,header=False,mode = 'a')
    
    pd.DataFrame(data11B).to_csv('Y:/NikonPara/SysParam11B.csv', \
            index=False,header=False,mode = 'a')    
    
    pd.DataFrame(data14).to_csv('Y:/NikonPara/SysParam14.csv', \
            index=False,header=False,mode = 'a')    

if __name__ == "__main__":
    MacAdjust()
    tmp = open(r'C:\anaconda3\log.txt','a')
    tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___005-NikonPara.MacAdjust  Done\n")
    tmp.close()
    
    
    MacConst()
    tmp = open(r'C:\anaconda3\log.txt','a')
    tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___006-NikonPara.MacConst  Done\n")
    tmp.close() 
    
    SYSparam()
    tmp = open(r'C:\anaconda3\log.txt','a')
    tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___007-NikonPara.SYSparam  Done\n")
    tmp.close() 
