# -*- coding: utf-8 -*-
"""
Created on Wed May 16 13:37:56 2018

@author: HUANGWEI45
"""
import os
import time
import datetime

import shutil

#shutil.copy(os.path.join(srcPath,idx+'.jpg'), destDir)

#tmp = os.path.getmtime("p:/Dailykchart.xls")
#tmp = time.localtime(tmp)
#tmp = time.strftime('%Y-%m-%d',tmp)

#if tmp == str(datetime.datetime.now().date()):
#    shutil.copy( 'p:/Dailykchart.xls', 'p:/_DailyCheck/DailyChart/' + tmp + '_Kchart.xls')
    
    
#tmp = os.path.getmtime("P:/RoutineWork/ScriptSaving.xlsx")
#tmp = time.localtime(tmp)
#tmp = time.strftime('%Y-%m-%d',tmp)

#if tmp == str(datetime.datetime.now().date()):
#    shutil.copy( 'p:/Dailykchart.xls', 'p:/_DailyCheck/OptOvl_Others/' + tmp + '_OptOvl_etc.xlsx')
    
def FileCopy():
    tmp =str( datetime.datetime.now().date() )
        
    if os.path.exists("P:/CD/CDrecipe" + tmp + ".xls" ):
        shutil.copy( "P:/CD/CDrecipe" + tmp + ".xls", 'z:/_DailyCheck/CDRecipe/CDRecipe' + tmp + ".xls")
        
            
if __name__ == "__main__":
    FileCopy()        