# -*- coding: utf-8 -*-
"""
Created on Mon Sep 10 16:58:30 2018

@author: HUANGWEI45
"""

import pandas as pd
import matplotlib.pyplot as plt
import os

def get_filename(folder = 'P:/SEQLOG/ALII01'):
    
    filenamelist=[]
    for root, dirs, files in os.walk(folder, False):  #root:所有目录名-->字符串 #dirs: root下的子目录名-->列表 #files：root下的文件名-->列表 # name.endswith(ext)-->文件名筛选 
        for names in files:
            if names.endswith('.TXT'):
                filenamelist.append( root  + '/' + names) 
    filenamelist.sort(reverse = False)
    return (filenamelist)



def read_data():

    filelist = get_filename(folder = 'P:/SEQLOG/')
    Summary = pd.DataFrame(columns=['X','Y','Tool','Type'])
    
    for file in filelist:    
        if file[:14] == 'P:/SEQLOG/ALII' or file[:14] == 'P:/SEQLOG/BLII':
            try:
                os.rename(file ,file[0:31] + '.TXT' )
                filename=file[0:31] + '.TXT'
    
                if filename[-8:-6]=='09': 
                    #read data of Sep. 09,revise it for other month
                    print(filename)
                    f = open(filename)
                    l=[]
                    for i in f.readlines(): 
                        if 'FIA-SET"' in i or "BASELINE X" in i or "BASELINE Y" in i or 'LSA-SET"' in i:
                            l.append(i.strip())
                    tmp=pd.DataFrame(l)
                    
                    
                    #============================================================
                    for Sensor in [ 'FIA-SET','LSA-SET']:
                        Index = ( tmp[tmp[0].str.contains(Sensor)]  ).index
                        X_Index = [ i+1 for i in Index]
                        Y_Index = [ i+2 for i in Index]
                        
                        X = tmp.loc[X_Index][0].str.split((' '),expand=True)
                        X =( X[3].str.split(' ',expand=True))
                        Y = tmp.loc[Y_Index][0].str.split((' '),expand=True)
                        Y =( Y[5].str.split(' ',expand=True))
                        
                        Data = pd.DataFrame([list(X[0]),list(Y[0])]).T
                        Data.columns=['X','Y']
                        Data['X'] = Data['X'].astype('float')
                        Data['Y'] = Data['Y'].astype('float')
                        Date_Index = tmp[tmp[0].str.contains(Sensor)]
                        Date_Index = Date_Index[0].str.split('"',expand = True)
                        Data = Data.set_index(pd.to_datetime(Date_Index[0]))
                        Data['Tool'] = filename[10:16]
                        Data['Type'] = Sensor
                        Summary = pd.concat([Summary,Data],axis =0)
                 
       
                   
            except:
                pass

    return Summary



def plot_graph(tmp1,tool,sensor):
    print(tool,sensor)
            
    fig = plt.figure(figsize =(16,8))
    ax1 = fig.add_subplot(2,1,1)            
    ax1.plot(tmp1.index,tmp1['X'],marker='v')
    ax1.set_title(tool + ' '+ sensor +  '_X')
    ax1.yaxis.grid(True)
    plt.ylim(-0.1,0.1)
    
    ax2 = fig.add_subplot(2,1,2) 
    ax2.plot(tmp1.index,tmp1['Y'],marker='v')  
    ax2.set_title(tool + ' '+ sensor +  '_Y')
    ax2.yaxis.grid(True)            
    plt.ylim(-0.1,0.1)
            
    plt.savefig('Y:\\NikonBaseLine\\' + tool + '_' + sensor + '.jpg',dpi=100, bbox_inches='tight') 




Summary =  read_data()

Summary = Summary.drop_duplicates()
Tool = Summary['Tool'].unique()
Type = Summary['Type'].unique()


for tool in Tool:
    

    tmp = Summary[ Summary['Tool'].str.contains( tool ) ]
    for sensor in Type:
        tmp1 = tmp [tmp['Type'].str.contains (sensor )]
        if tmp1.shape[0]>1:
            

  
            tmp1['X'] = [ i-tmp1.describe().loc['mean'][0]  for i in tmp1['X']]
            tmp1['Y'] = [ i-tmp1.describe().loc['mean'][1]  for i in tmp1['Y']]
            tmp1 = tmp1.sort_index()

            plot_graph(tmp1,tool,sensor)
        
Summary = Summary.sort_index()
#Summary = Summary.sort_values(by=['Tool'])
Summary = Summary.reset_index()
Summary['index'] = [ str(i) for i in Summary['index']]
Summary['Time'] = [ str( i.split(' ')[1])[0:8] for i in Summary['index']]
Summary['index']=[str( i .split(' ')[0]) for i in Summary['index']]
Summary[['index','Time','Tool','Type','X','Y']].to_csv('Y:/NikonBaseline/NikonBaseline.csv')


