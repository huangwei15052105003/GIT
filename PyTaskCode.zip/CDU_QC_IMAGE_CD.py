# -*- coding: utf-8 -*-
"""
Created on Thu Jan  4 16:31:20 2018

@author: huangwei45
"""




'''
 5  4,4 ctr V
10  4,4 LL  V
11  4,4 LR  V
12  4,4 UR  V
13  4,4 UL  V

14  4,4 ctr H
15  4,4 LL  H
16  4,4 LR  H
17  4,4 UR  H
18  4,4 UL  H


19  4,5 ctr V
20  4,5 LL  V
21  4,5 LR  V
22  4,5 UR  V
23  4,5 UL  V


24  4,3 LL  V
25  4,3 LR  V
26  4,3 UR  V
27  4,3 UL  V

4,5
4,4
4,3



'''



import pandas as pd
import os
from PIL import Image,ImageDraw,ImageFont
import datetime
import numpy as np
#import sys

import matplotlib.pyplot as plt




def nikon_merge_image(folder):   #图片合并程序
    #toImage = Image.new('RGBA',(3072,4096))
    toImage = Image.new('RGB',(3172,2372),(255,255,255))
    
    line1 =   Image.new('RGB',(3172,100),(255,255,0))
    line2 =   Image.new('RGB',(100,2372),(255,255,0))
    
    toImage.paste(line1,(0,1136))
  
    toImage.paste(line2,(1536,0))
    
    # insert 4,5
    
    
    
    img1 = Image.open( folder + '_M0023-01MS.JPEG')
    toImage.paste(img1,(0,0))
    img1 = Image.open(folder + '_M0022-01MS.JPEG')
    toImage.paste(img1,(1024,0))
    img1 = Image.open(folder + '_M0019-01MS.JPEG')
    toImage.paste(img1,(512,312))
    img1 = Image.open(folder + '_M0020-01MS.JPEG')
    toImage.paste(img1,(0,624))
    img1 = Image.open(folder + '_M0021-01MS.JPEG')
    toImage.paste(img1,(1024,624))
    
  # insert 4,3 vertical
    img1 = Image.open(folder + '_M0027-01MS.JPEG')
    toImage.paste(img1,(1636,0))
    img1 = Image.open(folder + '_M0026-01MS.JPEG')
    toImage.paste(img1,(2660,0))
    #toImage.paste(img1,(2298,512))
    img1 = Image.open(folder + '_M0024-01MS.JPEG')
    toImage.paste(img1,(1636,624))
    img1 = Image.open(folder + '_M0025-01MS.JPEG')
    toImage.paste(img1,(2660,624))    
    
    
    
    
    
    
    
    
    # insert 4,4 vertical
    img1 = Image.open(folder + '_M0013-01MS.JPEG')
    toImage.paste(img1,(0,1236))
    img1 = Image.open(folder + '_M0012-01MS.JPEG')
    toImage.paste(img1,(1024,1236))
    img1 = Image.open(folder + '_M0005-01MS.JPEG')
    toImage.paste(img1,(512,1548))
    img1 = Image.open(folder + '_M0010-01MS.JPEG')
    toImage.paste(img1,(0,1860))
    img1 = Image.open(folder + '_M0011-01MS.JPEG')
    toImage.paste(img1,(1024,1860))
    
    
    # insert 4,4 horzintal
    img1 = Image.open(folder + '_M0018-01MS.JPEG')
    toImage.paste(img1.transpose(Image.ROTATE_90),(1636,1236))
    img1 = Image.open(folder + '_M0017-01MS.JPEG')
    toImage.paste(img1.transpose(Image.ROTATE_90),(2660,1236))
    img1 = Image.open(folder + '_M0014-01MS.JPEG')
    toImage.paste(img1.transpose(Image.ROTATE_90),(2148,1548))
    img1 = Image.open(folder + '_M0015-01MS.JPEG')
    toImage.paste(img1.transpose(Image.ROTATE_90),(1636,1860))
    img1 = Image.open(folder + '_M0016-01MS.JPEG')
    toImage.paste(img1.transpose(Image.ROTATE_90),(2660,1860))
    
    
    setfont = ImageFont.truetype('simsun.ttc',48)
    fillcolor = (0,0,0)
    draw = ImageDraw.Draw(toImage)
    
    draw.text((650,50),'Shot(4,5)',fill=fillcolor,font=setfont)
    draw.text((512,100),'Norminal Focus +0.2um',fill=fillcolor,font=setfont)
    draw.text((588,150),'B1,B2,B8,BH,E1',fill=fillcolor,font=setfont)    
    
    
    draw.text((2286,50),'Shot(4,3)',fill=fillcolor,font=setfont)
    draw.text((2148,100),'Norminal Focus -0.2um',fill=fillcolor,font=setfont)
    draw.text((2224,150),'B1,B2,B8,BH,E1',fill=fillcolor,font=setfont) 
    
    
    draw.text((660,1286),'Ctr Shot',fill=fillcolor,font=setfont)
    draw.text((586,1386),'Norminal Focus',fill=fillcolor,font=setfont)
    draw.text((650,1336),'Shot(4,4)',fill=fillcolor,font=setfont)
    
    
    draw.text((2296,1286),'Ctr Shot',fill=fillcolor,font=setfont)
    draw.text((2222,1386),'Norminal Focus',fill=fillcolor,font=setfont)    
    draw.text((2286,1336),'Shot(4,4)',fill=fillcolor,font=setfont)
  
  
  
 
    tmp = folder.split('\\')
    toImage.save('P:\\temp\\NikonShot\\transfer\\' + tmp[6] + '_' + tmp[7] + '.jpg')

    #r,g,b,a = toImage.split()
    #toImage = Image.merge("RGB",(r,g,b))

    #toImage.save('P:\\temp\\NikonShot\\transfer\\' + tmp[6] + '_' + tmp[7] + '.png')

def asml_merge_image(folder):   #图片合并程序
    print(folder)
    #toImage = Image.new('RGBA',(3072,4096))
    toImage = Image.new('RGB',(4096,1044),(255,255,255))
    
   
    

    
    # insert within wafer 2,3,4,5,6,7,8,9
    
    
    
    img1 = Image.open(folder + '_M0002-01MS.JPEG')
    toImage.paste(img1,(0,0))
    img1 = Image.open(folder + '_M0003-01MS.JPEG')
    toImage.paste(img1,(512,0))
    img1 = Image.open(folder + '_M0004-01MS.JPEG')
    toImage.paste(img1,(1024,0))
    img1 = Image.open(folder + '_M0005-01MS.JPEG')
    toImage.paste(img1,(1536,0))
    img1 = Image.open(folder + '_M0006-01MS.JPEG')
    toImage.paste(img1,(2048,0))
    img1 = Image.open(folder + '_M0007-01MS.JPEG')
    toImage.paste(img1,(2560,0))
    img1 = Image.open(folder + '_M0008-01MS.JPEG')
    toImage.paste(img1,(3072,0))
    img1 = Image.open(folder + '_M0009-01MS.JPEG')
    toImage.paste(img1,(3584,0))
    
    
    # insert within shot 1,10,11,12,13
    img1 = Image.open(folder + '_M0001-01MS.JPEG')
    toImage.paste(img1,(1536,532))
    img1 = Image.open(folder + '_M0010-01MS.JPEG')
    toImage.paste(img1,(2048,532))
    img1 = Image.open(folder + '_M0011-01MS.JPEG')
    toImage.paste(img1,(2560,532))
    img1 = Image.open(folder + '_M0012-01MS.JPEG')
    toImage.paste(img1,(3072,532))
    img1 = Image.open(folder + '_M0013-01MS.JPEG')
    toImage.paste(img1,(3584,532))

    
  
    
    
    
    
    
    
    
    
   
    
    
    
    
    
    setfont = ImageFont.truetype('simsun.ttc',72)
    fillcolor = (0,0,0)
    draw = ImageDraw.Draw(toImage)
    
    draw.text((10,532),'Row-1: center L-Bar within wafer',fill=fillcolor,font=setfont)
    draw.text((10,632),'Row-2: L-Bar within shot-->Ctr,LL,LR,UL,UR',fill=fillcolor,font=setfont)
    
    

  
  
  
 
    tmp = folder.split('\\')
    #toImage.save('p:\\temp\\NikonShot\\transfer\\' + tmp[3] + '_' + tmp[4] + '.jpg')
    toImage.save('p:\\temp\\NikonShot\\transfer\\' + tmp[6] + '_' + tmp[7] + '.jpg')

def complete_collection():   #已完成合并的图片名
    finish_merge = []
    for root,dirs,files in os.walk('p:\\temp\\nikonshot\\transfer',False):
        for name in files:
            finish_merge.append(name)
    return finish_merge




def YE_folderlist(begin,end):  # n天内的图片目录
    print( '=== folder lists of YE images server being extracted.........===')
    folderlist = []
    full = []
    for n in range(begin,end):        
        datestr = ( datetime.datetime.today() - datetime.timedelta(days=n) ).strftime("%Y%m%d")
        print(datestr)
        
        foldername =  'D:\\ftpimages\\' + datestr  
        foldername = '\\\\10.4.72.182\\d\\ftpimages\\' + datestr
        
            
        for root,dirs,files in os.walk(foldername,False):
            for name in dirs:
                full.append(root + '\\' + name + '\\')
                if '2LXXX' in name:
                    folderlist.append(root + '\\' + name + '\\')
    pd.DataFrame(folderlist).to_csv('p:\\temp\\nikonshot\\folderlist.csv',mode='a',header=False, index=False)
    pd.DataFrame(full).to_csv('p:\\temp\\nikonshot\\fulllist.csv',mode='a',header=False, index=False)
    
    tmp = pd.read_csv('p:\\temp\\nikonshot\\folderlist.csv',header=None)
    pd.DataFrame ( tmp[0].unique()  ).to_csv('p:\\temp\\nikonshot\\folderlist.csv',index=False)
    
    tmp = pd.read_csv('p:\\temp\\nikonshot\\fulllist.csv',header=None)
    pd.DataFrame ( tmp[0].unique()  ).to_csv('p:\\temp\\nikonshot\\fulllist.csv',index=False)    
    
    
    return folderlist
    
  

def folderFinish(folder,finish_merge):  #判断YE_folderlist()中已完成贴图的目录
    flag = True
    tmp = folder.split('\\')[4]
    for i in finish_merge:
        if tmp in i:
            flag = False
    return flag
            


def cd_measure_done(): #list image folders completed measurment
    df = pd.read_csv('p:\\temp\\nikonshot\\cd.csv')    
    tmp = [i[0:-19] for i in list (df['Path']) ]        
    imgdone = set(  tmp )
    return imgdone
        


def read_img(picture_path):
    tmp_img = Image.open(picture_path)
    #tmp_img.show() #显示读入的图片
    
    
    region = tmp_img.crop((60,136,452,352)) #图片尺寸512*512，截取部分选择一块区域
    #region = tmp_img.crop((143,136,460,352)) #选择一块区域
    #region.show()
    
    arr = np.array( region.convert('L') )
    
    
    
    #图片上有点状线，自Y=0开始，间隔8个像素，需去除
    tmp1 = [i+8 for i in range(8)]
    tmp2 = [i for i in range(13)]
    tmp3 = []
    for i in tmp2:
        for j in tmp1:
            tmp3.append( i * 16 + j )
    newarr = np.delete(arr,tmp3,axis=0) #axia=0 删除X轴方向，axis=1 删除Y轴方向
    return newarr,arr


def sepr602_read_img(picture_path):
    tmp_img = Image.open(picture_path)
    #tmp_img.show() #显示读入的图片
    
    
    region = tmp_img.crop((90,0,422,55)) #图片尺寸512*512，截取部分选择一块区域    
  

    #region.show()
    
    arr = np.array( region.convert('L') )
    newarr = arr
    
    
    
    #图片上十字线，自Y=0开始，间隔8个像素，需去除        
    
 
    return newarr,arr







    
    
def moving_average(newarr,n):    
    #图片数据平坦化
    #n=13

    newarr = newarr[0] # 调用的newarr是个list,内容分别是去除测试虚线的图像矩阵和原始数据
    a = newarr.shape[0]
    b = newarr.shape[1]-n+1
    
    #零值矩阵
    img = np.zeros([a,b],dtype='int32') #导出的图像矩阵数据格式为int8，若零矩阵格式仍为int8，后续移动平均计算会溢出
    
    #移动平均，只累加，不平均
    tmp1 = [n-i-2 for i in range(n-1)]
    k = newarr.shape[1]
    for i in range(n):    
        tmp2=tmp1.copy()    
        if i == 0:
            pass
        else:
            for j in range(i):
                tmp2[j] = k -j-1
        

        img = img + np.delete(newarr,tmp2,axis=1)
  
    #检查图片，正常步骤省
    img =img / n *1.0  
    return img


def calculate_cd(img,threshold=0.25,differential=7):
    img_avg = np.mean(img,axis=0)#按列计算
    #newarr_avg = np.mean(newarr,axis=0)#按列计算
    
    #求导
    #dxdy = np.delete(img_avg,0) - np.delete(img_avg,-1)
    
    tmp1 = img_avg
    tmp2 = img_avg
    for i in range(differential-1):
        tmp1 = np.delete(tmp1,0)
        tmp2 = np.delete(tmp2,-1)
    dxdy =( tmp1-tmp2) / (differential-1)
        
    
    
    
    #显示信号曲线和微分曲线
    #plt.plot(img_avg)
    #plt.show()
    #plt.plot(dxdy)
    #plt.show()
    #plt.plot(dxdyn)
    #plt.show()    
    
    df = pd.DataFrame(dxdy)
    #df_left = df.iloc[0:int (df.shape[0] / 2)].sort([0],ascending=True)
    df_left = df.iloc[0:int (df.shape[0] / 2)].sort_values(by=[0],ascending=True)
    
    #df_right = df.iloc[int (df.shape[0] / 2): ].sort([0],ascending=True)
    df_right = df.iloc[int (df.shape[0] / 2): ].sort_values (by = [0],ascending=True)    
    
    
    a = df_left.index[-1]
    b = df_left.index[0]
    c = df_right.index[-1]
    d = df_right.index[0]
    
 

    cd1 = df[0][a]
    cd2 = df[0][b]
    cd3 = df[0][c]
    cd4 = df[0][d]
    
  
    tmp = df[30:a+1]
    #print(tmp)
    tmp = list(tmp.sort_index(ascending=False)[0])
    for i,value in enumerate(tmp):
        if value < threshold * cd1:          
            x1 = a-i
            y1 = tmp[i]
            x2 = a - (i - 1)
            y2 = tmp [i-1]
            #print(x1,y1,x2,y2,threshold*cd1)
            k1 = (y2-y1)/(x2-x1)
            k2 =  y2 - k1 * x2
            ta = (threshold * cd1 - k2 ) / k1            
            #print('ta = ',ta)
            break
            
            
                
    tmp = df[b:int( (c-b)/2)+b]
    #print(tmp)
    tmp = list(tmp[0])
    for i,value in enumerate(tmp):
        
        if value > threshold * cd2:
            x1 = b + i
            y1 = tmp[i]
            x2 = b + (i - 1)
            y2 = tmp [i-1]
            #print(x1,y1,x2,y2,threshold*cd2)
            k1 = (y2-y1)/(x2-x1)
            k2 =  y2 - k1 * x2
            tb = (threshold * cd2 - k2 ) / k1
            #print('tb = ',tb)                                                
            break
    
    
    

    tmp = df[int( (c-b)/2)+b:c+1]
    #print(tmp)    
    tmp = list(tmp.sort_index(ascending=False)[0])    
    for i,value in enumerate(tmp):
        if value < threshold * cd3:          
            x1 = c-i
            y1 = tmp[i]
            x2 = c - (i - 1)
            y2 = tmp [i-1]
            #print(x1,y1,x2,y2,threshold*cd3)
            k1 = (y2-y1)/(x2-x1)
            k2 =  y2 - k1 * x2
            tc = (threshold * cd3 - k2 ) / k1
            #print('tc = ',tc) 
            break    
    
    
     
 
 
    tmp = df[d:350]
    #print(tmp)
    tmp = list(tmp[0])
    for i,value in enumerate(tmp):
        
        if value > threshold * cd4:
            x1 = d + i
            y1 = tmp[i]
            x2 = d + (i - 1)
            y2 = tmp [i-1]
            #print(x1,y1,x2,y2,threshold*cd4)
            k1 = (y2-y1)/(x2-x1)
            k2 =  y2 - k1 * x2
            td = (threshold * cd4 - k2 ) / k1
            #print('td = ',td)                                                
            break
 
 
 
 
 
    
    line_cd = d-a
    space_cd = c-b
    left_boundary = b-a
    right_boundary = d-c
    
    try:
        line_cd1 = td-ta
    except:
        line_cd1 = 888
    
    
    try:
        space_cd1 = tc-tb
    except:
        space_cd1 = 888
    
    
    try:
        left_boundary1 = tb-ta
    except:
        left_boundary1 = 888
        
    try:
        right_boundary1 = td-tc
    except:
        right_boundary1 = 888
    
    #print(cd1,cd2,cd3,cd4)
    
    #print(a,b,c,d)    
    #print(line_cd,space_cd,left_boundary,right_boundary)
    #print(ta,tb,tc,td)
    #print(line_cd1,space_cd1,left_boundary1,right_boundary1)
        
    
    

    cddata = [line_cd,space_cd,left_boundary,right_boundary,line_cd1,space_cd1,left_boundary1,right_boundary1]
  
    return cddata












  

def nikon_image_cd(folderlist,finish_merge,imgdone):
    


    

    count = 0            
    filename = {'_M0005-01MS.JPEG','_M0010-01MS.JPEG','_M0011-01MS.JPEG','_M0012-01MS.JPEG','_M0013-01MS.JPEG',
                '_M0014-01MS.JPEG','_M0015-01MS.JPEG','_M0016-01MS.JPEG','_M0017-01MS.JPEG','_M0018-01MS.JPEG',
                '_M0019-01MS.JPEG','_M0020-01MS.JPEG','_M0021-01MS.JPEG','_M0022-01MS.JPEG','_M0023-01MS.JPEG',
                '_M0024-01MS.JPEG','_M0025-01MS.JPEG','_M0026-01MS.JPEG','_M0027-01MS.JPEG' }            
                
                
    cdfile = ['_M0005-01MS.JPEG','_M0010-01MS.JPEG','_M0011-01MS.JPEG','_M0012-01MS.JPEG','_M0013-01MS.JPEG',
                    '_M0014-01MS.JPEG','_M0015-01MS.JPEG','_M0016-01MS.JPEG','_M0017-01MS.JPEG','_M0018-01MS.JPEG' ]
                    
    direction =  {'_M0005-01MS.JPEG':'Vertical','_M0010-01MS.JPEG':'Vertical','_M0011-01MS.JPEG':'Vertical','_M0012-01MS.JPEG':'Vertical','_M0013-01MS.JPEG':'Vertical',
                    '_M0014-01MS.JPEG':'Horizontal','_M0015-01MS.JPEG':'Horizontal','_M0016-01MS.JPEG':'Horizontal','_M0017-01MS.JPEG':'Horizontal','_M0018-01MS.JPEG':'Horizontal' }

                
                                                                   

   
    csv_output=[]  
    
#Nikon#Nikon#Nikon#Nikon#Nikon#Nikon#Nikon#Nikon#Nikon#Nikon#Nikon#Nikon#Nikon#Nikon#Nikon#Nikon#Nikon#Nikon#Nikon#Nikon#Nikon#Nikon#Nikon#Nikon#Nikon   
#判断目录中文件是否全==========================================
    nikonfolderlist = [ tmp for tmp in folderlist if '2LXXXSCD' in tmp]    
    for folder in nikonfolderlist:
        print(folder)       
        imgnameset = []
        for root,dirs,files in os.walk(folder,False):
            for name in files:
                imgnameset.append( name[3:].upper())   #文件名出去除片号,全部大写
            
        imgnameset= set(imgnameset)             #列表转集合
        imgflag  = filename.issubset(imgnameset) #判断是否是子集，即文件是否全
        wfrno = name[0:3]

        #print(imgnameset)




        
# Merge picture===========================================
        folderflag = folderFinish(folder,finish_merge)   #判断YE目录中图片是否已处理  
        if folderflag == True and imgflag == True:
            pass
            folder1 = folder + wfrno     #folder名改为目录+圆片号，也将用于cd               
            nikon_merge_image( folder1 )
        
# check CD============================================================================== 
           
        if folder not in imgdone and imgflag == True:
            for file in cdfile:
                
            
                count += 1
                folder1 = folder + wfrno     #重新调用，因调试中Merge Picture不做，不被定义
                picture_path = folder1 + file 
                print(picture_path)
                newarr = read_img( picture_path  )#返回的newarr是个list,内容分别是去除测试虚线的图像矩阵和原始数据
                                                         #newarr[0]供后续移动平均，CD计算
                                                         #newarr[1]供计算在线实际CD
                #calculate real cd
                realcd = pd.DataFrame(newarr[1])
                #realcd = realcd.describe().T.sort(['std'],ascending = False)
                realcd = realcd.describe().T.sort_values(by = ['std'],ascending = False)
                realcd = abs ( realcd.index[0]-realcd.index[1] )
                        
                n= 7
                img = moving_average(newarr,n)   #函数中调用newarr[0]处理数据
                cd_data = calculate_cd(img,threshold=0.25,differential=7) 
                       
                      
                cd_data.append(realcd)
                cd_data.append( folder1 + file )
                #cd_data.append ( folder.split("\\")[4].split('_')[0] + ' '  + folder.split("\\")[4].split('_')[1] )
                cd_data.append ( folder.split("\\")[7].split('_')[0] + ' '  + folder.split("\\")[7].split('_')[1] )                
                cd_data.append(folder.split('_')[3]+'.1')                
                cd_data.append( direction[ file] )
                print(cd_data)
                csv_output.append(cd_data)
                if count >5:
                    #break
                    pass
                    #sys.exit(0)
        if count >5:
            pass
            #break
  
    
    tmp = pd.DataFrame(csv_output)
    tmp.to_csv('p:\\temp\\nikonshot\\cd.csv',mode='a',header=False, index=False)


def asml_image_cd(folderlist,finish_merge,imgdone):
    
    count = 0            
    filename = {'_M0001-01MS.JPEG','_M0002-01MS.JPEG','_M0003-01MS.JPEG','_M0004-01MS.JPEG','_M0005-01MS.JPEG',
                '_M0006-01MS.JPEG','_M0007-01MS.JPEG','_M0008-01MS.JPEG','_M0009-01MS.JPEG','_M0010-01MS.JPEG',
                '_M0011-01MS.JPEG','_M0012-01MS.JPEG','_M0013-01MS.JPEG' }            
                
                
    cdfile = ['_M0001-01MS.JPEG','_M0010-01MS.JPEG','_M0011-01MS.JPEG','_M0012-01MS.JPEG','_M0013-01MS.JPEG']
                    
    direction =  {'_M0001-01MS.JPEG':'Vertical','_M0010-01MS.JPEG':'Vertical','_M0011-01MS.JPEG':'Vertical',
                  '_M0012-01MS.JPEG':'Vertical','_M0013-01MS.JPEG':'Vertical'}

                
                                                                   

   
    csv_output=[]  
    
#ASML#ASML#ASML#ASML#ASML#ASML#ASML#ASML#ASML#ASML#ASML#ASML#ASML#ASML#ASML#ASML#ASML#ASML#ASML
#判断目录中文件是否全==========================================
    asmlfolderlist = [ tmp for tmp in folderlist if ( ('2LXXXUCD' in tmp) or ('2LXXXVCD' in tmp) ) ]   
    for folder in asmlfolderlist:
        print(folder)       
        imgnameset = []
        for root,dirs,files in os.walk(folder,False):
            for name in files:
                imgnameset.append( name[3:].upper())   #文件名出去除片号,全部大写
            
        imgnameset= set(imgnameset)             #列表转集合
        imgflag  = filename.issubset(imgnameset) #判断是否是子集，即文件是否全
        wfrno = name[0:3]

        #print(imgnameset)




        
# Merge picture===========================================
        folderflag = folderFinish(folder,finish_merge)   #判断YE目录中图片是否已处理  
        if folderflag == True and imgflag == True:
            pass
            folder1 = folder + wfrno     #folder名改为目录+圆片号，也将用于cd               
            asml_merge_image( folder = folder1 )
        
# check CD============================================================================== 
           
        if folder not in imgdone and imgflag == True:
            if 'UCD' in folder: #UV135
                for file in cdfile:
                
                    count += 1
                    folder1 = folder + wfrno     #重新调用，因调试中Merge Picture不做，不被定义
                    picture_path = folder1 + file 
                    print(picture_path)
                    newarr = read_img( picture_path  )#返回的newarr是个list,内容分别是去除测试虚线的图像矩阵和原始数据
                                                             #newarr[0]供后续移动平均，CD计算
                                                             #newarr[1]供计算在线实际CD
                    #calculate real cd
                    realcd = pd.DataFrame(newarr[1])
                    realcd = realcd.describe().T.sort_values(by=['std'],ascending = False)
                    realcd = abs ( realcd.index[0]-realcd.index[1] )
                            
                    n= 7
                    img = moving_average(newarr,n)   #函数中调用newarr[0]处理数据
                    cd_data = calculate_cd(img,threshold=0.25,differential=7) 
                           
                          
                    cd_data.append(realcd)
                    cd_data.append( folder1 + file )
                    cd_data.append ( folder.split("\\")[7].split('_')[0] + ' '  + folder.split("\\")[7].split('_')[1] )
                    cd_data.append(folder.split('_')[3]+'.1')                
                    cd_data.append( direction[ file] )
                    print(cd_data)
                    csv_output.append(cd_data)
                    if count >10:
                        #break
                        pass
                        #sys.exit(0)                    
                    
                    
            else:
                for file in cdfile: #SEPR602
                
                    count += 1
                    folder1 = folder + wfrno     #重新调用，因调试中Merge Picture不做，不被定义
                    picture_path = folder1 + file 
                    print(picture_path)
                    #multipoint的十字线无法准确去除
                    newarr = sepr602_read_img( picture_path  )#返回的newarr是个list,newarr[0]和nearr[1]内容相同，取图片最上部分

                    #assign real cd
                    realcd = 888


                            
                    n= 7
                    img = moving_average(newarr,n)   #函数中调用newarr[0]处理数据
                    cd_data = calculate_cd(img,threshold=0.25,differential=7) 
                           
                          
                    cd_data.append(realcd)
                    cd_data.append( folder1 + file )
                    cd_data.append ( folder.split("\\")[7].split('_')[0] + ' '  + folder.split("\\")[7].split('_')[1] )
                    cd_data.append(folder.split('_')[3]+'.1')                
                    cd_data.append( direction[ file] )
                    print(cd_data)
                    csv_output.append(cd_data)
                    if count >10:
                        #break
                        pass
                        #sys.exit(0)             
                
                
                
                
                

        if count >20:
            pass
            #break
  
    
    tmp = pd.DataFrame(csv_output)
    tmp.to_csv('p:\\temp\\nikonshot\\cd.csv',mode='a',header=False, index=False)




    














































if __name__ == '__main__':
    
    
    
    folderlist =YE_folderlist(begin = 0, end =3)        #指定天数内YE目录
    #folderlist = pd.read_csv(r'P:\temp\nikonshot\folderlist.csv')
    #folderlist = list (folderlist['path'])
 
    finish_merge = complete_collection() #已完成图片贴图的YE目录-->后续改为集合，简化nikon_image_cd调用时的判断
    imgdone = cd_measure_done()          #已完成CD测量的YE目录    
    nikon_image_cd(folderlist,finish_merge,imgdone)
    asml_image_cd(folderlist,finish_merge,imgdone)
    
    
    tmp = open(r'C:\anaconda3\log.txt','a')
    tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___002-CDU_IMAGE_CD Done\n")
    tmp.close()
  



#path = r'D:\ftpimages\20180116\ALCD01\20180116_220923_2LXXXVCD01-GT-LN_ALDI10CD1_1\S04_M0001-01MS.jpeg'
 

'''    
    
    
 >>> from PIL import Image
>>> im=Image.open("test.png")
>>> r,g,b,a=im.split()
>>> im=Image.merge((r,g,b))

Traceback (most recent call last):
  File "<pyshell#33>", line 1, in <module>
    im=Image.merge((r,g,b))
TypeError: merge() takes exactly 2 arguments (1 given)
>>> im=Image.merge("RGB",(r,g,b))
>>> im.save("test.bmp")
>>>    
    
    
    
    
    
'''    
    
    
'''   
path= r'D:\ftpimages\20180103\ALCD01\20180103_183516_2LXXXSCD01-A1-LN_ALIIQCCD3_1\S01_M0014-01MS.JPEG'#
path = r'D:\ftpimages\20180116\ALCD01\20180116_015451_2LXXXSCD01-A1-LN_ALIIQCCD2_1\S02_M0023-01MS.JPEG'
path = r'D:\ftpimages\20180116\ALCD01\20180116_220923_2LXXXVCD01-GT-LN_ALDI10CD1_1\S04_M0001-01MS.jpeg'
    
folder1 =  'D:\\ftpimages\\20180103\\ALCD01\\20180103_183516_2LXXXSCD01-A1-LN_ALIIQCCD3_1\\'
folder1 =  'D:\\ftpimages\\20180109\\ALCD01\\20180109_140225_2LXXXSCD01-A1-LN_ALIIQCCD1_1\\'
temp = []
for root,dirs,files in os.walk(folder1,False):
    for name in files:
        temp.append(folder1 +name)
for i in temp:
            
    newarr = read_img(i)   
    n=7
    img = moving_average(newarr,n)   #函数中调用newarr[0]处理数据
    cd_data = calculate_cd(img,threshold=0.5,differential=7) 







a=1	



#检查图片，正常步骤省略
img  = img.astype(np.int8)    
tmp = Image.fromarray(img)
tmp.show()
'''










































'''
N=11
n=np.ones(N)
weights=n/N
weights

dxdy1 = np.convolve(dxdy, weights, mode='valid')
plt.plot(dxdy)
plt.show()
print (base_img.size, base_img.mode)
box =(0, 0, 100, 100)  # 底图上需要P掉的区域

#加载需要P上去的图片
tmp_img = Image.open(r'D:\ftpimages\20180105\ALCD01\20180104_232054_2LXXXSCD01-A1-LN_ALIIQCCD3_1\S01_M0002-01MS.JPEG')
#这里可以选择一块区域或者整张图片
region = tmp_img.crop((100,100,200,200)) #选择一块区域
#或者使用整张图片
#region = tmp_img

#使用 paste(region, box) 方法将图片粘贴到另一种图片上去.
# 注意，region的大小必须和box的大小完全匹配。但是两张图片的mode可以不同，合并的时候回自动转化。如果需要保留透明度，则使用RGMA mode
#提前将图片进行缩放，以适应box区域大小
# region = region.rotate(180) #对图片进行旋转
region = region.resize((box[2] - box[0], box[3] - box[1]))
base_img.paste(region, box)
base_img.show() # 查看合成的图片
#base_img.save('./out.png') #保存图片



























def nikon_merge_image(folder):   #图片合并程序
    #toImage = Image.new('RGBA',(3072,4096))
    toImage = Image.new('RGB',(3172,2372),(255,255,255))
    
    line1 =   Image.new('RGB',(3172,100),(255,255,0))
    line2 =   Image.new('RGB',(100,2372),(255,255,0))
    
    toImage.paste(line1,(0,1136))
  
    toImage.paste(line2,(1536,0))
    
    # insert 4,5
    
    
    
    img1 = Image.open( folder + '_M0013-01MS.JPEG')
    toImage.paste(img1,(0,0))
    img1 = Image.open(folder + '_M0012-01MS.JPEG')
    toImage.paste(img1,(1024,0))
    img1 = Image.open(folder + '_M0005-01MS.JPEG')
    toImage.paste(img1,(512,312))
    img1 = Image.open(folder + '_M0010-01MS.JPEG')
    toImage.paste(img1,(0,624))
    img1 = Image.open(folder + '_M0011-01MS.JPEG')
    toImage.paste(img1,(1024,624))
    
  # insert 4,3 vertical
    img1 = Image.open(folder + '_M0027-01MS.JPEG')
    toImage.paste(img1,(1636,0))
    img1 = Image.open(folder + '_M0026-01MS.JPEG')
    toImage.paste(img1,(2660,0))
    #toImage.paste(img1,(2298,512))
    img1 = Image.open(folder + '_M0024-01MS.JPEG')
    toImage.paste(img1,(1636,624))
    img1 = Image.open(folder + '_M0025-01MS.JPEG')
    toImage.paste(img1,(2660,624))    
    
    
    
    
    
    
    
    
    # insert 4,4 vertical
    img1 = Image.open(folder + '_M0018-01MS.JPEG')
    toImage.paste(img1,(0,1236))
    img1 = Image.open(folder + '_M0017-01MS.JPEG')
    toImage.paste(img1,(1024,1236))
    img1 = Image.open(folder + '_M0014-01MS.JPEG')
    toImage.paste(img1,(512,1548))
    img1 = Image.open(folder + '_M0015-01MS.JPEG')
    toImage.paste(img1,(0,1860))
    img1 = Image.open(folder + '_M0016-01MS.JPEG')
    toImage.paste(img1,(1024,1860))
    
    
    # insert 4,4 horzintal
    img1 = Image.open(folder + '_M0023-01MS.JPEG')
    toImage.paste(img1.transpose(Image.ROTATE_90),(1636,1236))
    img1 = Image.open(folder + '_M0022-01MS.JPEG')
    toImage.paste(img1.transpose(Image.ROTATE_90),(2660,1236))
    img1 = Image.open(folder + '_M0019-01MS.JPEG')
    toImage.paste(img1.transpose(Image.ROTATE_90),(2148,1548))
    img1 = Image.open(folder + '_M0020-01MS.JPEG')
    toImage.paste(img1.transpose(Image.ROTATE_90),(1636,1860))
    img1 = Image.open(folder + '_M0021-01MS.JPEG')
    toImage.paste(img1.transpose(Image.ROTATE_90),(2660,1860))
    
    
    setfont = ImageFont.truetype('simsun.ttc',48)
    fillcolor = (0,0,0)
    draw = ImageDraw.Draw(toImage)
    
    draw.text((650,50),'Shot(4,5)',fill=fillcolor,font=setfont)
    draw.text((512,100),'Norminal Focus +0.2um',fill=fillcolor,font=setfont)
    draw.text((588,150),'B1,B2,B8,BH,E1',fill=fillcolor,font=setfont)    
    
    
    draw.text((2286,50),'Shot(4,3)',fill=fillcolor,font=setfont)
    draw.text((2148,100),'Norminal Focus -0.2um',fill=fillcolor,font=setfont)
    draw.text((2224,150),'B1,B2,B8,BH,E1',fill=fillcolor,font=setfont) 
    
    
    draw.text((660,1286),'Ctr Shot',fill=fillcolor,font=setfont)
    draw.text((586,1386),'Norminal Focus',fill=fillcolor,font=setfont)
    draw.text((650,1336),'Shot(4,4)',fill=fillcolor,font=setfont)
    
    
    draw.text((2296,1286),'Ctr Shot',fill=fillcolor,font=setfont)
    draw.text((2222,1386),'Norminal Focus',fill=fillcolor,font=setfont)    
    draw.text((2286,1336),'Shot(4,4)',fill=fillcolor,font=setfont)
  
  
  
 
    tmp = folder.split('\\')
    toImage.save('P:\\temp\\NikonShot\\transfer\\' + tmp[6] + '_' + tmp[7] + '.jpg')

    #r,g,b,a = toImage.split()
    #toImage = Image.merge("RGB",(r,g,b))

    #toImage.save('P:\\temp\\NikonShot\\transfer\\' + tmp[6] + '_' + tmp[7] + '.png')

'''


























