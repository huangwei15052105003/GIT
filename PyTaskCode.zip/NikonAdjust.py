# -*- coding: utf-8 -*-
"""
Created on Fri Dec 21 15:37:52 2018

@author: huangwei45
"""


import pandas as pd
import matplotlib.pyplot as plt
import win32com.client
import os
import sys
import numpy as np
import pandas as pd
import datetime
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import gc
import re
import matplotlib.ticker as ticker






def ovl_qc(): #NIkon OVL QC Value
    n = 120 #define time period for data extraction
    databasepath = r'Z:\_DailyCheck\Database\data.mdb'  
    
    
    enddate = datetime.datetime.now().date()
    startdate = enddate - datetime.timedelta(days=n)
    
        
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)  
    rs = win32com.client.Dispatch(r'ADODB.Recordset')
    
    



    sql = "SELECT  PartID, \
          Proc_EqID, Dcoll_Time, \
          (OffsetX_jobin + OffsetX_Met_Value) as OffsetX, \
          (OffsetY_jobin + OffsetY_Met_Value) as OffsetY, \
          (Mag_jobin + Mag_Met_Value) as Mag ,\
          (Rot_jobin + Rot_Met_Value) as Rot,OffsetX_Met_Value,OffsetY_Met_Value,Mag_Met_Value , Rot_Met_Value \
          FROM OL_Nikon WHERE ((Dcoll_Time>#" + str(startdate) + "#)  \
          and (PartID like '2LXXX%')) ORDER BY Dcoll_Time"
    rs.Open(sql, conn, 1, 3)

    ovl = []
    rs.MoveFirst()
    
    while True:
        if rs.EOF:
            break
        else:                
            ovl.append ([rs.Fields.Item(i).Value for i in range( rs.Fields.Count)] )
            rs.MoveNext()
    
    rs.close
    ovl = pd.DataFrame(ovl)
    
    ovl.columns = ['Part','Tool','Riqi','TranX','TranY','Mag','Rot','Mx','My','Mm','Mr']
    
    return ovl








def Nikno_Product_OVL():
    n = 120 #define time period for data extraction
    databasepath = r'Z:\_DailyCheck\Database\data.mdb'  
    
    
    enddate = datetime.datetime.now().date()
    startdate = enddate - datetime.timedelta(days=n)
    
        
    conn = win32com.client.Dispatch(r"ADODB.Connection")    
    DSN = 'PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = '  + databasepath
    conn.Open(DSN)  
    rs = win32com.client.Dispatch(r'ADODB.Recordset')
    
    

    
    sql = "SELECT * FROM OL_NIKON WHERE (Dcoll_Time>#" + str(startdate) + "#) ORDER BY Dcoll_Time"        
    sql = "SELECT  \
          Proc_EqID, Dcoll_Time, \
          OffsetX_Optimum, OffsetY_Optimum, ScalX_Optimum , ScalY_Optimum, \
          ORT_Optimum, Wrot_Optimum , Mag_Optimum , Rot_Optimum,  \
          Tech, Layer \
          FROM OL_NIKON WHERE (Dcoll_Time>#" + str(startdate) + "#)  and  (PartID  not like '2LXXX%') ORDER BY Dcoll_Time"        
    rs.Open(sql, conn, 1, 3) 
    
    nikon = []
    rs.MoveFirst()
    while True:
        if rs.EOF:
            break
        else:        
            nikon.append ([rs.Fields.Item(i).Value for i in range( rs.Fields.Count)] )
            rs.MoveNext()
    rs.close
    nikon = pd.DataFrame(nikon)
    
    conn.close
    nikon.columns = ['Tool','Riqi','TranX','TranY','ScalX','ScalY','Ort','Rot','SMag','SRot','Tech','Layer']
    nikon['Riqi'] =  [datetime.datetime.strptime(str(i)[0:19],'%Y-%m-%d %H:%M:%S') for i in nikon['Riqi']]


    return nikon





def LSA_FIA(tmp2):
                    
    t1 = tmp2 [tmp2['Tech'].str.contains("1") | tmp2['Tech'].str.contains("25") | tmp2['Tech'].str.contains("52") ]
    t1 = t1 [t1['Layer'].str.contains("PT") | t1['Layer'].str.contains("TB") | t1['Layer'].str.contains("HV") | \
    t1['Layer'].str.contains("NX") | t1['Layer'].str.contains("PX") | t1['Layer'].str.contains("DN") | \
    t1['Layer'].str.contains("DP")]
                
    t2 = tmp2 [ tmp2['Layer'].str.contains("A1") | tmp2['Layer'].str.contains("A2") |  tmp2['Layer'].str.contains("A3") | tmp2['Layer'].str.contains("A4") |tmp2['Layer'].str.contains("AT") | tmp2['Layer'].str.contains("TT") | \
                          tmp2['Layer'].str.contains("W1") |  tmp2['Layer'].str.contains("W2") |  tmp2['Layer'].str.contains("WT") |tmp2['Layer'].str.contains("CT")  ]
         
    fia = pd.concat([t1,t2],axis = 0).sort_index() 
    
    
    lsa = tmp2.loc [list( set(tmp2.index) -set(fia.index) )].sort_index()
    
    return lsa,fia
                   
                





















































































































I11 = 'y:/NikonPara/Adjust11.csv'
I14 = 'y:/NikonPara/Adjust14.csv'



item11 = ['Tool','Date','basadj.fia.dx_FIA Base-line Offset X:[um]',
        'basadj.fia.dy_Y:[um]','basadj.lsa.dx_LSA Base-line Offset X:[um]',
        'basadj.lsa.dy_Y:[um]','magadj.Dnocalib_Offset:[um]','basadj.Drot_Reticle Rotation:[urad]']

item14 = ['Tool','Date',' basadj.fia.dx_FIA Base-line Offset X:[um]',
          ' basadj.fia.dy_Y:[um]',' basadj.lsa.dx_LSA Base-line Offset X:[um]',
          ' basadj.lsa.dy_Y:[um]',' magadj.Dnocalib_Offset:[um]',' basadj.Drot_Reticle Rotation:[urad]']     

col = ['rot','lsa_x','lsa_y','fia_x','fia_y','mag','tool','date' ]

df11 = pd.read_csv(I11,usecols = item11)
df14 = pd.read_csv(I14,usecols = item14)

df11.columns = col
df14.columns = col
df = pd.concat([df11,df14],axis=0)
df11 ,df14 = None,None

df['date'] = pd.to_datetime(df['date'])
df = df.reset_index().set_index('date')



ovl =  ovl_qc()

ovl['Riqi'] =  [datetime.datetime.strptime(str(i)[:-6],'%Y-%m-%d %H:%M:%S') for i in ovl['Riqi']]
ovl = ovl.reset_index().set_index('Riqi')

ovltool = ['ALII01', 'ALII02', 'ALII03', 'ALII04', 'ALII05', 'ALII10',
       'ALII11', 'ALII12', 'ALII13', 'ALII14', 'ALII15', 'ALII16',
       'ALII17', 'ALII18', 'ALSIB6', 'ALSIB7', 'ALSIB8', 'ALSIB9',
       'ALSIBJ', 'BLSIBK', 'BLSIBL', 'BLSIE1', 'BLSIE2']







toolmap = {'alsib1':'ALII01', 'alsib2':'ALII02', 'alsib3':'ALII03', 
           'alsib4':'ALII04', 'alsib5':'ALII05', 'alsib6':'ALSIB6',
           'alsib7':'ALSIB7', 'alsib8':'ALSIB8', 'alsib9':'ALSIB9', 
           'alsiba':'ALII10', 'alsibb':'ALII11', 'alsibc':'ALII12',
           'alsibd':'ALII13', 'alsibe':'ALII14', 'alsibf':'ALII15',
           'alsibg':'ALII15', 'alsibh':'ALII17', 'alsibi':'ALII18',
           'alsibj':'ALSIBJ', 'blsibk':'BLSIBK', 'blsibl':'BLSIBL',
           'blsie1':'BLSIE1', 'blsie2':'BLSIE2'}


nikon =  Nikno_Product_OVL()

for tool in df['tool'].unique()[0:]:
    tmp = df[df['tool']==tool]
    tmp1 = ovl[ovl['Tool']==toolmap[tool]] # QC Value
    tmp2 = nikon[nikon['Tool']==toolmap[tool]]  # Product value
    lsa,fia = LSA_FIA(tmp2)
    

    fig = plt.figure(figsize=(18, 10))
    #-----------------------------------
    ax1 = fig.add_subplot(3,2,1) 
    x = list(tmp.index)
    y = list(tmp['lsa_x']) 
    plt.plot(x,y,color = 'blue')
    #tmp['lsa_x'].plot()    
    ax1.yaxis.grid(True)
    ax1.set_title(tool.upper() + ' LSA_X  Blue:Machine/Red:QcOpt/Green:QcMeasured/Black:ProductOpt' )
    #plt.text(0, 0, 'Blue:Machine Red:QcOpt Green:QcMeasured Black:ProductOpt')
    

    
    
    ax11 = ax1.twinx()
    x = list(tmp1[tmp1['Part'].str.contains('LSA')].index)
    y = list(tmp1[tmp1['Part'].str.contains('LSA')]['TranX'])
    plt.plot(x,y,color='red')
    y = list(tmp1[tmp1['Part'].str.contains('LSA')]['Mx'])
    plt.plot(x,y,color='green')
    
    x = lsa['Riqi']
    y = lsa['TranX']
    plt.plot(x,y,color='black',marker='.',linestyle=':',alpha=0.1)
    
    #-----------------------------------
    
    #-----------------------------------
    ax2 = fig.add_subplot(3,2,2)
    x = list(tmp.index)
    y = list(tmp['lsa_y']) 
    plt.plot(x,y,color = 'blue')
    #tmp['lsa_y'].plot()    
    ax2.yaxis.grid(True)
    ax2.set_title(tool.upper() + ' LSA_Y' )
    
    ax21 = ax2.twinx()
    x = list(tmp1[tmp1['Part'].str.contains('LSA')].index)
    y = list(tmp1[tmp1['Part'].str.contains('LSA')]['TranY'])
    plt.plot(x,y,color='red')  
    y = list(tmp1[tmp1['Part'].str.contains('LSA')]['My'])
    plt.plot(x,y,color='green')
    x = lsa['Riqi']
    y = lsa['TranY']
    plt.plot(x,y,color='black',marker='.',linestyle=':',alpha=0.1)
    
    #-----------------------------------    
    
    #-----------------------------------
    ax3 = fig.add_subplot(3,2,3)
    x = list(tmp.index)
    y = list(tmp['fia_x']) 
    plt.plot(x,y,color = 'blue')
    #tmp['fia_x'].plot()    
    ax3.yaxis.grid(True)
    ax3.set_title(tool.upper() + ' FIA_X' )
    
    
    ax31 = ax3.twinx()
    x = list(tmp1[tmp1['Part'].str.contains('FIA')].index)
    y = list(tmp1[tmp1['Part'].str.contains('FIA')]['TranX'])
    plt.plot(x,y,color='red')
    y = list(tmp1[tmp1['Part'].str.contains('FIA')]['Mx'])
    plt.plot(x,y,color='green') 
    x = fia['Riqi']
    y = fia['TranX']
    plt.plot(x,y,color='black',marker='.',linestyle=':',alpha=0.1)
    #-----------------------------------    
        
    #-----------------------------------
    ax4 = fig.add_subplot(3,2,4) 
    x = list(tmp.index)
    y = list(tmp['fia_y']) 
    plt.plot(x,y,color = 'blue')   
    ax4.yaxis.grid(True)
    ax4.set_title(tool.upper() + ' FIA_Y' )
    
    ax41 = ax4.twinx()
    x = list(tmp1[tmp1['Part'].str.contains('FIA')].index)
    y = list(tmp1[tmp1['Part'].str.contains('FIA')]['TranY'])
    plt.plot(x,y,color='red') 
    y = list(tmp1[tmp1['Part'].str.contains('FIA')]['My'])
    plt.plot(x,y,color='green')
    x = fia['Riqi']
    y = fia['TranY']
    plt.plot(x,y,color='black',marker='.',linestyle=':',alpha=0.1)
    
    #-----------------------------------        
    
    #-----------------------------------
    ax5 = fig.add_subplot(3,2,5) 
    x = list(tmp.index)
    y = list(tmp['rot']) 
    plt.plot(x,y,color = 'blue')   
    ax5.yaxis.grid(True)
    ax5.set_title(tool.upper() + ' ROT' )
    
    ax51 = ax5.twinx()
    x = list(tmp1[tmp1['Part'].str.contains('FIA')].index)
    y = list(tmp1[tmp1['Part'].str.contains('FIA')]['Rot'])
    plt.plot(x,y,color='red') 
    y = list(tmp1[tmp1['Part'].str.contains('FIA')]['Mr'])
    plt.plot(x,y,color='green')  
    x = fia['Riqi']
    y = fia['SRot']
    plt.plot(x,y,color='black',marker='.',linestyle=':',alpha=0.1)
    #-----------------------------------    
    
    #-----------------------------------
    ax6 = fig.add_subplot(3,2,6) 
    x = list(tmp.index)
    y = list(tmp['mag']) 
    plt.plot(x,y,color = 'blue')    
    ax6.yaxis.grid(True)
    ax6.set_title(tool.upper() + ' MAG' )
    
    ax61 = ax6.twinx()
    x = list(tmp1[tmp1['Part'].str.contains('FIA')].index)
    y = list(tmp1[tmp1['Part'].str.contains('FIA')]['Mag'])
    plt.plot(x,y,color='red')
    y = list(tmp1[tmp1['Part'].str.contains('FIA')]['Mm'])
    plt.plot(x,y,color='green') 
    x = fia['Riqi']
    y = fia['SMag']
    plt.plot(x,y,color='black',marker='.',linestyle=':',alpha=0.1)    
    
    
    #----------------------------------- 

    fig.subplots_adjust(hspace=0.4) 

    plt.savefig('z:\\_DailyCheck\\NikonAdjust\\' + tool ,dpi=100, bbox_inches='tight')

    
    
    
    
    
    
    
    