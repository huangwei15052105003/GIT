# -*- coding: utf-8 -*-
"""
Created on Fri Nov 16 07:21:45 2018

@author: HUANGWEI45
"""

import pandas as pd
import datetime
import os



esfColumns=   ['ACTION','PARTTITLE', 'PART', 'STAGE', 'RECIPE', 'PPID', 'EQPID', 'FLAG', 'TYPE',
    'ACTIVEFLAG', 'FAILREASON', 'EXPIRETIME', 'CREATEUSER', 'USERDEPT',
    'CREATETIME', 'REQUESTUSER']


 
os.system('z:\\_dailycheck\\ESF\\ESF.xlsm')
new = pd.read_excel('z:\\_dailycheck\\ESF\\ESF.xlsm',sheet_name = 'ESF',header=0).fillna('')
new.to_csv('z:\\_dailycheck\\ESF\\ESF_' + str(datetime.date.today() )+".csv",index=None,encoding='GBK')  
#new = pd.read_csv('z:\\_dailycheck\\ESF\\ESF_' + str(datetime.date.today() )+".csv",encoding='GBK').fillna('')


old = str(datetime.date.today() + datetime.timedelta(days=-1))
if os.path.exists('z:\\_dailycheck\\ESF\\ESF_' + old +".csv"):
    old = pd.read_csv('z:\\_dailycheck\\ESF\\ESF_' + old +".csv",encoding='GBK').fillna('')


new =set( [ ('#'+str(new.loc[i][0])
          + '#'+str(new.loc[i][1])
          + '#'+str(new.loc[i][2])
          + '#'+str(new.loc[i][3])
          + '#'+str(new.loc[i][4])
          + '#'+str(new.loc[i][5])
          + '#'+str(new.loc[i][6])
          + '#'+str(new.loc[i][7])
          + '#'+str(new.loc[i][8])           
          + '#'+str(new.loc[i][9]) 
          + '#'+str(new.loc[i][10]) 
          + '#'+str(new.loc[i][11]) 
          + '#'+str(new.loc[i][12]) 
          + '#'+str(new.loc[i][13]) 
          + '#'+str(new.loc[i][14]))  for i in range(new.shape[0])])
          
old  =set( [ ('#'+str(old.loc[i][0])
          + '#'+str(old.loc[i][1])
          + '#'+str(old.loc[i][2])
          + '#'+str(old.loc[i][3])
          + '#'+str(old.loc[i][4])
          + '#'+str(old.loc[i][5])
          + '#'+str(old.loc[i][6])
          + '#'+str(old.loc[i][7])
          + '#'+str(old.loc[i][8])
          + '#'+str(old.loc[i][9])
          + '#'+str(old.loc[i][10])
          + '#'+str(old.loc[i][11])
          + '#'+str(old.loc[i][12])
          + '#'+str(old.loc[i][13])    
          + '#'+str(old.loc[i][14]) )for i in range(old.shape[0])])
          
          
added =   pd.DataFrame( [[k for k in i.split('#')]  for i in (new-old)],columns = esfColumns)
deleted =   pd.DataFrame( [[k for k in i.split('#')]  for i in (old-new)],columns = esfColumns)
                                             
                                             
                                             
added['ACTION'] = 'added'
deleted['ACTION']='deleted'
result = pd.concat([added,deleted])   
result.to_csv('z:\\_dailycheck\\ESF\\result_' + str(datetime.date.today() )+".csv",index=None,encoding="GBK")                          
          