# -*- coding: utf-8 -*-
"""
Created on Thu May 24 07:32:41 2018

@author: HUANGWEI45
"""

import os
import datetime



def MakeVmsFtp():

    no = [ '01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22','23','24','25']
    
    tmp = str( datetime.datetime.now().date()-datetime.timedelta(days = 1) ).split('-')
    tmp = tmp[0] + tmp[1] + tmp[2]
    
    
    
    
    
    
    for tool in no:
        
        if tool in [ '22','23']:
            
        
            if os.path.exists(r'P:\SEQLOG\EGAftp\EGAftp' + tool + '.ftp'):
                os.remove( r'P:\SEQLOG\EGAftp\EGAftp' + tool + '.ftp' )
                
            file = open ( r'P:\SEQLOG\EGAftp\EGAftp' + tool + '.ftp','w')
            tmpstr = 'set def dka100:[mcsvlog.msr]\n'
            tmpstr = tmpstr + 'lcd dka300:[ega' + tool + ']\n'
            tmpstr = tmpstr + 'asc\n'
            #tmpstr = tmpstr + 'delete ega_' + tmp2 +'*.egam;*\n'
            tmpstr = tmpstr + 'get ega_' + tmp + '*.egam;*\n'
            tmpstr = tmpstr + 'bye\n'
            file.write(tmpstr)
            file.close
        else:
            if os.path.exists(r'P:\SEQLOG\EGAftp\EGAftp' + tool + '.ftp'):
                os.remove( r'P:\SEQLOG\EGAftp\EGAftp' + tool + '.ftp' )
                
            file = open ( r'P:\SEQLOG\EGAftp\EGAftp' + tool + '.ftp','w')
            tmpstr = 'set def dka300:[mcsvlog.msr]\n'
            tmpstr = tmpstr + 'lcd dka300:[ega' + tool + ']\n'
            tmpstr = tmpstr + 'asc\n'
            #tmpstr = tmpstr + 'delete ega_' + tmp2 +'*.egam;*\n'
            tmpstr = tmpstr + 'get ega_' + tmp + '*.egam;*\n'
            tmpstr = tmpstr + 'bye\n'
            file.write(tmpstr)
            file.close
            
        
 
if __name__ == "__main__":
    MakeVmsFtp()
    tmp = open(r'C:\anaconda3\log.txt','a')
    tmp.write("\n" + str(datetime.datetime.now())[0:19] + "___001-MakeVmsFtp Done\n")
    tmp.close()